import { useEffect, useRef, useState } from "react";
import { Skull, Coins, Pause, Volume2, VolumeX, Heart, Zap, Crosshair, MousePointerClick, ArrowBigDown, Slice, Hammer, DoorOpen, Zap as PowerIcon, Star, Dna, Radio, Wrench, Mic, MicOff } from "lucide-react";
import type { ZombieEngine, HudSnapshot } from "../game/fpsEngine";
import { MAPS, type MapId } from "../game/maps";
import { AbilityIcon } from "./abilityIcons";

export function HUD({
  engineRef,
  muted,
  voiceOn,
  onPause,
  onToggleMute,
  onToggleVoice,
  mapId,
}: {
  engineRef: React.RefObject<ZombieEngine | null>;
  muted: boolean;
  voiceOn: boolean;
  onPause: () => void;
  onToggleMute: () => void;
  onToggleVoice: () => void;
  mapId: MapId;
}) {
  const [s, setS] = useState<HudSnapshot | null>(null);
  const [gain, setGain] = useState<{ v: number; k: number } | null>(null);
  const prevPoints = useRef(0);

  useEffect(() => {
    const id = window.setInterval(() => {
      const e = engineRef.current;
      if (e) {
        const snap = e.getSnapshot();
        setS((old) => {
          if (old && snap.points > old.points) {
            setGain({ v: snap.points - old.points, k: Date.now() });
          }
          return snap;
        });
      }
    }, 100);
    return () => window.clearInterval(id);
  }, [engineRef]);

  useEffect(() => {
    if (!gain) return;
    const t = window.setTimeout(() => setGain(null), 1200);
    return () => window.clearTimeout(t);
  }, [gain]);

  useEffect(() => {
    if (s) prevPoints.current = s.points;
  }, [s]);

  if (!s) return null;
  const hpPct = Math.max(0, (s.hp / s.maxHp) * 100);
  const hpColor = hpPct > 55 ? "bg-green-500" : hpPct > 28 ? "bg-amber-400" : "bg-red-600";
  const xpPct = Math.min(100, (s.xp / Math.max(1, s.xpNeed)) * 100);
  const sp = s.spread;

  return (
    <div className="pointer-events-none absolute inset-0 z-20 select-none">
      {/* flash de dano: fino e só quando dói de verdade (a grade 3D já cuida do resto) */}
      <div
        className="absolute inset-0 transition-opacity duration-200"
        style={{
          opacity: Math.min(0.6, s.recentHit * 0.5 + (s.dying > 0 ? 0.5 : 0)),
          background: "radial-gradient(ellipse at center, transparent 55%, rgba(170,10,10,0.7) 100%)",
        }}
      />
      {s.nukeFlash > 0 && (
        <div className="absolute inset-0 bg-[#fff6dc]" style={{ opacity: Math.min(0.9, s.nukeFlash) }} />
      )}

      {/* XP / nível */}
      <div className="absolute inset-x-0 top-0">
        <div className="h-1 w-full bg-black/70">
          <div
            className="h-full bg-gradient-to-r from-emerald-600 via-green-300 to-emerald-600 transition-[width] duration-200"
            style={{ width: `${xpPct}%` }}
          />
        </div>
        <div className="flex justify-center">
          <div className="bg-black/60 px-2.5 py-0.5 font-tech text-[10px] tracking-[0.25em] text-green-200/90">
            NV {s.level} · {s.xp}/{s.xpNeed} XP
          </div>
        </div>
      </div>

      {/* DINHEIRO — grande, topo centro, estilo COD */}
      <div className="absolute left-1/2 top-7 -translate-x-1/2 text-center sm:top-8">
        <div className="font-tech text-[10px] tracking-[0.45em] text-amber-200/80">DINHEIRO</div>
        <div key={s.points} className="ammo-pop font-display text-5xl leading-none text-amber-300 drop-shadow-[0_2px_0_rgba(0,0,0,0.9)] sm:text-6xl" style={{ textShadow: "0 3px 0 rgba(0,0,0,0.8), 0 0 28px rgba(255,180,60,0.35)" }}>
          <span className="mr-1 align-top text-2xl sm:text-3xl">$</span>{s.points.toLocaleString("pt-BR")}
        </div>
        {gain && (
          <div key={gain.k} className="rise-in font-tech text-sm font-bold tracking-[0.2em] text-green-300" style={{ textShadow: "0 2px 0 rgba(0,0,0,0.9)" }}>
            +{gain.v.toLocaleString("pt-BR")} $
          </div>
        )}
      </div>

      {/* top-left */}
      <div className="absolute left-2 top-8 sm:left-4 sm:top-9">
        <div className="border border-white/10 bg-black/65 px-3 py-2 backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <div>
              <div className="font-tech text-[9px] tracking-[0.3em] text-red-500">ROUND</div>
              <div className="font-display text-3xl leading-none text-white">{String(s.round).padStart(2, "0")}</div>
            </div>
            <div className="h-10 w-px bg-white/10" />
            <div>
              <div className="flex items-center gap-1 font-tech text-[9px] tracking-[0.3em] text-stone-400">
                <Skull className="h-3 w-3 text-red-500" /> RESTAM
              </div>
              <div className={`font-display text-3xl leading-none ${s.zombiesLeft === 0 ? "text-green-400" : "text-amber-200"}`}>{s.zombiesLeft}</div>
            </div>
          </div>
          <div className="font-tech mt-1 border-t border-white/10 pt-1 text-[11px] tracking-[0.2em] text-stone-300">
            SCORE <span className="font-bold text-white">{s.score.toLocaleString("pt-BR")}</span>
          </div>
          {s.intermission > 0 && (
            <div className="font-tech mt-1 animate-pulse text-[10px] tracking-[0.2em] text-green-300">
              PRÓXIMO ROUND EM {Math.ceil(s.intermission)}s
            </div>
          )}
        </div>
        {(s.doubleT > 0 || s.instaT > 0) && (
          <div className="mt-1.5 flex gap-1.5">
            {s.doubleT > 0 && (
              <div className="flex items-center gap-1 border border-amber-300/40 bg-amber-950/80 px-2 py-1 font-tech text-[11px] text-amber-200">
                <Zap className="h-3 w-3" /> 2X {Math.ceil(s.doubleT)}s
              </div>
            )}
            {s.instaT > 0 && (
              <div className="pulse-red flex items-center gap-1 border border-red-500/50 bg-red-950/80 px-2 py-1 font-tech text-[11px] text-red-200">
                <Skull className="h-3 w-3" /> INSTA {Math.ceil(s.instaT)}s
              </div>
            )}
          </div>
        )}
        {s.abilities.length > 0 && (
          <div className="mt-1.5 flex max-w-44 flex-wrap gap-1">
            {s.abilities.map((a) => (
              <div
                key={a.id}
                title={`${a.name} — nível ${a.level}`}
                className="flex items-center gap-1 border bg-black/70 px-1.5 py-1 backdrop-blur-sm"
                style={{ borderColor: `${a.color}55` }}
              >
                <span style={{ color: a.color }}>
                  <AbilityIcon icon={a.icon} className="h-3.5 w-3.5" />
                </span>
                <span className="font-tech text-[9px] tracking-wider text-stone-300">
                  {a.level >= 3 ? "MAX" : `Nv${a.level}`}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* top-right */}
      <div className="pointer-events-auto absolute right-2 top-8 flex gap-1.5 sm:right-4 sm:top-9">
        <button onClick={onToggleVoice} title={voiceOn ? "Voz do sargento: ON" : "Voz do sargento: OFF"} className={`border p-2 backdrop-blur-sm transition hover:bg-white/10 ${voiceOn ? "border-white/15 bg-black/65 text-stone-300" : "border-red-400/40 bg-red-950/60 text-red-300"}`} aria-label="Voz">
          {voiceOn ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
        </button>
        <button onClick={onToggleMute} className="border border-white/15 bg-black/65 p-2 text-stone-300 backdrop-blur-sm transition hover:bg-white/10" aria-label="Som">
          {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </button>
        <button onClick={onPause} className="border border-white/15 bg-black/65 p-2 text-stone-300 backdrop-blur-sm transition hover:bg-white/10" aria-label="Pausar">
          <Pause className="h-4 w-4" />
        </button>
      </div>
      <div className="absolute right-2 top-20 hidden text-right font-tech text-[10px] tracking-[0.2em] text-stone-500 sm:right-4 sm:block">
        <div style={{ color: MAPS[mapId].accent }}>{MAPS[mapId].name} · {MAPS[mapId].sub}</div>
        <div>{s.kills} KILLS · {s.headshots} HEADSHOTS · {s.accuracy}%</div>
      </div>

      {/* mira ADS (luneta) */}
      {s.ads > 0.5 && s.dying <= 0 && (
        <div className="absolute inset-0 flex items-center justify-center" style={{ opacity: Math.min(1, (s.ads - 0.5) * 2) }}>
          <div
            className="absolute inset-0"
            style={{ background: "radial-gradient(circle at center, transparent 26%, rgba(0,0,0,0.88) 31%)" }}
          />
          <div className="h-56 w-56 rounded-full border border-black/80 sm:h-72 sm:w-72" style={{ boxShadow: "0 0 0 2px rgba(255,255,255,0.12), inset 0 0 40px rgba(0,0,0,0.7)" }} />
          <div className="absolute h-px w-56 bg-black/70 sm:w-72" />
          <div className="absolute h-56 w-px bg-black/70 sm:h-72" />
          <div className="absolute h-1.5 w-1.5 rounded-full bg-red-500/90" />
        </div>
      )}
      {/* postura: agachado / no ar / faca */}
      {(s.crouched || s.airborne || s.knifing > 0) && s.dying <= 0 && (
        <div className="absolute bottom-24 left-1/2 flex -translate-x-1/2 gap-1.5">
          {s.crouched && (
            <div className="flex items-center gap-1 border border-green-300/50 bg-green-950/80 px-2 py-1 font-tech text-[10px] tracking-[0.2em] text-green-200">
              <ArrowBigDown className="h-3 w-3" /> AGACHADO
            </div>
          )}
          {s.airborne && (
            <div className="border border-sky-300/50 bg-sky-950/80 px-2 py-1 font-tech text-[10px] tracking-[0.2em] text-sky-200">
              NO AR
            </div>
          )}
          {s.knifing > 0 && (
            <div className="pulse-red flex items-center gap-1 border border-slate-200/60 bg-slate-800/90 px-2 py-1 font-tech text-[10px] tracking-[0.2em] text-white">
              <Slice className="h-3 w-3" /> FACADA 150
            </div>
          )}
        </div>
      )}
      {/* mira central */}
      {s.dying <= 0 && s.ads < 0.6 && s.knifing <= 0.05 && (
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="relative h-0 w-0">
            {[[1, 0], [-1, 0], [0, 1], [0, -1]].map(([ox, oy], i) => (
              <div
                key={i}
                className="absolute rounded-full"
                style={{
                  width: 3, height: oy !== 0 ? 9 : 3,
                  left: ox * sp - (ox !== 0 ? 1.5 : 1.5),
                  top: oy * sp - (oy !== 0 ? 4.5 : 1.5),
                  background: s.hitA > 0.05 ? "#ff4d4d" : "rgba(255,255,255,0.92)",
                  boxShadow: "0 0 4px rgba(0,0,0,0.9)",
                }}
              />
            ))}
            <div className="absolute h-1 w-1 rounded-full bg-white" style={{ left: -0.5, top: -0.5 }} />
            {/* hitmarker */}
            {s.hitA > 0.05 && (
              <div
                className="absolute"
                style={{
                  left: -16, top: -16, width: 32, height: 32,
                  opacity: Math.min(1, s.hitA + 0.3),
                  transform: `rotate(45deg) scale(${s.hitKill ? 1.25 : 1})`,
                }}
              >
                {[[ -1, -1], [1, -1], [-1, 1], [1, 1]].map(([qx, qy], i) => (
                  <div
                    key={i}
                    className="absolute"
                    style={{
                      width: 10, height: s.hitKill ? 4 : 3,
                      left: qx === -1 ? 0 : 22, top: qy === -1 ? 0 : 22,
                      background: s.hitKill ? "#ff2d2d" : s.hitHead ? "#ff7a2d" : "#fff",
                      transform: `rotate(${qx * qy === 1 ? 45 : -45}deg)`,
                      boxShadow: "0 0 6px rgba(0,0,0,0.9)",
                    }}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* clique para mirar */}
      {!s.locked && s.dying <= 0 && (
        <div className="absolute inset-x-0 top-[58%] flex justify-center">
          <div className="pulse-red flex items-center gap-2 border border-white/25 bg-black/75 px-4 py-2 font-cond text-sm font-bold tracking-[0.25em] text-white">
            <MousePointerClick className="h-4 w-4" /> CLIQUE PARA MIRAR
          </div>
        </div>
      )}

      {/* banner */}
      {s.bannerT > 0 && (
        <div className="absolute inset-x-0 top-[20%] flex flex-col items-center">
          <div key={s.banner} className="banner-in font-display text-stroke text-5xl text-red-600 sm:text-7xl">{s.banner}</div>
          <div className="font-type mt-1 bg-black/55 px-4 py-1 text-sm tracking-[0.3em] text-amber-100/90 sm:text-base">{s.bannerSub}</div>
        </div>
      )}

      {/* prompt de interação: janela / energia / relé / bancada / pack / perk / porta / loja */}
      {s.nearBuy && s.dying <= 0 && (
        <div className="absolute inset-x-0 bottom-36 flex justify-center sm:bottom-32">
          <div className={`rise-in flex items-center gap-3 border px-4 py-2 backdrop-blur-sm ${
            s.nearBuy.kind === "window" ? "border-green-300/50 bg-green-950/70"
            : s.nearBuy.kind === "power" ? "border-yellow-300/60 bg-yellow-950/70"
            : s.nearBuy.kind === "relay" ? "border-violet-300/60 bg-violet-950/70"
            : s.nearBuy.kind === "workbench" ? "border-sky-300/60 bg-sky-950/70"
            : s.nearBuy.kind === "pack" ? "border-emerald-300/60 bg-emerald-950/70"
            : s.nearBuy.kind === "perk" ? "border-pink-300/50 bg-pink-950/70"
            : s.nearBuy.kind === "door" ? (s.nearBuy.can ? "border-amber-200/60 bg-amber-950/70" : "border-red-400/40 bg-black/70")
            : s.nearBuy.can ? "border-amber-200/50 bg-black/75" : "border-white/15 bg-black/60"
          }`}>
            {s.nearBuy.kind === "window" ? (
              <Hammer className="h-5 w-5 text-green-300" />
            ) : s.nearBuy.kind === "power" ? (
              <PowerIcon className="h-5 w-5 text-yellow-300" />
            ) : s.nearBuy.kind === "relay" ? (
              <Radio className="h-5 w-5 text-violet-300" />
            ) : s.nearBuy.kind === "workbench" ? (
              <Wrench className="h-5 w-5 text-sky-300" />
            ) : s.nearBuy.kind === "pack" ? (
              <Star className="h-5 w-5 text-emerald-300" />
            ) : s.nearBuy.kind === "perk" ? (
              <Dna className="h-5 w-5 text-pink-300" />
            ) : s.nearBuy.kind === "door" ? (
              <DoorOpen className={`h-5 w-5 ${s.nearBuy.can ? "text-amber-300" : "text-red-400"}`} />
            ) : (
              <Crosshair className={`h-5 w-5 ${s.nearBuy.can ? "text-amber-300" : "text-stone-500"}`} />
            )}
            <div className="text-left">
              <div className="font-cond text-sm font-bold tracking-widest text-white">
                {s.nearBuy.label}{(s.nearBuy.kind === "door" || s.nearBuy.kind === "station" || s.nearBuy.kind === "pack" || s.nearBuy.kind === "perk") && s.nearBuy.price > 0 ? ` — ${s.nearBuy.price} $` : ""}
                {s.nearBuy.lockedReason && <span className="ml-2 text-red-400">· {s.nearBuy.lockedReason}</span>}
              </div>
              <div className="font-tech text-[10px] tracking-[0.2em] text-stone-300">{s.nearBuy.hint}</div>
            </div>
            <div className={`font-display border px-2.5 py-1 text-lg ${s.nearBuy.can ? "border-amber-300 bg-amber-400/20 text-amber-200" : "border-white/20 text-stone-500"}`}>F</div>
          </div>
        </div>
      )}

      {s.mag === 0 && !s.reloading && s.dying <= 0 && (
        <div className="pulse-red absolute inset-x-0 bottom-48 flex justify-center">
          <div className="font-cond bg-red-800/90 px-4 py-1 text-sm font-bold tracking-[0.3em] text-white">RECARREGUE — R</div>
        </div>
      )}

      {/* HP (dinheiro agora mora no topo) */}
      <div className="absolute bottom-2 left-2 sm:bottom-4 sm:left-4">
        <div className="w-52 border border-white/10 bg-black/65 p-2.5 backdrop-blur-sm sm:w-64">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 font-tech text-[10px] tracking-[0.25em] text-stone-400">
              <Heart className={`h-3.5 w-3.5 ${s.lowHp ? "animate-pulse text-red-500" : "text-green-500"}`} /> {s.hp}
            </div>
            <div className="flex items-center gap-1 font-tech text-sm font-bold text-amber-200/90">
              <Coins className="h-4 w-4 text-amber-300" /> {s.points.toLocaleString("pt-BR")} $
            </div>
          </div>
          <div className="mt-1.5 h-2.5 w-full overflow-hidden rounded-sm bg-white/10">
            <div className={`hp-bar h-full ${hpColor}`} style={{ width: `${hpPct}%` }} />
          </div>
          <div className="mt-1.5 flex gap-1">
            {s.weapons.map((w, i) => (
              <div key={i} className={`flex-1 border px-1.5 py-0.5 text-center font-tech text-[10px] ${w.active ? "border-amber-200/60 bg-amber-200/10 text-amber-100" : "border-white/10 text-stone-500"}`}>
                {w.short} {w.mag}/{w.reserve}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* munição */}
      <div className="absolute bottom-2 right-2 text-right sm:bottom-4 sm:right-4">
        <div className="border border-white/10 bg-black/65 px-3 py-2 backdrop-blur-sm">
          <div className="font-cond text-[11px] font-semibold tracking-[0.25em] text-stone-400">{s.weaponName.toUpperCase()}</div>
          <div key={`${s.mag}`} className="ammo-pop font-display leading-none text-white">
            <span className={`text-4xl sm:text-5xl ${s.mag === 0 ? "text-red-500" : s.mag <= s.magSize * 0.25 ? "text-amber-300" : ""}`}>{s.mag}</span>
            <span className="ml-1 text-lg text-stone-500">/ {s.reserve}</span>
          </div>
          {s.reloading ? (
            <div className="mt-1">
              <div className="font-tech animate-pulse text-[10px] tracking-[0.3em] text-amber-300">RECARREGANDO</div>
              <div className="mt-1 h-1 w-36 overflow-hidden bg-white/10">
                <div className="h-full bg-amber-300" style={{ width: `${s.reloadPct * 100}%` }} />
              </div>
            </div>
          ) : (
            <div className="font-tech mt-1 hidden text-[10px] tracking-[0.25em] text-stone-600 sm:block">R RECARREGAR · Q TROCAR · BOTÃO DIREITO FACA / SEGURAR MIRA</div>
          )}
        </div>
      </div>
    </div>
  );
}

import { useState } from "react";
import { Trophy, Medal, Trash2, CloudOff } from "lucide-react";
import type { GameMode, HighScore } from "../game/scores";
import { MODE_LABEL, clearScores } from "../game/scores";

interface Props {
  scores: HighScore[];
  compact?: boolean;
  highlight?: number;
  mode?: GameMode;
  onCleared?: (scores: HighScore[]) => void;
}

export function HighScoreTable({ scores, compact = false, highlight = -1, mode = "single", onCleared }: Props) {
  const [confirming, setConfirming] = useState(false);
  const medal = ["text-amber-300", "text-stone-300", "text-amber-600"];

  const handleClear = () => {
    if (!confirming) {
      setConfirming(true);
      window.setTimeout(() => setConfirming(false), 3000);
      return;
    }
    clearScores(mode);
    setConfirming(false);
    onCleared?.([]);
  };

  return (
    <div className={`border border-white/10 bg-black/70 backdrop-blur ${compact ? "" : "p-1"}`}>
      <div className="flex items-center gap-2 border-b border-white/10 bg-white/5 px-4 py-2">
        <Trophy className="h-4 w-4 text-amber-300" />
        <span className="font-cond flex-1 text-left text-sm font-bold tracking-[0.25em] text-amber-100">
          RECORDES REAIS — {MODE_LABEL[mode]}
        </span>
        {scores.length > 0 && (
          <button
            onClick={handleClear}
            title="Apagar recordes deste dispositivo"
            className={`flex items-center gap-1 border px-2 py-1 font-tech text-[10px] tracking-[0.2em] transition ${
              confirming
                ? "border-red-500 bg-red-900/50 text-red-200"
                : "border-white/10 text-stone-500 hover:border-white/25 hover:text-stone-300"
            }`}
          >
            <Trash2 className="h-3 w-3" />
            {confirming ? "CONFIRMAR?" : "LIMPAR"}
          </button>
        )}
      </div>

      <div className="max-h-64 overflow-y-auto">
        {scores.length === 0 && (
          <div className="p-5 text-center">
            <Medal className="mx-auto h-8 w-8 text-stone-700" />
            <div className="font-cond mt-2 text-sm font-bold tracking-[0.25em] text-stone-300">
              NENHUM RECORDE AINDA
            </div>
            <p className="font-tech mt-1 text-[11px] leading-relaxed tracking-wider text-stone-500">
              Jogue uma partida e salve sua pontuação.
              <br />
              Aqui só entra resultado de verdade — nada de nomes falsos.
            </p>
            <div className="font-tech mt-3 inline-flex items-center gap-1.5 border border-white/10 bg-white/5 px-2.5 py-1 text-[10px] tracking-[0.2em] text-stone-500">
              <CloudOff className="h-3 w-3" />
              RANKING ONLINE (FIREBASE) — EM BREVE
            </div>
          </div>
        )}
        {scores.map((s, i) => (
          <div
            key={s.id || i}
            className={`flex items-center gap-3 border-b border-white/5 px-3 py-1.5 font-tech text-xs sm:text-sm ${i === highlight ? "bg-red-900/40 text-white" : i % 2 ? "bg-white/[0.02]" : ""}`}
          >
            <span className={`w-6 text-center font-bold ${medal[i] ?? "text-stone-500"}`}>
              {i < 3 ? <Medal className="mx-auto h-4 w-4" /> : `${i + 1}`}
            </span>
            <span className="flex-1 truncate tracking-[0.2em] text-stone-200">{s.name}</span>
            <span className="hidden text-stone-500 sm:inline">R{s.round}</span>
            <span className="hidden text-stone-500 sm:inline">Nv{s.level}</span>
            <span className="hidden text-stone-500 sm:inline">{s.kills} K</span>
            <span className="font-bold text-amber-200">{s.score.toLocaleString("pt-BR")}</span>
          </div>
        ))}
      </div>

      {scores.length > 0 && (
        <div className="font-tech border-t border-white/10 px-3 py-1.5 text-[10px] tracking-[0.15em] text-stone-600">
          {scores.length} {scores.length === 1 ? "PARTIDA REAL SALVA" : "PARTIDAS REAIS SALVAS"} NESTE DISPOSITIVO
        </div>
      )}
    </div>
  );
}

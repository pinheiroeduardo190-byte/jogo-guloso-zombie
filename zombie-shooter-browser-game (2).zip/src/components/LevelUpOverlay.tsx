import { useEffect } from "react";
import { ArrowUpCircle } from "lucide-react";
import type { Choice } from "../game/abilities";
import { AbilityIcon } from "./abilityIcons";

export function LevelUpOverlay({
  choices, level, onPick,
}: {
  choices: Choice[];
  level: number;
  onPick: (id: string) => void;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const i = ["1", "2", "3"].indexOf(e.key);
      if (i >= 0 && choices[i]) {
        e.preventDefault();
        onPick(choices[i].id);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [choices, onPick]);

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center overflow-y-auto bg-black/80 p-4 backdrop-blur-[2px]">
      <div className="w-full max-w-3xl py-4 text-center">
        <div className="rise-in mx-auto flex h-16 w-16 items-center justify-center rounded-full border-2 border-green-300 bg-green-950/60 shadow-[0_0_40px_rgba(93,255,141,0.5)]">
          <ArrowUpCircle className="h-9 w-9 text-green-300" />
        </div>
        <div className="font-tech mt-2 text-[11px] tracking-[0.5em] text-green-300">MUTAÇÃO DISPONÍVEL</div>
        <h2 className="font-display text-stroke text-5xl text-white sm:text-6xl">
          NÍVEL <span className="text-green-400">{level}</span>
        </h2>
        <p className="font-type mt-1 text-sm text-stone-300">Escolha 1 de 3 melhorias — e ganhe +25 de vida na hora.</p>

        <div className="mt-5 grid gap-2 sm:grid-cols-3">
          {choices.map((c, i) => (
            <button
              key={c.id}
              onClick={() => onPick(c.id)}
              className="btn-brutal group relative border bg-[#0b0e0b]/95 p-4 text-left"
              style={{ borderColor: `${c.color}77`, boxShadow: `0 0 26px ${c.color}26` }}
            >
              <div className="absolute right-2 top-2 flex h-6 w-6 items-center justify-center border border-white/20 bg-white/5 font-tech text-xs text-stone-300">
                {i + 1}
              </div>
              <div
                className="flex h-12 w-12 items-center justify-center border"
                style={{ borderColor: `${c.color}88`, backgroundColor: `${c.color}14`, color: c.color }}
              >
                <AbilityIcon icon={c.icon} className="h-6 w-6" />
              </div>
              <div
                className="font-tech mt-2 inline-block px-1.5 py-0.5 text-[10px] tracking-[0.25em]"
                style={{ backgroundColor: `${c.color}22`, color: c.color }}
              >
                {c.tag}
              </div>
              <div className="font-cond mt-1 text-lg font-bold leading-tight tracking-wider text-white">{c.name}</div>
              {c.kind === "ability" && (
                <div className="mt-1.5 flex gap-1">
                  {[1, 2, 3].map((p) => (
                    <span
                      key={p}
                      className="h-1.5 flex-1 rounded-sm"
                      style={{ backgroundColor: p <= c.level ? c.color : "rgba(255,255,255,0.12)" }}
                    />
                  ))}
                </div>
              )}
              <p className="font-cond mt-1.5 text-[13px] font-light leading-snug text-stone-300">{c.desc}</p>
              <div
                className="font-cond mt-2 text-center text-xs font-bold tracking-[0.3em] opacity-0 transition group-hover:opacity-100"
                style={{ color: c.color }}
              >
                CLIQUE PARA EVOLUIR
              </div>
            </button>
          ))}
        </div>
        <div className="font-tech mt-3 text-[10px] tracking-[0.3em] text-stone-500">
          PRESSIONE 1 · 2 · 3 PARA ESCOLHER
        </div>
      </div>
    </div>
  );
}

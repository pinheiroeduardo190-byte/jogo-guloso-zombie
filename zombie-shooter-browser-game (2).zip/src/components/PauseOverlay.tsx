import { Play, RotateCcw, Home, Volume2, VolumeX } from "lucide-react";

export function PauseOverlay({
  muted, onResume, onRestart, onQuit, onToggleMute,
}: {
  muted: boolean;
  onResume: () => void;
  onRestart: () => void;
  onQuit: () => void;
  onToggleMute: () => void;
}) {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/75 p-4 backdrop-blur-[3px] grain">
      <div className="rise-in w-full max-w-md border border-white/10 bg-[#0b0e0b]/95 p-6 text-center shadow-[0_0_60px_rgba(0,0,0,0.9)] sm:p-8">
        <div className="font-tech text-[11px] tracking-[0.5em] text-red-500">OPERAÇÃO PAUSADA</div>
        <h2 className="font-display mt-1 text-5xl text-white sm:text-6xl">PAUSADO</h2>
        <p className="font-type mt-2 text-sm text-stone-400">Os mortos esperam por você... por enquanto.</p>

        <div className="mt-6 flex flex-col gap-2">
          <button onClick={onResume} className="btn-brutal flex items-center justify-center gap-2 bg-red-700 px-6 py-3.5 font-display text-xl tracking-wider text-white">
            <Play className="h-5 w-5 fill-current" /> CONTINUAR
          </button>
          <div className="grid grid-cols-2 gap-2">
            <button onClick={onRestart} className="btn-brutal flex items-center justify-center gap-2 border border-white/15 bg-white/5 px-4 py-3 font-cond text-sm font-bold tracking-[0.2em] text-stone-200 hover:bg-white/10">
              <RotateCcw className="h-4 w-4" /> REINICIAR
            </button>
            <button onClick={onQuit} className="btn-brutal flex items-center justify-center gap-2 border border-white/15 bg-white/5 px-4 py-3 font-cond text-sm font-bold tracking-[0.2em] text-stone-200 hover:bg-white/10">
              <Home className="h-4 w-4" /> MENU
            </button>
          </div>
          <button onClick={onToggleMute} className="mx-auto mt-1 flex items-center gap-2 font-tech text-[11px] tracking-[0.25em] text-stone-500 hover:text-white">
            {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />} {muted ? "ATIVAR SOM" : "SILENCIAR"}
          </button>
        </div>

        <div className="font-tech mt-5 border-t border-white/10 pt-3 text-[10px] leading-relaxed tracking-[0.15em] text-stone-600">
          WASD MOVER · SHIFT CORRE/AGACHA · ESPAÇO PULA · DIREITO FACA (SEGURA = MIRA) · R RECARREGAR · F COMPRAR · Q TROCAR
        </div>
      </div>
    </div>
  );
}

import { useRef, useState } from "react";
import { RefreshCw, Repeat, Hand, Crosshair, Focus, ArrowBigUp, ArrowBigDown, Slice } from "lucide-react";
import type { ZombieEngine } from "../game/fpsEngine";
import { sound } from "../game/audio";

interface Stick { active: boolean; id: number; bx: number; by: number; dx: number; dy: number; }
const initStick: Stick = { active: false, id: -1, bx: 0, by: 0, dx: 0, dy: 0 };

export function TouchControls({ engineRef }: { engineRef: React.RefObject<ZombieEngine | null> }) {
  const [move, setMove] = useState<Stick>(initStick);
  const [firing, setFiring] = useState(false);
  const [crouched, setCrouched] = useState(false);
  const moveRef = useRef<HTMLDivElement>(null);
  const lookState = useRef<{ id: number; lx: number; ly: number } | null>(null);
  const R = 52;

  const setMoveVec = (dx: number, dy: number) => engineRef.current?.setTouchMove(dx, dy);

  const mDown = (e: React.PointerEvent) => {
    e.preventDefault();
    sound.ensure();
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    const rect = moveRef.current?.getBoundingClientRect();
    if (!rect) return;
    setMove({ active: true, id: e.pointerId, bx: rect.left + rect.width / 2, by: rect.top + rect.height / 2, dx: 0, dy: 0 });
  };
  const mMove = (e: React.PointerEvent) => {
    if (!move.active || move.id !== e.pointerId) return;
    e.preventDefault();
    let dx = (e.clientX - move.bx) / R, dy = (e.clientY - move.by) / R;
    const m = Math.hypot(dx, dy);
    if (m > 1) { dx /= m; dy /= m; }
    setMove({ ...move, dx, dy });
    setMoveVec(dx, dy);
  };
  const mUp = (e: React.PointerEvent) => {
    if (!move.active || move.id !== e.pointerId) return;
    setMove(initStick);
    setMoveVec(0, 0);
  };

  const lDown = (e: React.PointerEvent) => {
    e.preventDefault();
    sound.ensure();
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    lookState.current = { id: e.pointerId, lx: e.clientX, ly: e.clientY };
  };
  const lMove = (e: React.PointerEvent) => {
    const st = lookState.current;
    if (!st || st.id !== e.pointerId) return;
    e.preventDefault();
    const dx = e.clientX - st.lx, dy = e.clientY - st.ly;
    st.lx = e.clientX; st.ly = e.clientY;
    engineRef.current?.setTouchLook(dx, dy);
  };
  const lUp = (e: React.PointerEvent) => {
    if (lookState.current?.id === e.pointerId) lookState.current = null;
  };

  const setFire = (b: boolean) => {
    setFiring(b);
    engineRef.current?.setTouchFiring(b);
  };

  const btn = "pointer-events-auto flex h-11 w-11 items-center justify-center rounded-full border backdrop-blur-sm active:scale-90 transition";

  return (
    <div className="absolute inset-0 z-[15] select-none" style={{ touchAction: "none" }}>
      <div
        className="absolute bottom-0 right-0 top-0 w-[55%]"
        style={{ touchAction: "none" }}
        onPointerDown={lDown}
        onPointerMove={lMove}
        onPointerUp={lUp}
        onPointerCancel={lUp}
      />
      {/* joystick + pulo/agachar */}
      <div className="absolute bottom-24 left-3 flex items-end gap-2">
        <div
          ref={moveRef}
          className="pointer-events-auto relative h-32 w-32 rounded-full border-2 border-white/20 bg-white/5 backdrop-blur-[2px]"
          style={{ touchAction: "none" }}
          onPointerDown={mDown}
          onPointerMove={mMove}
          onPointerUp={mUp}
          onPointerCancel={mUp}
        >
          <div className="absolute inset-0 flex items-center justify-center font-tech text-[9px] tracking-[0.25em] text-white/40">MOVER</div>
          <div
            className="absolute h-14 w-14 rounded-full border border-white/40 bg-white/25 shadow-lg"
            style={{ left: `calc(50% - 28px + ${move.dx * 38}px)`, top: `calc(50% - 28px + ${move.dy * 38}px)` }}
          />
        </div>
        <div className="pointer-events-auto flex flex-col gap-2">
          <button className={`${btn} border-white/30 bg-black/50 text-white`} onPointerDown={(e) => { e.preventDefault(); engineRef.current?.touchJump(); }} aria-label="Pular">
            <ArrowBigUp className="h-5 w-5" />
          </button>
          <button
            className={`${btn} ${crouched ? "border-green-300 bg-green-500/40 text-green-100" : "border-white/30 bg-black/50 text-white"}`}
            onPointerDown={(e) => { e.preventDefault(); engineRef.current?.toggleCrouch(); setCrouched((v) => !v); }}
            aria-label="Agachar"
          >
            <ArrowBigDown className="h-5 w-5" />
          </button>
        </div>
      </div>
      {/* fogo + faca */}
      <button
        className={`pointer-events-auto absolute bottom-28 right-4 flex h-24 w-24 items-center justify-center rounded-full border-2 font-display text-lg backdrop-blur-sm active:scale-90 ${
          firing ? "border-red-200 bg-red-500/70 text-white" : "border-red-400/70 bg-red-600/30 text-red-100"
        }`}
        style={{ touchAction: "none" }}
        onPointerDown={(e) => { e.preventDefault(); sound.ensure(); setFire(true); }}
        onPointerUp={() => setFire(false)}
        onPointerCancel={() => setFire(false)}
        onPointerLeave={() => setFire(false)}
        aria-label="Atirar"
      >
        <span className="flex flex-col items-center">
          <Crosshair className="h-7 w-7" />
          FOGO
        </span>
      </button>
      <button
        className="pointer-events-auto absolute bottom-28 right-32 flex h-14 w-14 items-center justify-center rounded-full border border-slate-200/50 bg-slate-400/20 text-slate-100 backdrop-blur-sm active:scale-90"
        style={{ touchAction: "none" }}
        onPointerDown={(e) => { e.preventDefault(); engineRef.current?.touchKnife(); }}
        aria-label="Faca"
      >
        <Slice className="h-6 w-6" />
      </button>
      {/* botões táticos */}
      <div className="pointer-events-auto absolute bottom-56 right-4 flex flex-col gap-2">
        <button className={`${btn} border-cyan-200/50 bg-cyan-400/20 text-cyan-100`} onPointerDown={(e) => { e.preventDefault(); engineRef.current?.toggleADS(); }} aria-label="Mira">
          <Focus className="h-5 w-5" />
        </button>
        <button className={`${btn} border-amber-200/50 bg-amber-400/20 text-amber-200`} onPointerDown={(e) => { e.preventDefault(); engineRef.current?.interact(); }} aria-label="Interagir">
          <Hand className="h-5 w-5" />
        </button>
        <button className={`${btn} border-white/30 bg-black/50 text-white`} onPointerDown={(e) => { e.preventDefault(); engineRef.current?.reloadWeapon(); }} aria-label="Recarregar">
          <RefreshCw className="h-5 w-5" />
        </button>
        <button className={`${btn} border-white/30 bg-black/50 text-white`} onPointerDown={(e) => { e.preventDefault(); engineRef.current?.cycleWeapon(); }} aria-label="Trocar arma">
          <Repeat className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
}

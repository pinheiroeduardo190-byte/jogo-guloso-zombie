import {
  Shield, Swords, Zap, Crosshair, Ghost, Target, Orbit, CloudLightning,
  Droplets, HeartPulse, Wind, Magnet, Package, Sparkles,
} from "lucide-react";

export function AbilityIcon({ icon, className = "h-5 w-5" }: { icon: string; className?: string }) {
  switch (icon) {
    case "shield": return <Shield className={className} />;
    case "swords": return <Swords className={className} />;
    case "zap": return <Zap className={className} />;
    case "crosshair": return <Crosshair className={className} />;
    case "ghost": return <Ghost className={className} />;
    case "target": return <Target className={className} />;
    case "nova": return <Orbit className={className} />;
    case "storm": return <CloudLightning className={className} />;
    case "vampire": return <Droplets className={className} />;
    case "heart": return <HeartPulse className={className} />;
    case "boots": return <Wind className={className} />;
    case "magnet": return <Magnet className={className} />;
    case "package": return <Package className={className} />;
    default: return <Sparkles className={className} />;
  }
}

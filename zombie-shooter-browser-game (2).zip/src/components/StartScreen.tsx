import { useState } from "react";
import { Play, Volume2, VolumeX, Crosshair, Move, MousePointer2, Zap, Skull, ChevronRight, Info, User, Users, Lock, Mic, MicOff, Snowflake, Plane, Castle } from "lucide-react";
import type { GameMode, HighScore } from "../game/scores";
import { PLAY_MODES, duoUnavailableMessage } from "../game/online";
import { MAP_LIST, type MapId } from "../game/maps";
import { HighScoreTable } from "./HighScoreTable";
import menuBg from "../assets/menu-bg.jpg";

interface Props {
  scores: HighScore[];
  mode: GameMode;
  muted: boolean;
  voiceOn: boolean;
  mapId: MapId;
  onToggleMute: () => void;
  onToggleVoice: () => void;
  onSelectMap: (id: MapId) => void;
  onStart: () => void;
  onScoresChange: (scores: HighScore[]) => void;
  isTouch: boolean;
}

const MAP_ICONS: Record<MapId, typeof Snowflake> = { subzero: Snowflake, terminal: Plane, fortaleza: Castle };

export function StartScreen({ scores, mode, muted, voiceOn, mapId, onToggleMute, onToggleVoice, onSelectMap, onStart, onScoresChange, isTouch }: Props) {
  const [tab, setTab] = useState<"play" | "help" | "scores">("play");
  const [duoMsg, setDuoMsg] = useState(false);

  return (
    <div className="absolute inset-0 z-30 overflow-hidden bg-black grain scanlines">
      {/* bg */}
      <div className="absolute inset-0">
        <img src={menuBg} alt="" className="h-full w-full object-cover opacity-55 fog-drift scale-110" draggable={false} />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/35 to-black" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_20%,rgba(0,0,0,0.75)_100%)]" />
        <div className="absolute inset-0 bg-green-950/20 mix-blend-overlay" />
      </div>

      <div className="relative z-10 flex h-full flex-col overflow-y-auto">
        {/* top bar */}
        <div className="flex items-center justify-between px-4 py-3 sm:px-8">
          <div className="flex items-center gap-2">
            <Skull className="h-5 w-5 text-red-600" />
            <span className="font-tech text-[11px] tracking-[0.3em] text-stone-400">T-GROUP // ARQUIVO 935</span>
          </div>
          <div className="flex gap-2">
            <button onClick={onToggleVoice} title={voiceOn ? "Voz do sargento ON" : "Voz do sargento OFF"} className={`flex items-center gap-1.5 rounded border px-2.5 py-2 font-tech text-[10px] tracking-[0.2em] backdrop-blur transition ${voiceOn ? "border-white/15 bg-white/5 text-stone-300 hover:bg-white/10" : "border-red-400/40 bg-red-950/50 text-red-300"}`} aria-label="Voz">
              {voiceOn ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
              <span className="hidden sm:inline">SARGENTO</span>
            </button>
            <button onClick={onToggleMute} className="rounded border border-white/15 bg-white/5 p-2 text-stone-300 backdrop-blur transition hover:bg-white/10" aria-label="Som">
              {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </button>
          </div>
        </div>

        <div className="mx-auto flex w-full max-w-5xl flex-1 flex-col items-center justify-center px-4 pb-10 pt-2 text-center">
          <div className="rise-in mb-2 flex items-center gap-3 font-tech text-[11px] tracking-[0.5em] text-red-500/90 sm:text-xs">
            <span className="h-px w-8 bg-red-800 sm:w-16" />
            FPS · SOBREVIVÊNCIA ZOMBIE EM PRIMEIRA PESSOA
            <span className="h-px w-8 bg-red-800 sm:w-16" />
          </div>

          <h1 className="font-display title-flicker text-stroke leading-[0.9] text-[15vw] text-stone-100 sm:text-8xl md:text-9xl">
            DEAD<span className="text-red-600">OPS</span>
          </h1>
          <div className="font-type mt-1 text-lg tracking-[0.45em] text-amber-100/90 sm:text-2xl">
            — NACHT DER UNTOTEN · 3D —
          </div>
          <p className="font-cond mt-3 max-w-2xl text-sm font-light tracking-wide text-stone-400 sm:text-base">
            Três mapas <span className="text-white font-semibold">em primeira pessoa</span>: laboratório congelado, aeroporto tomado e castelo cyber-gótico.
            Trave as <span className="text-green-300 font-semibold">janelas com tábuas</span>, ligue a{" "}
            <span className="text-yellow-300 font-semibold">energia</span>, use o{" "}
            <span className="text-emerald-300 font-semibold">Pack-a-Punch</span> e abra portas com o{" "}
            <span className="text-amber-300 font-semibold">dinheiro dos abates</span>. O sargento narra tudo com voz brutal. Sobreviva aos{" "}
            <span className="text-red-400 font-semibold">ROUNDS</span>.
          </p>

          {/* tabs */}
          <div className="mt-6 flex gap-1 rounded-sm border border-white/10 bg-black/60 p-1 backdrop-blur">
            {([["play", "JOGAR"], ["help", "COMO JOGAR"], ["scores", "RECORDES"]] as const).map(([k, label]) => (
              <button
                key={k}
                onClick={() => setTab(k)}
                className={`px-4 py-2 font-cond text-xs font-semibold tracking-[0.2em] transition sm:px-6 sm:text-sm ${tab === k ? "bg-red-700 text-white shadow-[0_0_18px_rgba(185,20,40,0.6)]" : "text-stone-400 hover:text-white"}`}
              >
                {label}
              </button>
            ))}
          </div>

          {tab === "play" && (
            <div className="rise-in mt-6 flex w-full max-w-3xl flex-col items-center">
              {/* seletor de mapa: 3 mapas do manual */}
              <div className="font-tech mb-2 text-[11px] tracking-[0.45em] text-stone-400">ESCOLHA O MAPA</div>
              <div className="mb-4 grid w-full gap-2 sm:grid-cols-3">
                {MAP_LIST.map((m) => {
                  const active = m.id === mapId;
                  const Icon = MAP_ICONS[m.id];
                  return (
                    <button
                      key={m.id}
                      onClick={() => onSelectMap(m.id)}
                      className={`btn-brutal border p-3 text-left transition ${active ? "bg-white/10" : "bg-black/60 hover:bg-white/5"}`}
                      style={{ borderColor: active ? m.accent : "rgba(255,255,255,0.12)", boxShadow: active ? `0 0 24px ${m.accent}44` : undefined }}
                    >
                      <Icon className="h-6 w-6" style={{ color: m.accent }} />
                      <div className="font-display mt-1 text-xl leading-none text-white">{m.name}</div>
                      <div className="font-tech text-[10px] tracking-[0.2em]" style={{ color: m.accent }}>{m.sub}</div>
                      <div className="font-cond mt-1.5 text-[11px] font-light leading-snug text-stone-400">{m.desc}</div>
                      <div className="font-tech mt-1.5 inline-block border border-white/15 px-1.5 py-0.5 text-[9px] tracking-[0.2em] text-stone-300">{m.difficulty}</div>
                      {active && <div className="font-tech mt-1 text-[10px] tracking-[0.3em]" style={{ color: m.accent }}>● SELECIONADO</div>}
                    </button>
                  );
                })}
              </div>
              {/* seletor de modo: single jogável / duo travado até o Firebase */}
              <div className="mb-4 grid w-full grid-cols-2 gap-2">
                {PLAY_MODES.map((m) => {
                  const active = m.id === mode;
                  const Icon = m.id === "single" ? User : Users;
                  return (
                    <button
                      key={m.id}
                      disabled={!m.available}
                      onClick={() => { if (!m.available) { setDuoMsg(true); window.setTimeout(() => setDuoMsg(false), 2800); } }}
                      className={`relative flex items-center gap-2 border px-3 py-2.5 text-left transition ${
                        active
                          ? "border-green-300/60 bg-green-950/40"
                          : m.available
                            ? "border-white/15 bg-black/60 hover:border-white/30"
                            : "cursor-not-allowed border-white/10 bg-black/50 opacity-70"
                      }`}
                    >
                      <Icon className={`h-5 w-5 shrink-0 ${active ? "text-green-300" : "text-stone-400"}`} />
                      <span>
                        <span className={`font-cond block text-sm font-bold tracking-[0.2em] ${active ? "text-white" : "text-stone-300"}`}>
                          {m.label}
                        </span>
                        <span className="font-tech block text-[9px] tracking-[0.15em] text-stone-500">{m.hint}</span>
                      </span>
                      {!m.available && <Lock className="absolute right-2 top-2 h-3.5 w-3.5 text-stone-500" />}
                    </button>
                  );
                })}
              </div>
              {duoMsg && (
                <div className="font-tech mb-3 w-full border border-amber-300/30 bg-amber-950/40 px-3 py-2 text-[11px] leading-relaxed tracking-wider text-amber-100">
                  {duoUnavailableMessage()}
                </div>
              )}
              <button
                onClick={onStart}
                className="btn-brutal group flex items-center gap-3 bg-red-700 px-10 py-4 font-display text-2xl tracking-wider text-white shadow-[0_0_40px_rgba(185,20,40,0.55)] sm:px-14 sm:text-3xl"
              >
                <Play className="h-7 w-7 fill-current transition group-hover:scale-125" />
                DEPLOY
              </button>
              <div className="font-tech mt-3 text-[11px] tracking-[0.25em] text-stone-500">
                {isTouch ? "TOQUE PARA ENTRAR EM COMBATE" : "PRESSIONE ENTER PARA ENTRAR EM COMBATE"}
              </div>
              {/* weapon strip */}
              <div className="mt-6 grid w-full grid-cols-2 gap-2 sm:grid-cols-4">
                {[
                  ["M1911", "INICIAL", "#9aa0a6"],
                  ["MP5K", "1000 PTS", "#57c8ff"],
                  ["AK-47", "2500 PTS", "#ffa14f"],
                  ["RAY GUN", "5000 PTS", "#5dff8d"],
                ].map(([n, p, c]) => (
                  <div key={n} className="border border-white/10 bg-black/60 px-2 py-3 backdrop-blur">
                    <Crosshair className="mx-auto h-5 w-5" style={{ color: c }} />
                    <div className="font-cond mt-1 text-sm font-bold tracking-widest text-stone-100">{n}</div>
                    <div className="font-tech text-[10px] tracking-widest" style={{ color: c }}>{p}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === "help" && (
            <div className="rise-in mt-6 grid w-full max-w-3xl gap-2 text-left sm:grid-cols-2">
              {isTouch ? (
                <>
                  <HelpCard icon={<Move className="h-5 w-5" />} title="ANALÓGICO — MOVER" desc="Empurre até a borda para correr. Arraste o lado direito da tela para olhar. Setas = pular e agachar." />
                  <HelpCard icon={<Crosshair className="h-5 w-5" />} title="FOGO + FACA" desc="Segure FOGO para atirar (mira gruda sozinha). Botão de faca = 150 de dano de perto. Dá pra pular por cima do zumbi!" />
                  <HelpCard icon={<Zap className="h-5 w-5" />} title="BOTÕES TÁTICOS" desc="Mão = comprar na parede, seta = recarregar, trocar = segunda arma, luneta = mira de precisão." />
                  <HelpCard icon={<Skull className="h-5 w-5" />} title="DICA DE SOBREVIVÊNCIA" desc="Mire na CABEÇA para HEADSHOT (+150). Guarde pontos para a AK-47 e não fique encurralado." />
                </>
              ) : (
                <>
                  <HelpCard icon={<Move className="h-5 w-5" />} title="WASD — MOVER · SHIFT — CORRER / AGACHAR" desc="SHIFT + W corre. SHIFT parado, C ou CTRL agacha (mais preciso). ESPAÇO pula — dá pra pular por cima do zumbi! ESC pausa." />
                  <HelpCard icon={<MousePointer2 className="h-5 w-5" />} title="CLIQUE ATIRA · DIREITO = FACADA 150" desc="Toque rápido no botão direito = facada mortal (V também). SEGURE o direito p/ mira de precisão. Headshot na cabeça." />
                  <HelpCard icon={<Zap className="h-5 w-5" />} title="F = CONSERTA · ENERGIA · PACK · PORTA · COMPRA" desc="F faz tudo: reconstrói tábua (+60 $), liga geradores, ativa relés, usa Pack-a-Punch (3500 $, +45% dano, precisa de energia), compra perks, abre portas e compra armas." />
                  <HelpCard icon={<Skull className="h-5 w-5" />} title="DINHEIRO · XP · SARGENTO" desc="Kill +100 $, headshot +150 $. Abates dão XP e mutações. Drops: Max Ammo, Insta-Kill, 2X e Nuke. O sargento narra tudo com voz brutal (botão MIC desliga)." />
                </>
              )}
              <div className="col-span-full mt-1 flex items-start gap-2 border border-amber-200/20 bg-amber-950/30 p-3 text-amber-100/90">
                <Info className="mt-0.5 h-4 w-4 shrink-0" />
                <p className="font-cond text-xs font-light leading-relaxed sm:text-sm">
                  Estratégia BO1: faça pontos nos rounds 1–3 com a pistola (tire no peito e finalize na faca mental — aqui, cada acerto conta).
                  Abra a MP5K primeiro, depois junte para a AK. A Ray Gun derrete Brutes. Vida regenera longe do perigo.
                </p>
              </div>
            </div>
          )}

          {tab === "scores" && (
            <div className="rise-in mt-6 w-full max-w-xl">
              <HighScoreTable scores={scores} compact mode={mode} onCleared={onScoresChange} />
              <p className="font-tech mt-2 text-[10px] tracking-[0.2em] text-stone-600">
                RANKING LOCAL E REAL · O ONLINE (FIREBASE) VALERÁ P/ SINGLE E 2 JOGADORES
              </p>
            </div>
          )}

          <button onClick={onStart} className="group mt-6 hidden items-center gap-1 font-tech text-xs tracking-[0.3em] text-stone-500 transition hover:text-white sm:flex">
            PULAR INTRO <ChevronRight className="h-4 w-4 transition group-hover:translate-x-1" />
          </button>
        </div>

        <div className="relative z-10 flex items-center justify-center gap-4 border-t border-white/10 bg-black/70 px-4 py-2 font-tech text-[10px] tracking-[0.25em] text-stone-500">
          <span>FAN TRIBUTE · INSPIRADO EM BO1 ZOMBIES</span>
          <span className="hidden sm:inline">·</span>
          <span className="hidden items-center gap-1 sm:flex"><span className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-green-500" /> 60 FPS</span>
        </div>
      </div>
    </div>
  );
}

function HelpCard({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="flex gap-3 border border-white/10 bg-black/60 p-3 backdrop-blur">
      <div className="flex h-9 w-9 shrink-0 items-center justify-center bg-red-800/80 text-white">{icon}</div>
      <div>
        <div className="font-cond text-sm font-bold tracking-widest text-stone-100">{title}</div>
        <div className="font-cond text-xs font-light leading-snug text-stone-400">{desc}</div>
      </div>
    </div>
  );
}

import { useState } from "react";
import { Skull, RotateCcw, Home, Trophy, Crosshair, Target, Clock, Coins } from "lucide-react";
import type { GameStats } from "../game/engine";
import type { GameMode, HighScore } from "../game/scores";
import { qualifies, MODE_LABEL } from "../game/scores";
import { formatTime } from "../game/scores";
import { HighScoreTable } from "./HighScoreTable";

interface Props {
  stats: GameStats;
  scores: HighScore[];
  mode: GameMode;
  onRestart: () => void;
  onQuit: () => void;
  onSaveScore: (name: string) => number; // returns highlight index
  savedIndex: number;
  onScoresChange?: (scores: HighScore[]) => void;
}

export function GameOverScreen({ stats, scores, mode, onRestart, onQuit, onSaveScore, savedIndex, onScoresChange }: Props) {
  const [name, setName] = useState("");
  const isRecord = qualifies(scores, stats.score) && savedIndex < 0;

  const submit = () => {
    const n = (name.trim() || "SOBREVIVENTE").toUpperCase().slice(0, 12);
    onSaveScore(n);
  };

  return (
    <div className="absolute inset-0 z-30 overflow-y-auto bg-black/85 backdrop-blur-[3px] grain scanlines">
      <div className="mx-auto flex min-h-full w-full max-w-2xl flex-col items-center justify-center px-4 py-8 text-center">
        <div className="rise-in flex h-20 w-20 items-center justify-center rounded-full border-4 border-red-800 bg-red-950/60 shadow-[0_0_50px_rgba(185,20,40,0.5)]">
          <Skull className="h-10 w-10 text-red-500" />
        </div>
        <div className="font-tech mt-3 text-[11px] tracking-[0.5em] text-red-500">SINAL VITAL PERDIDO · {MODE_LABEL[mode]}</div>
        <h2 className="font-display text-stroke text-6xl text-red-600 sm:text-7xl">GAME OVER</h2>
        <p className="font-type mt-1 text-stone-400">“Você lutou bem, soldado. Eles eram muitos.”</p>

        {/* stats */}
        <div className="rise-in mt-5 grid w-full grid-cols-2 gap-2 sm:grid-cols-4">
          <Stat icon={<Trophy className="h-4 w-4" />} label="PONTUAÇÃO" value={stats.score.toLocaleString("pt-BR")} big />
          <Stat icon={<Skull className="h-4 w-4" />} label="ROUND" value={String(stats.round).padStart(2, "0")} big />
          <Stat icon={<Crosshair className="h-4 w-4" />} label="KILLS" value={String(stats.kills)} />
          <Stat icon={<Target className="h-4 w-4" />} label="HEADSHOTS" value={String(stats.headshots)} />
          <Stat icon={<Coins className="h-4 w-4" />} label="PONTOS FINAIS" value={stats.points.toLocaleString("pt-BR")} />
          <Stat icon={<Crosshair className="h-4 w-4" />} label="PRECISÃO" value={`${stats.shots ? Math.round((stats.hits / stats.shots) * 100) : 0}%`} />
          <Stat icon={<Clock className="h-4 w-4" />} label="TEMPO" value={formatTime(stats.time)} />
          <Stat icon={<Skull className="h-4 w-4" />} label="NÍVEL" value={String(stats.level)} big />
        </div>

        {isRecord ? (
          <div className="rise-in mt-4 w-full border border-amber-300/40 bg-amber-950/30 p-4">
            <div className="font-cond text-sm font-bold tracking-[0.3em] text-amber-200">★ NOVO RECORDE ★</div>
            <div className="mt-2 flex gap-2">
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") submit(); }}
                placeholder="SEU NOME DE GUERRA"
                maxLength={12}
                autoFocus
                className="font-tech min-w-0 flex-1 border border-white/20 bg-black/70 px-3 py-2.5 text-sm tracking-[0.2em] text-white placeholder:text-stone-600 focus:border-amber-300 focus:outline-none"
              />
              <button onClick={submit} className="btn-brutal bg-amber-500 px-5 py-2.5 font-display text-lg text-black">SALVAR</button>
            </div>
          </div>
        ) : (
          <div className="mt-4 w-full">
            <HighScoreTable scores={scores} compact highlight={savedIndex} mode={mode} onCleared={onScoresChange} />
          </div>
        )}

        <div className="mt-5 flex w-full flex-col gap-2 sm:flex-row">
          <button onClick={onRestart} className="btn-brutal flex flex-1 items-center justify-center gap-2 bg-red-700 px-6 py-3.5 font-display text-xl tracking-wider text-white shadow-[0_0_30px_rgba(185,20,40,0.5)]">
            <RotateCcw className="h-5 w-5" /> JOGAR DE NOVO
          </button>
          <button onClick={onQuit} className="btn-brutal flex items-center justify-center gap-2 border border-white/15 bg-white/5 px-6 py-3.5 font-cond text-sm font-bold tracking-[0.2em] text-stone-200 hover:bg-white/10">
            <Home className="h-4 w-4" /> MENU
          </button>
        </div>
        <div className="font-tech mt-2 text-[10px] tracking-[0.3em] text-stone-600">PRESSIONE R OU ENTER PARA REINICIAR INSTANTANEAMENTE</div>
      </div>
    </div>
  );
}

function Stat({ icon, label, value, big = false }: { icon: React.ReactNode; label: string; value: string; big?: boolean }) {
  return (
    <div className={`border px-2 py-2.5 ${big ? "border-red-800/50 bg-red-950/30" : "border-white/10 bg-black/60"}`}>
      <div className="flex items-center justify-center gap-1 font-tech text-[9px] tracking-[0.25em] text-stone-500">{icon}{label}</div>
      <div className={`font-display mt-0.5 leading-none ${big ? "text-2xl text-white sm:text-3xl" : "text-xl text-stone-100"}`}>{value}</div>
    </div>
  );
}

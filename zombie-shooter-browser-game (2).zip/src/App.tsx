import { useCallback, useEffect, useRef, useState } from "react";
import { ZombieEngine, type GameStats } from "./game/fpsEngine";
import { sound } from "./game/audio";
import { voice } from "./game/voice";
import { type MapId } from "./game/maps";
import { loadScores, saveScore, type GameMode, type HighScore } from "./game/scores";
import type { Choice } from "./game/abilities";
import { StartScreen } from "./components/StartScreen";
import { HUD } from "./components/HUD";
import { PauseOverlay } from "./components/PauseOverlay";
import { GameOverScreen } from "./components/GameOverScreen";
import { TouchControls } from "./components/TouchControls";
import { LevelUpOverlay } from "./components/LevelUpOverlay";

type Screen = "menu" | "playing" | "paused" | "gameover";

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<ZombieEngine | null>(null);
  const [screen, setScreen] = useState<Screen>("menu");
  const screenRef = useRef<Screen>("menu");
  screenRef.current = screen;
  const [stats, setStats] = useState<GameStats | null>(null);
  const [playMode] = useState<GameMode>("single");
  const [mapId, setMapId] = useState<MapId>("subzero");
  const mapRef = useRef<MapId>("subzero");
  mapRef.current = mapId;
  const [scores, setScores] = useState<HighScore[]>(() => loadScores("single"));
  const [savedIndex, setSavedIndex] = useState(-1);
  const [muted, setMuted] = useState(sound.muted);
  const [voiceOn, setVoiceOn] = useState(voice.enabled);
  const [levelChoices, setLevelChoices] = useState<Choice[] | null>(null);
  const [isTouch] = useState(() => "ontouchstart" in window || navigator.maxTouchPoints > 0);

  const handleGameOver = useCallback((s: GameStats) => {
    setStats(s);
    setScores(loadScores("single"));
    setSavedIndex(-1);
    setLevelChoices(null);
    setScreen("gameover");
  }, []);

  useEffect(() => {
    if (!canvasRef.current || engineRef.current) return;
    const engine = new ZombieEngine(canvasRef.current, handleGameOver, mapRef.current);
    engine.onPauseKey = () => {
      if (engine.isLevelUpOpen()) return;
      const sc = screenRef.current;
      if (sc === "playing") {
        engine.pause();
        setScreen("paused");
      } else if (sc === "paused") {
        engine.resume();
        setScreen("playing");
      }
    };
    engine.onLockLost = () => {
      if (screenRef.current === "playing" && !engine.isLevelUpOpen()) setScreen("paused");
    };
    engine.onLevelUp = (choices) => {
      setLevelChoices(choices ? [...choices] : null);
    };
    engineRef.current = engine;
    const onVis = () => {
      const eng = engineRef.current;
      if (document.hidden && screenRef.current === "playing" && eng && !eng.isLevelUpOpen()) {
        eng.pause();
        setScreen("paused");
      }
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [handleGameOver]);

  useEffect(() => {
    return () => { engineRef.current?.destroy(); engineRef.current = null; };
  }, []);

  const ensureEngineForMap = useCallback(() => {
    const want = mapRef.current;
    const cur = engineRef.current;
    if (cur && cur.mapId === want) return cur;
    if (cur) cur.destroy();
    engineRef.current = null;
    if (!canvasRef.current) return null;
    const engine = new ZombieEngine(canvasRef.current, handleGameOver, want);
    engine.onPauseKey = () => {
      if (engine.isLevelUpOpen()) return;
      const sc = screenRef.current;
      if (sc === "playing") {
        engine.pause();
        setScreen("paused");
      } else if (sc === "paused") {
        engine.resume();
        setScreen("playing");
      }
    };
    engine.onLockLost = () => {
      if (screenRef.current === "playing" && !engine.isLevelUpOpen()) setScreen("paused");
    };
    engine.onLevelUp = (choices) => {
      setLevelChoices(choices ? [...choices] : null);
    };
    engineRef.current = engine;
    return engine;
  }, [handleGameOver]);

  const startGame = useCallback(() => {
    sound.ensure();
    sound.ui();
    setSavedIndex(-1);
    setStats(null);
    setLevelChoices(null);
    setScreen("playing");
    requestAnimationFrame(() => ensureEngineForMap()?.start());
  }, [ensureEngineForMap]);

  const pauseGame = useCallback(() => {
    if (engineRef.current?.isLevelUpOpen()) return;
    sound.ui();
    engineRef.current?.pause();
    setScreen("paused");
  }, []);

  const resumeGame = useCallback(() => {
    sound.ensure(); sound.ui();
    setScreen("playing");
    requestAnimationFrame(() => engineRef.current?.resume());
  }, []);

  const restartGame = useCallback(() => {
    sound.ensure(); sound.ui();
    setSavedIndex(-1);
    setStats(null);
    setLevelChoices(null);
    setScreen("playing");
    requestAnimationFrame(() => ensureEngineForMap()?.start());
  }, [ensureEngineForMap]);

  const quitToMenu = useCallback(() => {
    sound.ui();
    engineRef.current?.pause();
    setLevelChoices(null);
    setScores(loadScores("single"));
    setScreen("menu");
  }, []);

  const toggleMute = useCallback(() => {
    sound.ensure();
    const m = !sound.muted;
    sound.setMuted(m);
    setMuted(m);
  }, []);

  const toggleVoice = useCallback(() => {
    const v = !voice.enabled;
    voice.setEnabled(v);
    setVoiceOn(v);
    if (v) voice.say("Sargento na escuta. Voz brutal ativada.", true);
  }, []);

  const selectMap = useCallback((id: MapId) => {
    sound.ensure(); sound.ui();
    setMapId(id);
    setScores(loadScores("single"));
  }, []);

  const handleSaveScore = useCallback((name: string): number => {
    if (!stats) return -1;
    const top = saveScore({
      name,
      score: stats.score,
      round: stats.round,
      kills: stats.kills,
      level: stats.level,
      mode: playMode,
      date: new Date().toLocaleDateString("pt-BR"),
    });
    setScores(top);
    const clean = (name.trim() || "SOBREVIVENTE").toUpperCase().slice(0, 12);
    const idx = top.findIndex((s) => s.name === clean && s.score === Math.floor(stats.score));
    setSavedIndex(idx);
    sound.buy();
    return idx;
  }, [stats, playMode]);

  const handlePickUpgrade = useCallback((id: string) => {
    sound.ensure();
    engineRef.current?.chooseUpgrade(id);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const sc = screenRef.current;
      if (sc === "menu" && (e.key === "Enter" || e.key === " ")) {
        e.preventDefault();
        startGame();
      } else if (sc === "gameover" && (e.key === "r" || e.key === "R" || e.key === "Enter")) {
        if ((e.target as HTMLElement)?.tagName === "INPUT") return;
        e.preventDefault();
        restartGame();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [startGame, restartGame]);

  return (
    <div className="fixed inset-0 h-[100dvh] w-screen overflow-hidden bg-black">
      <div className="absolute inset-0" style={{ touchAction: "none" }}>
        <canvas ref={canvasRef} className="h-full w-full cursor-none" style={{ touchAction: "none" }} />
      </div>

      {screen === "menu" && <div className="pointer-events-none absolute inset-0 bg-[#050705]" />}

      {(screen === "playing" || screen === "paused") && (
        <HUD engineRef={engineRef} muted={muted} voiceOn={voiceOn} onPause={pauseGame} onToggleMute={toggleMute} onToggleVoice={toggleVoice} mapId={mapId} />
      )}

      {screen === "playing" && isTouch && !levelChoices && <TouchControls engineRef={engineRef} />}

      {screen === "playing" && levelChoices && (
        <LevelUpOverlay
          choices={levelChoices}
          level={engineRef.current?.level ?? 1}
          onPick={handlePickUpgrade}
        />
      )}

      {screen === "menu" && (
        <StartScreen scores={scores} mode={playMode} muted={muted} voiceOn={voiceOn} mapId={mapId} onToggleMute={toggleMute} onToggleVoice={toggleVoice} onSelectMap={selectMap} onStart={startGame} onScoresChange={setScores} isTouch={isTouch} />
      )}
      {screen === "paused" && (
        <PauseOverlay muted={muted} onResume={resumeGame} onRestart={restartGame} onQuit={quitToMenu} onToggleMute={toggleMute} />
      )}
      {screen === "gameover" && stats && (
        <GameOverScreen stats={stats} scores={scores} mode={playMode} onRestart={restartGame} onQuit={quitToMenu} onSaveScore={handleSaveScore} savedIndex={savedIndex} onScoresChange={setScores} />
      )}
    </div>
  );
}

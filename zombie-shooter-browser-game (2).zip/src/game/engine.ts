/* ============================================================
   DEAD OPS — Zombie survival engine (top-down, COD BO1 homage)
   Canvas 2D, 60fps, pooled particles, procedural everything.
   ============================================================ */
import { sound } from "./audio";
import {
  ABILITIES, rollChoices, xpNeedForLevel, fieldParams, bladeParams, novaParams, thunderParams,
  RAPID_MULT, DMG_MULT, PIERCE_N, CRIT_CH, CRIT_MULT, BOOTS_MULT, MAGNET_R, MAGNET_XP,
  REGEN_MAX, REGEN_RATE, VAMP_KILL, VAMP_HIT,
  type Choice,
} from "./abilities";

export interface HudWeapon { short: string; mag: number; reserve: number; active: boolean; }
export interface NearBuy { label: string; price: number; can: boolean; hint: string; }
export interface HudSnapshot {
  hp: number; maxHp: number; points: number; score: number; round: number;
  zombiesLeft: number; alive: number; kills: number; headshots: number;
  shots: number; hits: number; accuracy: number; gameTime: number;
  weaponName: string; weaponShort: string; mag: number; reserve: number; magSize: number;
  reloading: boolean; reloadPct: number; weapons: HudWeapon[];
  doubleT: number; instaT: number; banner: string; bannerSub: string; bannerT: number;
  nearBuy: NearBuy | null; intermission: number; lowHp: boolean; recentHit: number;
  nukeFlash: number; dying: number; fps: number;
  level: number; xp: number; xpNeed: number; abilities: AbilityHud[];
}
export interface AbilityHud { id: string; name: string; level: number; color: string; icon: string; }
export interface GameStats { score: number; points: number; round: number; kills: number; headshots: number; shots: number; hits: number; time: number; level: number; }

interface WeaponDef {
  id: string; name: string; short: string; damage: number; headMult: number;
  interval: number; magSize: number; startReserve: number; maxReserve: number;
  reloadTime: number; spread: number; range: number; auto: boolean;
  price: number; ammoPrice: number; kick: number; tracer: string; aoe: number;
}
const WEAPONS: Record<string, WeaponDef> = {
  m1911: { id: "m1911", name: "M1911 Pistola", short: "M1911", damage: 46, headMult: 2.2, interval: 0.24, magSize: 8, startReserve: 96, maxReserve: 160, reloadTime: 1.05, spread: 0.022, range: 760, auto: true, price: 0, ammoPrice: 300, kick: 0.1, tracer: "#ffd37a", aoe: 0 },
  mp5k: { id: "mp5k", name: "MP5K", short: "MP5K", damage: 32, headMult: 1.9, interval: 0.092, magSize: 30, startReserve: 150, maxReserve: 300, reloadTime: 1.6, spread: 0.05, range: 700, auto: true, price: 1000, ammoPrice: 500, kick: 0.055, tracer: "#9adcff", aoe: 0 },
  ak47: { id: "ak47", name: "AK-47", short: "AK47", damage: 60, headMult: 2.0, interval: 0.132, magSize: 30, startReserve: 120, maxReserve: 270, reloadTime: 1.9, spread: 0.03, range: 860, auto: true, price: 2500, ammoPrice: 1000, kick: 0.09, tracer: "#ffb066", aoe: 0 },
  raygun: { id: "raygun", name: "Ray Gun MK-II", short: "RAY", damage: 230, headMult: 1.6, interval: 0.34, magSize: 20, startReserve: 80, maxReserve: 160, reloadTime: 2.0, spread: 0.008, range: 950, auto: true, price: 5000, ammoPrice: 2000, kick: 0.22, tracer: "#7dff9a", aoe: 110 },
};

interface Owned { defId: string; mag: number; reserve: number; }
interface Zombie {
  id: number; x: number; y: number; vx: number; vy: number;
  hp: number; maxHp: number; speed: number; radius: number; damage: number;
  atk: number; spawnT: number; deathT: number; dead: boolean; wob: number;
  type: "walker" | "runner" | "brute"; flash: number; lunge: number; groan: number; deadRot: number;
  bladeCd?: number; slowT?: number; slowMult?: number;
}
interface Particle { x: number; y: number; vx: number; vy: number; life: number; max: number; size: number; color: string; kind: number; drag: number; grav: number; }
interface Tracer { x1: number; y1: number; x2: number; y2: number; life: number; max: number; color: string; w: number; }
interface FloatText { x: number; y: number; life: number; max: number; text: string; color: string; size: number; }
interface Decal { x: number; y: number; r: number; rot: number; a: number; }
interface Drop { id: number; x: number; y: number; type: "max" | "insta" | "double" | "nuke"; t: number; }
interface BuyStation { weaponId: string; x: number; y: number; label: string; color: string; }
interface Hitmark { life: number; max: number; kill: boolean; head: boolean; }

const MAP_W = 2200, MAP_H = 1500;
const TAU = Math.PI * 2;
const rand = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => v < a ? a : v > b ? b : v;
const dist2 = (ax: number, ay: number, bx: number, by: number) => { const dx = bx - ax, dy = by - ay; return dx * dx + dy * dy; };

export class ZombieEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private onGameOver: (s: GameStats) => void;
  private raf = 0;
  private running = false;
  paused = false;
  private destroyed = false;
  private last = 0;
  private time = 0;
  private fps = 60;
  private fpsAcc = 0; private fpsN = 0; private fpsT = 0;

  // view
  private vw = 0; private vh = 0; private dpr = 1;
  private camX = 0; private camY = 0;
  private trauma = 0; private shakeX = 0; private shakeY = 0;
  private vignette: CanvasGradient | null = null;
  private ground: HTMLCanvasElement | null = null;

  // input
  private keys = new Set<string>();
  private mouseX = 0; private mouseY = 0; private mouseDown = false;
  private semiLatch = false;
  private touchMove = { x: 0, y: 0 };
  private touchAimActive = false; private touchAimAngle = 0; private touchFiring = false;
  isTouch = false;

  // player
  private px = MAP_W / 2; private py = MAP_H / 2;
  private pvx = 0; private pvy = 0; private aim = -Math.PI / 2;
  private hp = 150; private maxHp = 150; private lastDmg = -99;
  private weapons: Owned[] = [{ defId: "m1911", mag: 8, reserve: 96 }];
  private cur = 0; private fireCd = 0; private reloadT = 0; private reloading = false;
  private muzzle = 0; private recentHit = 0; private dying = 0; private deadDone = false;
  private crossKick = 0;

  // rounds
  private round = 1; private queue = 0; private spawnT = 0; private spawnInterval = 1;
  private intermission = 0; private banner = ""; private bannerSub = ""; private bannerT = 0;
  private zid = 1;

  // entities
  private zombies: Zombie[] = [];
  private parts: Particle[] = [];
  private tracers: Tracer[] = [];
  private texts: FloatText[] = [];
  private decals: Decal[] = [];
  private drops: Drop[] = [];
  private hitmarks: Hitmark[] = [];
  private dropId = 1;

  // powerups & score
  private doubleT = 0; private instaT = 0; private nukeFlash = 0;
  private points = 500; private earned = 500; private kills = 0; private heads = 0; private shots = 0; private hits = 0;

  // xp & abilities
  level = 1; private xp = 0; private xpNeed = xpNeedForLevel(1);
  private abilityLevels: Record<string, number> = {};
  private pendingLevels = 0;
  private currentChoices: Choice[] | null = null;
  private bladeAngle = 0; private novaT = 0; private thunderT = 0;
  onLevelUp: ((c: Choice[] | null) => void) | null = null;

  isLevelUpOpen() { return this.currentChoices !== null; }

  private obstacles: { x: number; y: number; w: number; h: number }[] = [];
  private stations: BuyStation[] = [];
  private spawns: { x: number; y: number }[] = [];
  private fogs: { x: number; y: number; r: number; s: number; a: number }[] = [];

  constructor(canvas: HTMLCanvasElement, onGameOver: (s: GameStats) => void) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) throw new Error("no 2d context");
    this.ctx = ctx;
    this.onGameOver = onGameOver;
    this.buildMap();
    this.buildGround();
    this.resize();
    this.attach();
  }

  /* ---------------- setup ---------------- */
  private buildMap() {
    const cx = MAP_W / 2, cy = MAP_H / 2;
    this.obstacles = [
      { x: cx - 320, y: cy - 260, w: 200, h: 120 },
      { x: cx + 120, y: cy - 260, w: 200, h: 120 },
      { x: cx - 320, y: cy + 140, w: 200, h: 120 },
      { x: cx + 120, y: cy + 140, w: 200, h: 120 },
      { x: cx - 70, y: cy - 80, w: 140, h: 160 },   // center stage block
      { x: 180, y: 220, w: 220, h: 110 },
      { x: MAP_W - 400, y: 220, w: 220, h: 110 },
      { x: 180, y: MAP_H - 330, w: 220, h: 110 },
      { x: MAP_W - 400, y: MAP_H - 330, w: 220, h: 110 },
      { x: 120, y: cy - 90, w: 90, h: 180 },
      { x: MAP_W - 210, y: cy - 90, w: 90, h: 180 },
    ];
    this.stations = [
      { weaponId: "mp5k", x: 340, y: 430, label: "MP5K", color: "#57c8ff" },
      { weaponId: "ak47", x: cx, y: 150, label: "AK-47", color: "#ffa14f" },
      { weaponId: "raygun", x: MAP_W - 340, y: 430, label: "RAY GUN", color: "#5dff8d" },
      { weaponId: "mp5k", x: 340, y: MAP_H - 300, label: "MP5K", color: "#57c8ff" },
      { weaponId: "ak47", x: MAP_W - 340, y: MAP_H - 300, label: "AK-47", color: "#ffa14f" },
    ];
    this.spawns = [
      { x: 60, y: 60 }, { x: MAP_W - 60, y: 60 }, { x: 60, y: MAP_H - 60 }, { x: MAP_W - 60, y: MAP_H - 60 },
      { x: MAP_W / 2, y: 50 }, { x: MAP_W / 2, y: MAP_H - 50 }, { x: 50, y: MAP_H / 2 }, { x: MAP_W - 50, y: MAP_H / 2 },
    ];
    this.fogs = Array.from({ length: 7 }, () => ({ x: rand(0, MAP_W), y: rand(0, MAP_H), r: rand(180, 420), s: rand(6, 20), a: rand(0.04, 0.09) }));
  }

  private buildGround() {
    const g = document.createElement("canvas");
    g.width = 1100; g.height = 750;
    const c = g.getContext("2d");
    if (!c) return;
    c.fillStyle = "#101310";
    c.fillRect(0, 0, 1100, 750);
    // concrete mottling
    for (let i = 0; i < 900; i++) {
      const x = Math.random() * 1100, y = Math.random() * 750, r = rand(2, 26);
      const v = Math.random();
      c.fillStyle = v < 0.5 ? `rgba(24,30,24,${rand(0.1, 0.35)})` : v < 0.8 ? `rgba(10,12,10,${rand(0.15, 0.4)})` : `rgba(46,58,44,${rand(0.05, 0.16)})`;
      c.beginPath(); c.ellipse(x, y, r, r * rand(0.4, 1), rand(0, 3), 0, TAU); c.fill();
    }
    // theater carpet: big worn oval + stage stripes
    c.save();
    c.translate(550, 375);
    c.fillStyle = "rgba(74,20,20,0.28)";
    c.beginPath(); c.ellipse(0, 0, 380, 260, 0, 0, TAU); c.fill();
    c.strokeStyle = "rgba(150,40,40,0.25)"; c.lineWidth = 6;
    c.beginPath(); c.ellipse(0, 0, 380, 260, 0, 0, TAU); c.stroke();
    c.strokeStyle = "rgba(120,110,80,0.12)"; c.lineWidth = 2;
    for (let i = -5; i <= 5; i++) { c.beginPath(); c.moveTo(i * 60, -240); c.lineTo(i * 60, 240); c.stroke(); }
    c.restore();
    // cracks
    c.strokeStyle = "rgba(0,0,0,0.5)"; c.lineWidth = 1.5;
    for (let i = 0; i < 40; i++) {
      let x = Math.random() * 1100, y = Math.random() * 750;
      c.beginPath(); c.moveTo(x, y);
      for (let s = 0; s < 5; s++) { x += rand(-40, 40); y += rand(-40, 40); c.lineTo(x, y); }
      c.stroke();
    }
    // scattered debris / papers
    for (let i = 0; i < 120; i++) {
      c.fillStyle = `rgba(${140 + rand(-30, 30)},${130 + rand(-30, 20)},${100 + rand(-20, 20)},${rand(0.05, 0.16)})`;
      c.save(); c.translate(Math.random() * 1100, Math.random() * 750); c.rotate(rand(0, 3));
      c.fillRect(0, 0, rand(3, 10), rand(2, 6)); c.restore();
    }
    this.ground = g;
  }

  private onResize = () => this.resize();
  private resize() {
    const parent = this.canvas.parentElement;
    const w = parent ? parent.clientWidth : window.innerWidth;
    const h = parent ? parent.clientHeight : window.innerHeight;
    this.dpr = clamp(window.devicePixelRatio || 1, 1, innerWidth < 820 ? 1.6 : 2);
    this.vw = w; this.vh = h;
    this.canvas.width = Math.round(w * this.dpr);
    this.canvas.height = Math.round(h * this.dpr);
    this.canvas.style.width = w + "px";
    this.canvas.style.height = h + "px";
    this.vignette = null;
  }

  private detachFns: (() => void)[] = [];
  private attach() {
    const cv = this.canvas;
    const keyDown = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(k)) e.preventDefault();
      this.keys.add(k);
      if (k === "r") this.reloadWeapon();
      if (k === "f" || k === "e") this.interact();
      if (k === "q" || k === "tab") { e.preventDefault(); this.cycleWeapon(); }
      if (k === "1") this.selectWeapon(0);
      if (k === "2") this.selectWeapon(1);
      if (k === "p" || k === "escape") this.onPauseKey?.();
    };
    const keyUp = (e: KeyboardEvent) => this.keys.delete(e.key.toLowerCase());
    const mouseMove = (e: MouseEvent) => {
      const r = cv.getBoundingClientRect();
      this.mouseX = e.clientX - r.left; this.mouseY = e.clientY - r.top;
    };
    const mouseDown = (e: MouseEvent) => {
      if (e.button !== 0) return;
      const t = e.target as HTMLElement | null;
      if (t && (t.closest("button") || t.closest("input"))) return; // ignore UI clicks
      this.mouseDown = true; sound.ensure();
    };
    const mouseUp = (e: MouseEvent) => { if (e.button === 0) { this.mouseDown = false; this.semiLatch = false; } };
    const wheel = (e: WheelEvent) => { e.preventDefault(); this.cycleWeapon(); };
    const ctxMenu = (e: Event) => e.preventDefault();
    const blur = () => { this.keys.clear(); this.mouseDown = false; };
    window.addEventListener("keydown", keyDown);
    window.addEventListener("keyup", keyUp);
    window.addEventListener("mousemove", mouseMove);
    window.addEventListener("mousedown", mouseDown);
    window.addEventListener("mouseup", mouseUp);
    cv.addEventListener("wheel", wheel, { passive: false });
    cv.addEventListener("contextmenu", ctxMenu);
    window.addEventListener("blur", blur);
    window.addEventListener("resize", this.onResize);
    this.detachFns = [
      () => window.removeEventListener("keydown", keyDown),
      () => window.removeEventListener("keyup", keyUp),
      () => window.removeEventListener("mousemove", mouseMove),
      () => window.removeEventListener("mousedown", mouseDown),
      () => window.removeEventListener("mouseup", mouseUp),
      () => cv.removeEventListener("wheel", wheel),
      () => cv.removeEventListener("contextmenu", ctxMenu),
      () => window.removeEventListener("blur", blur),
      () => window.removeEventListener("resize", this.onResize),
    ];
  }

  onPauseKey: (() => void) | null = null;

  /* ---------------- public control ---------------- */
  start() {
    sound.ensure(); sound.startAmbience();
    this.resetWorld();
    this.running = true; this.paused = false; this.destroyed = false;
    this.last = performance.now();
    cancelAnimationFrame(this.raf);
    this.raf = requestAnimationFrame(this.loop);
  }
  pause() { this.paused = true; }
  resume() {
    if (!this.running) return;
    this.paused = false;
    this.last = performance.now();
    cancelAnimationFrame(this.raf);
    this.raf = requestAnimationFrame(this.loop);
  }
  destroy() {
    this.destroyed = true; this.running = false;
    cancelAnimationFrame(this.raf);
    this.detachFns.forEach((f) => f());
  }
  setTouchMove(x: number, y: number) { this.touchMove.x = x; this.touchMove.y = y; if (x || y) this.isTouch = true; }
  setTouchAim(active: boolean, angle: number, firing: boolean) {
    this.touchAimActive = active; this.touchAimAngle = angle; this.touchFiring = firing;
    if (active) this.isTouch = true;
  }

  private resetWorld() {
    this.px = MAP_W / 2; this.py = MAP_H / 2 + 220; this.pvx = 0; this.pvy = 0;
    this.hp = this.maxHp; this.lastDmg = -99;
    this.weapons = [{ defId: "m1911", mag: 8, reserve: 96 }];
    this.cur = 0; this.fireCd = 0; this.reloadT = 0; this.reloading = false;
    this.zombies = []; this.parts = []; this.tracers = []; this.texts = []; this.decals = []; this.drops = []; this.hitmarks = [];
    this.points = 500; this.earned = 500; this.kills = 0; this.heads = 0; this.shots = 0; this.hits = 0;
    this.doubleT = 0; this.instaT = 0; this.nukeFlash = 0; this.trauma = 0;
    this.level = 1; this.xp = 0; this.xpNeed = xpNeedForLevel(1);
    this.abilityLevels = {}; this.pendingLevels = 0; this.currentChoices = null;
    this.bladeAngle = 0; this.novaT = 0; this.thunderT = 0;
    this.round = 0; this.intermission = 0; this.time = 0; this.dying = 0; this.deadDone = false;
    this.camX = this.px - this.vw / 2; this.camY = this.py - this.vh / 2;
    this.nextRound(true);
    // opening contact — two zombies rise close by so the action starts in ~2s
    this.spawnZombie(this.px + 430, this.py - 210);
    this.spawnZombie(this.px - 440, this.py + 190);
    this.queue = Math.max(0, this.queue - 2);
  }

  /* ---------------- gameplay actions ---------------- */
  private curDef(): WeaponDef { return WEAPONS[this.weapons[this.cur].defId]; }

  reloadWeapon() {
    if (this.dying > 0 || this.paused) return;
    const w = this.weapons[this.cur];
    const def = WEAPONS[w.defId];
    if (this.reloading || w.mag >= def.magSize || w.reserve <= 0) return;
    this.reloading = true; this.reloadT = def.reloadTime;
    sound.reload();
  }

  cycleWeapon() {
    if (this.weapons.length < 2 || this.reloading) return;
    this.cur = (this.cur + 1) % this.weapons.length;
    this.reloading = false; this.fireCd = Math.max(this.fireCd, 0.18);
    sound.wave();
  }
  selectWeapon(i: number) {
    if (i < this.weapons.length && i !== this.cur && !this.reloading) {
      this.cur = i; this.fireCd = Math.max(this.fireCd, 0.18); sound.wave();
    }
  }

  private nearestStation(): BuyStation | null {
    let best: BuyStation | null = null; let bd = 130 * 130;
    for (const s of this.stations) {
      const d = dist2(this.px, this.py, s.x, s.y);
      if (d < bd) { bd = d; best = s; }
    }
    return best;
  }

  interact() {
    if (this.dying > 0 || this.paused) return;
    const s = this.nearestStation();
    if (!s) return;
    const def = WEAPONS[s.weaponId];
    const ownedIdx = this.weapons.findIndex((w) => w.defId === s.weaponId);
    if (ownedIdx >= 0) {
      // buy ammo
      const w = this.weapons[ownedIdx];
      if (w.reserve >= def.maxReserve) { sound.deny(); this.addText(this.px, this.py - 30, "MUNIÇÃO CHEIA", "#9adcff", 15); return; }
      if (this.points < def.ammoPrice) { sound.deny(); this.addText(this.px, this.py - 30, "PONTOS INSUFICIENTES", "#ff5b5b", 15); return; }
      this.points -= def.ammoPrice;
      w.reserve = def.maxReserve;
      sound.buy(); this.addText(s.x, s.y - 40, "MUNIÇÃO MÁXIMA", "#9adcff", 17);
      this.burst(s.x, s.y, 14, "#9adcff", 160, 0.5);
    } else {
      if (this.points < def.price) { sound.deny(); this.addText(this.px, this.py - 30, `FALTAM ${def.price - this.points} PTS`, "#ff5b5b", 15); return; }
      this.points -= def.price;
      const nw: Owned = { defId: s.weaponId, mag: def.magSize, reserve: def.startReserve };
      if (this.weapons.length < 2) this.weapons.push(nw);
      else this.weapons[this.cur] = nw;
      this.cur = this.weapons.findIndex((w) => w.defId === s.weaponId);
      this.reloading = false;
      sound.buy(); this.addText(s.x, s.y - 40, def.name.toUpperCase(), def.id === "raygun" ? "#5dff8d" : "#ffd37a", 18);
      this.burst(s.x, s.y, 22, s.color, 220, 0.6);
      this.trauma = Math.min(1, this.trauma + 0.15);
    }
  }

  private addPoints(n: number, x?: number, y?: number, label?: string) {
    const mult = this.doubleT > 0 ? 2 : 1;
    const v = n * mult;
    this.points += v; this.earned += v;
    if (x !== undefined && label) this.addText(x, y ?? 0, label, "#ffe9a8", 14);
  }

  private addText(x: number, y: number, text: string, color: string, size: number) {
    if (this.texts.length > 40) this.texts.shift();
    this.texts.push({ x, y, life: 1, max: 1, text, color, size });
  }

  private burst(x: number, y: number, n: number, color: string, speed: number, life: number) {
    for (let i = 0; i < n; i++) {
      if (this.parts.length > 450) return;
      const a = rand(0, TAU), s = rand(speed * 0.2, speed);
      this.parts.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: rand(life * 0.5, life), max: life, size: rand(2, 5), color, kind: 0, drag: 3, grav: 0 });
    }
  }
  private blood(x: number, y: number, n: number, big = false) {
    for (let i = 0; i < n; i++) {
      if (this.parts.length > 450) return;
      const a = rand(0, TAU), s = rand(40, big ? 420 : 260);
      this.parts.push({
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        life: rand(0.3, 0.9), max: 0.9, size: rand(2, big ? 7 : 5),
        color: Math.random() < 0.25 ? "#7a0d0d" : Math.random() < 0.5 ? "#a31515" : "#d42a2a",
        kind: 0, drag: 2.5, grav: 0,
      });
    }
  }
  private spark(x: number, y: number, n: number, color = "#ffcf7a") {
    for (let i = 0; i < n; i++) {
      if (this.parts.length > 450) return;
      const a = rand(0, TAU), s = rand(80, 380);
      this.parts.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: rand(0.15, 0.4), max: 0.4, size: rand(1.5, 3), color, kind: 1, drag: 4, grav: 0 });
    }
  }

  /* ---------------- rounds ---------------- */
  private nextRound(first = false) {
    this.round++;
    this.queue = Math.min(6 + this.round * 5, 46);
    this.spawnInterval = Math.max(0.28, 1.05 - this.round * 0.07);
    this.spawnT = first ? 0.8 : 0.4;
    const subs = ["ELES ESTÃO VINDO...", "SEGURE A POSIÇÃO!", "NÃO DEIXE ELES CHEGAREM!", "SOBREVIVA.", "A NOITE PIORA..."];
    this.banner = `ROUND ${this.round}`;
    this.bannerSub = subs[Math.floor(Math.random() * subs.length)];
    this.bannerT = 3.2;
    sound.roundStart();
  }

  private spawnZombie(fx?: number, fy?: number) {
    // pick a spawn far from player when possible
    const cands = [...this.spawns].sort(() => Math.random() - 0.5);
    let sp = cands[0];
    for (const c of cands) {
      if (dist2(c.x, c.y, this.px, this.py) > 480 * 480) { sp = c; break; }
    }
    const sx = fx ?? sp.x + rand(-30, 30);
    const sy = fy ?? sp.y + rand(-30, 30);
    const r = Math.random();
    let type: Zombie["type"] = "walker";
    if (this.round >= 7 && r < 0.14) type = "brute";
    else if (this.round >= 4 && r < 0.38) type = "runner";
    const hpMul = 1 + (this.round - 1) * 0.24 + Math.pow(Math.max(0, this.round - 1), 1.6) * 0.035;
    const spMul = Math.min(1.65, 1 + (this.round - 1) * 0.045);
    let hp = 105 * hpMul, speed = rand(72, 105) * spMul, radius = 17, dmg = 16;
    if (type === "runner") { hp *= 0.55; speed = rand(165, 205) * Math.min(1.3, spMul); dmg = 11; radius = 14; }
    if (type === "brute") { hp *= 3.4; speed = rand(52, 66) * spMul; dmg = 34; radius = 25; }
    if (this.round === 1) hp = 100; // pistol: 3 body shots... 46dmg -> 3 hits. tight but fair
    this.zombies.push({
      id: this.zid++, x: sx, y: sy, vx: 0, vy: 0,
      hp, maxHp: hp, speed, radius, damage: dmg, atk: 0, spawnT: 1.1, deathT: 0,
      dead: false, wob: rand(0, TAU), type, flash: 0, lunge: 0, groan: rand(2, 8), deadRot: rand(0, TAU),
    });
    this.burst(sx, sy, 8, "#3a4436", 120, 0.6);
  }

  /* ---------------- shooting ---------------- */
  private tryFire(dt: number) {
    this.fireCd -= dt;
    const w = this.weapons[this.cur];
    const def = WEAPONS[w.defId];
    const wantFire = this.mouseDown || this.touchFiring;
    if (!wantFire) { this.semiLatch = false; return; }
    if (!def.auto && this.semiLatch) return;
    if (this.fireCd > 0 || this.reloading || this.dying > 0) return;
    if (w.mag <= 0) {
      sound.empty();
      this.fireCd = 0.25; this.semiLatch = true;
      this.reloadWeapon();
      return;
    }
    this.semiLatch = true;
    this.fireWeapon(w, def);
  }

  private rayWallT(ox: number, oy: number, dx: number, dy: number, range: number): number {
    let best = range;
    for (const o of this.obstacles) {
      // slab test
      let tmin = 0, tmax = best;
      if (Math.abs(dx) < 1e-8) { if (ox < o.x || ox > o.x + o.w) continue; }
      else {
        let t1 = (o.x - ox) / dx, t2 = (o.x + o.w - ox) / dx;
        if (t1 > t2) [t1, t2] = [t2, t1];
        tmin = Math.max(tmin, t1); tmax = Math.min(tmax, t2);
        if (tmin > tmax) continue;
      }
      if (Math.abs(dy) < 1e-8) { if (oy < o.y || oy > o.y + o.h) continue; }
      else {
        let t1 = (o.y - oy) / dy, t2 = (o.y + o.h - oy) / dy;
        if (t1 > t2) [t1, t2] = [t2, t1];
        tmin = Math.max(tmin, t1); tmax = Math.min(tmax, t2);
        if (tmin > tmax) continue;
      }
      if (tmin > 0 && tmin < best) best = tmin;
    }
    // map bounds
    if (dx > 0) best = Math.min(best, (MAP_W - ox) / dx);
    else if (dx < 0) best = Math.min(best, (0 - ox) / dx);
    if (dy > 0) best = Math.min(best, (MAP_H - oy) / dy);
    else if (dy < 0) best = Math.min(best, (0 - oy) / dy);
    return Math.max(0, best);
  }

  private fireWeapon(w: Owned, def: WeaponDef) {
    w.mag--; this.shots++;
    const rapidMult = RAPID_MULT[this.abilityLevels["rapid"] ?? 0] ?? 1;
    this.fireCd = def.interval * rapidMult; this.muzzle = 0.06;
    this.crossKick = Math.min(1, this.crossKick + def.kick * 3);
    let spread = def.spread * (this.isSprinting() ? 1.8 : 1);
    if (this.isTouch) spread *= 0.55; // aim assist on touch
    const a = this.aim + rand(-spread, spread);
    const dx = Math.cos(a), dy = Math.sin(a);
    const ox = this.px + dx * 24, oy = this.py + dy * 24;
    const wallT = this.rayWallT(ox, oy, dx, dy, def.range);

    // find zombie hits (balas espectrais atravessam vários)
    const pierce = PIERCE_N[this.abilityLevels["pierce"] ?? 0] ?? 0;
    const hits: { z: Zombie; t: number; head: boolean }[] = [];
    for (const z of this.zombies) {
      if (z.dead || z.spawnT > 0.4) continue;
      const rx = z.x - ox, ry = z.y - oy;
      const t = rx * dx + ry * dy;
      if (t < 0 || t > wallT) continue;
      const px2 = ox + dx * t, py2 = oy + dy * t;
      const perp = Math.hypot(z.x - px2, z.y - py2);
      const hr = z.radius + (this.isTouch ? 8 : 3);
      if (perp < hr) hits.push({ z, t, head: perp < (z.type === "brute" ? 10 : 7.5) });
    }
    hits.sort((a, b) => a.t - b.t);
    const targets = hits.slice(0, 1 + pierce);
    const bestT = targets.length ? targets[targets.length - 1].t : wallT;

    const ex = ox + dx * bestT, ey = oy + dy * bestT;
    sound.shoot(def.id);
    this.trauma = Math.min(1, this.trauma + def.kick * (def.id === "raygun" ? 1.6 : 0.7));
    // tracer + casing + muzzle smoke
    if (this.tracers.length < 40) this.tracers.push({ x1: ox, y1: oy, x2: ex, y2: ey, life: 0.1, max: 0.1, color: def.tracer, w: def.id === "raygun" ? 4 : 2 });
    if (this.parts.length < 440) {
      const ca = a + Math.PI / 2;
      this.parts.push({ x: this.px, y: this.py, vx: Math.cos(ca) * rand(60, 140) + rand(-30, 30), vy: Math.sin(ca) * rand(60, 140) + rand(-30, 30), life: rand(0.4, 0.8), max: 0.8, size: 2.5, color: "#c9a227", kind: 2, drag: 2, grav: 0 });
    }

    if (targets.length) {
      const dmgMult = DMG_MULT[this.abilityLevels["dmg"] ?? 0] ?? 1;
      const critCh = CRIT_CH[this.abilityLevels["crit"] ?? 0] ?? 0;
      const critMult = CRIT_MULT[this.abilityLevels["crit"] ?? 0] ?? 1;
      const vampHit = VAMP_HIT[this.abilityLevels["vampire"] ?? 0] ?? 0;
      for (const { z: bestZ, t: bt, head } of targets) {
        const fall = 1 - (bt / def.range) * 0.35;
        let dmg = def.damage * (head ? def.headMult : 1) * fall * dmgMult;
        let crit = false;
        if (critCh > 0 && Math.random() < critCh) { crit = true; dmg *= critMult; }
        if (this.instaT > 0) dmg = 9999;
        bestZ.hp -= dmg; bestZ.flash = 0.09;
        const kb = def.id === "raygun" ? 320 : def.id === "ak47" ? 150 : 110;
        bestZ.vx += dx * kb; bestZ.vy += dy * kb;
        this.hits++;
        this.blood(bestZ.x, bestZ.y, crit ? 14 : head ? 12 : 7, def.id === "raygun");
        this.addPoints(head || crit ? 15 : 10);
        this.hitmarks.push({ life: 0.28, max: 0.28, kill: false, head: head || crit });
        if (crit || head) sound.headshot(); else sound.hitmark();
        sound.zombieHit();
        if (vampHit > 0 && this.dying <= 0) this.hp = Math.min(this.maxHp, this.hp + vampHit);
        if (crit) this.addText(bestZ.x + rand(-10, 10), bestZ.y - 26, `CRIT ${Math.round(dmg)}`, "#ffd94f", 17);
        else if (Math.random() < 0.4) this.addText(bestZ.x + rand(-10, 10), bestZ.y - 24, `${Math.round(dmg)}`, head ? "#ff5d5d" : "#ffe9a8", head ? 16 : 12);
        if (bestZ.hp <= 0 && !bestZ.dead) this.killZombie(bestZ, head);
      }
      // raygun splash
      if (def.id === "raygun") this.explode(ex, ey, def.aoe, def.damage * 0.7 * dmgMult, targets[0].z);
    } else {
      this.spark(ex, ey, 5);
      if (this.parts.length < 440) this.parts.push({ x: ex, y: ey, vx: rand(-20, 20), vy: rand(-40, -10), life: 0.7, max: 0.7, size: 5, color: "rgba(150,150,150,0.5)", kind: 3, drag: 1, grav: -20 });
    }
    // small camera kick
    this.camX -= dx * def.kick * 22; this.camY -= dy * def.kick * 22;
  }

  private explode(x: number, y: number, r: number, dmg: number, except: Zombie | null) {
    this.burst(x, y, 26, "#5dff8d", 420, 0.6);
    this.burst(x, y, 14, "#eaffea", 300, 0.4);
    if (this.parts.length < 430) this.parts.push({ x, y, vx: 0, vy: 0, life: 0.35, max: 0.35, size: r, color: "rgba(93,255,141,0.55)", kind: 4, drag: 0, grav: 0 });
    this.trauma = Math.min(1, this.trauma + 0.35);
    // flash light handled in render via muzzle-like timer
    for (const z of this.zombies) {
      if (z.dead || z === except || z.spawnT > 0.4) continue;
      const d = Math.hypot(z.x - x, z.y - y);
      if (d < r + z.radius) {
        let dd = dmg * (1 - (d / (r + z.radius)) * 0.6);
        if (this.instaT > 0) dd = 9999;
        z.hp -= dd; z.flash = 0.09;
        const a = Math.atan2(z.y - y, z.x - x);
        z.vx += Math.cos(a) * 380; z.vy += Math.sin(a) * 380;
        this.blood(z.x, z.y, 8, true);
        if (z.hp <= 0 && !z.dead) this.killZombie(z, false);
      }
    }
    // hurt player slightly if point blank (forgiveness: small)
    const pd = Math.hypot(this.px - x, this.py - y);
    if (pd < 70 && this.dying <= 0) this.damagePlayer(8, x, y);
  }

  /* ---------------- habilidades ativas ---------------- */
  private tickAbilities(dt: number) {
    const dmgMult = DMG_MULT[this.abilityLevels["dmg"] ?? 0] ?? 1;
    // soro 935: regeneração constante
    const rr = REGEN_RATE[this.abilityLevels["regen"] ?? 0] ?? 0;
    if (rr > 0 && this.hp < this.maxHp && this.dying <= 0) {
      this.hp = Math.min(this.maxHp, this.hp + rr * dt);
    }
    // campo de força: dano por segundo + lentidão
    const fl = this.abilityLevels["field"] ?? 0;
    if (fl > 0) {
      const fp = fieldParams(fl);
      for (const z of this.zombies) {
        if (z.dead || z.spawnT > 0.4) continue;
        const rad = fp.r + z.radius;
        if (dist2(z.x, z.y, this.px, this.py) < rad * rad) {
          z.slowT = 0.35; z.slowMult = 1 - fp.slow;
          if (this.instaT > 0) { this.killZombie(z, false); continue; }
          z.hp -= fp.dps * dt;
          z.flash = Math.max(z.flash, 0.05);
          if (z.hp <= 0 && !z.dead) this.killZombie(z, false);
        }
      }
      if (Math.random() < 0.35 && this.parts.length < 430) {
        const a = rand(0, TAU);
        this.parts.push({ x: this.px + Math.cos(a) * fp.r, y: this.py + Math.sin(a) * fp.r, vx: Math.cos(a + 1.7) * 90, vy: Math.sin(a + 1.7) * 90, life: 0.5, max: 0.5, size: 3, color: "#5dff8d", kind: 1, drag: 1, grav: 0 });
      }
    }
    // lâminas orbitais
    const bl = this.abilityLevels["blades"] ?? 0;
    if (bl > 0) {
      const bp = bladeParams(bl);
      this.bladeAngle += bp.speed * dt;
      for (let i = 0; i < bp.count; i++) {
        const a = this.bladeAngle + (i / bp.count) * TAU;
        const bx = this.px + Math.cos(a) * bp.radius;
        const by = this.py + Math.sin(a) * bp.radius;
        for (const z of this.zombies) {
          if (z.dead || z.spawnT > 0.4 || (z.bladeCd ?? 0) > 0) continue;
          const rad = 17 + z.radius;
          if (dist2(z.x, z.y, bx, by) < rad * rad) {
            const dmg = this.instaT > 0 ? 9999 : bp.dmg * dmgMult;
            z.hp -= dmg; z.flash = 0.09; z.bladeCd = 0.4;
            const ka = Math.atan2(z.y - this.py, z.x - this.px);
            z.vx += Math.cos(ka) * 260; z.vy += Math.sin(ka) * 260;
            this.blood(z.x, z.y, 8, false);
            this.addPoints(10);
            this.hits++;
            sound.zombieHit();
            if (z.hp <= 0 && !z.dead) this.killZombie(z, false);
          }
        }
      }
    }
    // pulso nova
    const nl = this.abilityLevels["nova"] ?? 0;
    if (nl > 0) {
      this.novaT -= dt;
      if (this.novaT <= 0) {
        const np = novaParams(nl);
        this.novaT = np.cd;
        this.novaBlast(this.px, this.py, np.r, np.dmg * dmgMult);
      }
    }
    // juízo final
    const tl = this.abilityLevels["thunder"] ?? 0;
    if (tl > 0) {
      this.thunderT -= dt;
      if (this.thunderT <= 0) {
        const tp = thunderParams(tl);
        this.thunderT = tp.cd;
        const cands = this.zombies.filter((z) => !z.dead && z.spawnT <= 0.4 && dist2(z.x, z.y, this.px, this.py) < 780 * 780);
        for (let i = cands.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [cands[i], cands[j]] = [cands[j], cands[i]];
        }
        cands.slice(0, tp.strikes).forEach((z) => this.lightningStrike(z, tp.dmg * dmgMult));
      }
    }
  }

  private novaBlast(x: number, y: number, r: number, dmg: number) {
    sound.nova();
    this.trauma = Math.min(1, this.trauma + 0.3);
    this.burst(x, y, 30, "#7dd7ff", 460, 0.6);
    this.burst(x, y, 14, "#ffffff", 300, 0.4);
    if (this.parts.length < 430) this.parts.push({ x, y, vx: 0, vy: 0, life: 0.4, max: 0.4, size: r, color: "rgba(125,215,255,0.6)", kind: 4, drag: 0, grav: 0 });
    for (const z of this.zombies) {
      if (z.dead || z.spawnT > 0.4) continue;
      const d = Math.hypot(z.x - x, z.y - y);
      if (d < r + z.radius) {
        const dd = this.instaT > 0 ? 9999 : dmg * (1 - (d / (r + z.radius)) * 0.5);
        z.hp -= dd; z.flash = 0.09;
        const a = Math.atan2(z.y - y, z.x - x);
        z.vx += Math.cos(a) * 420; z.vy += Math.sin(a) * 420;
        this.blood(z.x, z.y, 8, true);
        if (z.hp <= 0 && !z.dead) this.killZombie(z, false);
      }
    }
  }

  private lightningStrike(z: Zombie, dmg: number) {
    if (z.dead) return;
    sound.thunder();
    if (this.tracers.length < 40) this.tracers.push({ x1: z.x + rand(-8, 8), y1: z.y - 320, x2: z.x, y2: z.y, life: 0.16, max: 0.16, color: "#d8ecff", w: 5 });
    this.burst(z.x, z.y, 18, "#cfe6ff", 340, 0.5);
    this.burst(z.x, z.y, 10, "#ffffff", 220, 0.3);
    if (this.parts.length < 430) this.parts.push({ x: z.x, y: z.y, vx: 0, vy: 0, life: 0.25, max: 0.25, size: 60, color: "rgba(220,240,255,0.5)", kind: 4, drag: 0, grav: 0 });
    const dd = this.instaT > 0 ? 9999 : dmg;
    z.hp -= dd; z.flash = 0.12;
    this.blood(z.x, z.y, 10, true);
    this.addPoints(10);
    if (z.hp <= 0 && !z.dead) this.killZombie(z, false);
    else this.addText(z.x, z.y - 26, `${Math.round(dd)}`, "#d8ecff", 14);
    this.trauma = Math.min(1, this.trauma + 0.18);
  }

  private drawForceField() {
    const fl = this.abilityLevels["field"] ?? 0;
    if (fl <= 0 || this.dying > 0) return;
    const { ctx } = this;
    const fp = fieldParams(fl);
    const pulse = 1 + Math.sin(this.time * 4) * 0.04;
    const col = fl >= 3 ? "93,255,190" : "93,255,141";
    ctx.save();
    ctx.translate(this.px, this.py);
    ctx.globalCompositeOperation = "lighter";
    const g = ctx.createRadialGradient(0, 0, fp.r * 0.5, 0, 0, fp.r * pulse);
    g.addColorStop(0, `rgba(${col},0)`);
    g.addColorStop(0.72, `rgba(${col},0.10)`);
    g.addColorStop(1, `rgba(${col},0.30)`);
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(0, 0, fp.r * pulse, 0, TAU); ctx.fill();
    ctx.strokeStyle = `rgba(${col},0.7)`;
    ctx.lineWidth = fl >= 3 ? 3.5 : 2;
    for (let k = 0; k < 3; k++) {
      const a0 = this.time * (1.2 + fl * 0.35) + (k * TAU) / 3;
      ctx.beginPath(); ctx.arc(0, 0, fp.r * pulse, a0, a0 + 1.1); ctx.stroke();
    }
    if (fl >= 3) {
      ctx.strokeStyle = "rgba(255,255,255,0.5)";
      ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(0, 0, fp.r * 0.68 * pulse, -this.time * 2, -this.time * 2 + 1.4); ctx.stroke();
    }
    ctx.restore();
  }

  private drawBlades() {
    const bl = this.abilityLevels["blades"] ?? 0;
    if (bl <= 0 || this.dying > 0) return;
    const { ctx } = this;
    const bp = bladeParams(bl);
    ctx.save();
    ctx.globalAlpha = 0.14;
    ctx.strokeStyle = "#cfe6ff";
    ctx.lineWidth = 1.5;
    ctx.setLineDash([6, 10]);
    ctx.beginPath(); ctx.arc(this.px, this.py, bp.radius, 0, TAU); ctx.stroke();
    ctx.restore();
    for (let i = 0; i < bp.count; i++) {
      const a = this.bladeAngle + (i / bp.count) * TAU;
      const bx = this.px + Math.cos(a) * bp.radius;
      const by = this.py + Math.sin(a) * bp.radius;
      ctx.save();
      ctx.translate(bx, by);
      ctx.rotate(a + Math.PI / 2);
      ctx.shadowColor = bl >= 3 ? "#ffd94f" : "#cfe6ff";
      ctx.shadowBlur = 12;
      // lâmina
      ctx.fillStyle = "#dfe7ee";
      ctx.beginPath();
      ctx.moveTo(0, -17); ctx.lineTo(4.5, -6); ctx.lineTo(3, 10); ctx.lineTo(-3, 10); ctx.lineTo(-4.5, -6);
      ctx.closePath(); ctx.fill();
      ctx.shadowBlur = 0;
      ctx.fillStyle = "#8fa3b8";
      ctx.fillRect(-1, -12, 2, 18);
      // guarda + cabo
      ctx.fillStyle = bl >= 3 ? "#ffb454" : "#6b7280";
      ctx.fillRect(-7, 10, 14, 3);
      ctx.fillStyle = "#3a2d1c";
      ctx.fillRect(-2, 13, 4, 7);
      ctx.restore();
    }
  }

  private killZombie(z: Zombie, head: boolean) {
    z.dead = true; z.deathT = 0.5;
    this.kills++; if (head) this.heads++;
    // XP por abate (escala com round + bônus de headshot + ímã)
    const xpBase = (z.type === "brute" ? 45 : z.type === "runner" ? 15 : 12) + (head ? 4 : 0) + Math.min(this.round, 12);
    const xpGain = Math.round(xpBase * (MAGNET_XP[this.abilityLevels["magnet"] ?? 0] ?? 1));
    this.gainXp(xpGain, z.x, z.y);
    // pacto sombrio: cura por abate
    const vh = VAMP_KILL[this.abilityLevels["vampire"] ?? 0] ?? 0;
    if (vh > 0 && this.dying <= 0) this.hp = Math.min(this.maxHp, this.hp + vh);
    const base = head ? 150 : 100;
    this.addPoints(base, z.x, z.y - 10, `+${base * (this.doubleT > 0 ? 2 : 1)}`);
    if (head) this.addText(z.x, z.y - 30, "HEADSHOT", "#ff5d5d", 15);
    sound.bloodKill();
    this.blood(z.x, z.y, 20, true);
    if (this.decals.length > 90) this.decals.shift();
    this.decals.push({ x: z.x + rand(-8, 8), y: z.y + rand(-8, 8), r: rand(14, z.type === "brute" ? 42 : 26), rot: rand(0, TAU), a: rand(0.35, 0.6) });
    if (this.decals.length > 90) this.decals.shift();
    this.decals.push({ x: z.x, y: z.y, r: rand(8, 16), rot: rand(0, TAU), a: 0.5 });
    // mark killing hitmark
    const h = this.hitmarks[this.hitmarks.length - 1];
    if (h) { h.kill = true; }
    // drops
    if (Math.random() < 0.055 && this.drops.length < 4 && this.dying <= 0) {
      const roll = Math.random();
      const type = roll < 0.32 ? "max" : roll < 0.58 ? "insta" : roll < 0.82 ? "double" : "nuke";
      this.drops.push({ id: this.dropId++, x: z.x, y: z.y, type, t: 26 });
      this.addText(z.x, z.y - 44, "DROP!", "#7dff9a", 15);
    }
  }

  /* ---------------- xp & level-up ---------------- */
  private gainXp(n: number, x: number, y: number) {
    if (this.dying > 0 || n <= 0) return;
    this.xp += n;
    if (n >= 10) this.addText(x + rand(-6, 6), y - 38, `+${n} XP`, "#8affc1", 12);
    while (this.xp >= this.xpNeed) {
      this.xp -= this.xpNeed;
      this.level++;
      this.pendingLevels++;
      this.xpNeed = xpNeedForLevel(this.level);
    }
    if (this.pendingLevels > 0 && !this.currentChoices) this.offerChoices();
  }

  private offerChoices() {
    const choices = rollChoices(this.abilityLevels, 3);
    this.currentChoices = choices;
    sound.levelup();
    this.burst(this.px, this.py, 30, "#8affc1", 320, 0.8);
    this.addText(this.px, this.py - 60, `NÍVEL ${this.level}!`, "#8affc1", 22);
    this.onLevelUp?.(choices);
  }

  chooseUpgrade(id: string) {
    if (!this.currentChoices) return;
    const found = this.currentChoices.find((c) => c.id === id);
    if (!found) return;
    if (found.kind === "ability") {
      const prev = this.abilityLevels[id] ?? 0;
      const lvl = Math.min(3, prev + 1);
      this.abilityLevels[id] = lvl;
      this.afterAbility(id, prev, lvl);
      this.addText(this.px, this.py - 48, `${found.name} NV ${lvl}!`, "#ffd94f", 18);
      this.burst(this.px, this.py, 24, found.color, 260, 0.7);
    } else {
      this.applySupply(id);
    }
    sound.pickup();
    this.hp = Math.min(this.maxHp, this.hp + 25);
    this.pendingLevels = Math.max(0, this.pendingLevels - 1);
    if (this.pendingLevels > 0) this.offerChoices();
    else {
      this.currentChoices = null;
      this.onLevelUp?.(null);
    }
  }

  private afterAbility(id: string, prev: number, lvl: number) {
    if (id === "regen") {
      const diff = (REGEN_MAX[lvl] ?? 0) - (REGEN_MAX[prev] ?? 0);
      this.maxHp += diff;
      this.hp = Math.min(this.maxHp, this.hp + diff);
    } else if (id === "nova") {
      this.novaT = Math.min(this.novaT || 99, 1.2);
    } else if (id === "thunder") {
      this.thunderT = Math.min(this.thunderT || 99, 1.0);
    }
  }

  private applySupply(id: string) {
    if (id === "supply_points") {
      this.addPoints(750, this.px, this.py - 48, "+750 PTS");
    } else if (id === "supply_ammo") {
      for (const w of this.weapons) {
        const def = WEAPONS[w.defId];
        w.mag = def.magSize; w.reserve = def.maxReserve;
      }
      this.reloading = false;
      this.addText(this.px, this.py - 48, "MUNIÇÃO CHEIA!", "#9adcff", 18);
    } else {
      this.hp = this.maxHp;
      this.addText(this.px, this.py - 48, "CURA TOTAL!", "#ff7a7a", 18);
    }
  }

  private damagePlayer(n: number, fromX: number, fromY: number) {
    if (this.dying > 0) return;
    this.hp -= n;
    this.lastDmg = this.time;
    this.recentHit = 1;
    this.trauma = Math.min(1, this.trauma + 0.45);
    sound.playerHurt();
    const a = Math.atan2(this.py - fromY, this.px - fromX);
    this.pvx += Math.cos(a) * 160; this.pvy += Math.sin(a) * 160;
    this.blood(this.px, this.py, 6, false);
    if (this.hp <= 0) {
      this.hp = 0; this.dying = 1.7;
      sound.gameOver();
      this.blood(this.px, this.py, 30, true);
    }
  }

  /* ---------------- update ---------------- */
  private isSprinting() {
    const touchMag = Math.hypot(this.touchMove.x, this.touchMove.y);
    if (touchMag > 0.92) return true; // push stick to edge to sprint on touch
    return (this.keys.has("shift") && (touchMag > 0.1 || this.keys.has("w") || this.keys.has("a") || this.keys.has("s") || this.keys.has("d")));
  }

  private collideCircle(x: number, y: number, r: number): [number, number] {
    for (const o of this.obstacles) {
      const cx = clamp(x, o.x, o.x + o.w), cy = clamp(y, o.y, o.y + o.h);
      const dx = x - cx, dy = y - cy;
      const d2 = dx * dx + dy * dy;
      if (d2 < r * r) {
        if (d2 < 0.0001) {
          // inside: push out along smallest axis
          const l = x - o.x, rr = o.x + o.w - x, t = y - o.y, b = o.y + o.h - y;
          const m = Math.min(l, rr, t, b);
          if (m === l) x = o.x - r; else if (m === rr) x = o.x + o.w + r;
          else if (m === t) y = o.y - r; else y = o.y + o.h + r;
        } else {
          const d = Math.sqrt(d2), push = r - d;
          x += (dx / d) * push; y += (dy / d) * push;
        }
      }
    }
    x = clamp(x, 30, MAP_W - 30); y = clamp(y, 30, MAP_H - 30);
    return [x, y];
  }

  private loop = (now: number) => {
    if (this.destroyed || !this.running) return;
    if (this.paused) return;
    let dt = (now - this.last) / 1000;
    this.last = now;
    if (dt > 0.05) dt = 0.05;
    if (dt <= 0) { this.raf = requestAnimationFrame(this.loop); return; }
    // fps track
    this.fpsAcc += 1 / Math.max(dt, 1e-4); this.fpsN++;
    if (now - this.fpsT > 500) { this.fps = Math.round(this.fpsAcc / Math.max(1, this.fpsN)); this.fpsAcc = 0; this.fpsN = 0; this.fpsT = now; }

    const scale = this.dying > 0 ? 0.35 : 1; // death slow-mo
    this.update(dt * scale, dt);
    this.render();
    this.raf = requestAnimationFrame(this.loop);
  };

  private update(dt: number, rawDt: number) {
    // level-up aberto: congela o mundo, só partículas/câmera continuam
    if (this.currentChoices) {
      this.updateFx(rawDt);
      this.updateCamera(rawDt);
      return;
    }
    this.time += dt;
    if (this.bannerT > 0) this.bannerT -= rawDt;
    if (this.recentHit > 0) this.recentHit -= rawDt * 2;
    if (this.nukeFlash > 0) this.nukeFlash -= rawDt * 1.2;
    if (this.doubleT > 0) this.doubleT -= dt;
    if (this.instaT > 0) this.instaT -= dt;
    this.trauma = Math.max(0, this.trauma - rawDt * 1.6);
    this.muzzle = Math.max(0, this.muzzle - dt);
    this.crossKick = Math.max(0, this.crossKick - rawDt * 3);

    // death sequence
    if (this.dying > 0) {
      this.dying -= rawDt;
      this.updateFx(dt);
      this.updateCamera(rawDt);
      if (this.dying <= 0 && !this.deadDone) {
        this.deadDone = true;
        this.onGameOver({ score: this.earned + this.round * 250, points: this.points, round: this.round, kills: this.kills, headshots: this.heads, shots: this.shots, hits: this.hits, time: this.time, level: this.level });
      }
      return;
    }

    /* player movement */
    let mx = 0, my = 0;
    if (this.keys.has("w") || this.keys.has("arrowup")) my -= 1;
    if (this.keys.has("s") || this.keys.has("arrowdown")) my += 1;
    if (this.keys.has("a") || this.keys.has("arrowleft")) mx -= 1;
    if (this.keys.has("d") || this.keys.has("arrowright")) mx += 1;
    mx += this.touchMove.x; my += this.touchMove.y;
    const ml = Math.hypot(mx, my);
    if (ml > 1) { mx /= ml; my /= ml; }
    const sprint = this.isSprinting();
    const bootsMult = BOOTS_MULT[this.abilityLevels["boots"] ?? 0] ?? 1;
    const speed = (sprint ? 432 : 308) * bootsMult;
    const accel = 12;
    this.pvx += (mx * speed - this.pvx) * Math.min(1, accel * dt);
    this.pvy += (my * speed - this.pvy) * Math.min(1, accel * dt);
    let nx = this.px + this.pvx * dt, ny = this.py + this.pvy * dt;
    [nx, ny] = this.collideCircle(nx, ny, 15);
    this.px = nx; this.py = ny;
    // sprint dust
    if (sprint && ml > 0.3 && Math.random() < 0.25 && this.parts.length < 440) {
      this.parts.push({ x: this.px + rand(-8, 8), y: this.py + 10, vx: rand(-30, 30), vy: rand(-10, 30), life: 0.5, max: 0.5, size: 4, color: "rgba(140,140,130,0.35)", kind: 3, drag: 2, grav: 0 });
    }

    /* aim */
    if (this.touchAimActive) this.aim = this.touchAimAngle;
    else {
      const wx = this.camX + this.shakeX + this.mouseX, wy = this.camY + this.shakeY + this.mouseY;
      this.aim = Math.atan2(wy - this.py, wx - this.px);
    }

    /* reload */
    if (this.reloading) {
      this.reloadT -= dt;
      if (this.reloadT <= 0) {
        const w = this.weapons[this.cur];
        const def = WEAPONS[w.defId];
        const need = def.magSize - w.mag;
        const take = Math.min(need, w.reserve);
        w.mag += take; w.reserve -= take;
        this.reloading = false;
      }
    }
    this.tryFire(dt);

    /* regen */
    if (this.time - this.lastDmg > 4.5 && this.hp < this.maxHp) {
      this.hp = Math.min(this.maxHp, this.hp + 30 * dt);
    }

    /* rounds / spawning */
    const alive = this.zombies.filter((z) => !z.dead).length;
    if (this.intermission > 0) {
      this.intermission -= rawDt;
      if (this.intermission <= 0) this.nextRound();
    } else {
      const cap = Math.min(6 + this.round, 20);
      if (this.queue > 0) {
        this.spawnT -= dt;
        if (this.spawnT <= 0 && alive < cap) {
          this.spawnZombie(); this.queue--; this.spawnT = this.spawnInterval;
        }
      } else if (alive === 0) {
        // round clear bonus
        const bonus = 100 + this.round * 25;
        this.points += bonus; this.earned += bonus;
        this.addText(this.px, this.py - 50, `ROUND CLEAR +${bonus}`, "#7dff9a", 17);
        sound.pickup();
        this.intermission = 5;
        this.banner = `ROUND ${this.round} CLEAR`;
        this.bannerSub = `BÔNUS +${bonus} PTS — PRÓXIMO ROUND EM 5s`;
        this.bannerT = 3;
      }
    }

    /* zombies */
    for (const z of this.zombies) {
      if (z.dead) { z.deathT -= dt; continue; }
      if (z.spawnT > 0) { z.spawnT -= dt; continue; }
      z.flash = Math.max(0, z.flash - dt);
      z.bladeCd = Math.max(0, (z.bladeCd ?? 0) - dt);
      z.slowT = Math.max(0, (z.slowT ?? 0) - dt);
      z.atk -= dt; z.lunge = Math.max(0, z.lunge - dt * 3);
      z.wob += dt * (z.type === "runner" ? 11 : 7);
      z.groan -= dt;
      if (z.groan <= 0) { z.groan = rand(4, 11); sound.groan(); }
      const dx = this.px - z.x, dy = this.py - z.y;
      const d = Math.hypot(dx, dy) || 1;
      const nx2 = dx / d, ny2 = dy / d;
      const arrive = clamp(d / 120, 0.35, 1);
      const slowK = (z.slowT ?? 0) > 0 ? (z.slowMult ?? 1) : 1;
      const spd = z.speed * arrive * slowK;
      z.vx += (nx2 * spd - z.vx) * Math.min(1, 4 * dt);
      z.vy += (ny2 * spd - z.vy) * Math.min(1, 4 * dt);
      // knockback decay
      let zx = z.x + z.vx * dt, zy = z.y + z.vy * dt;
      [zx, zy] = this.collideCircle(zx, zy, z.radius);
      z.x = zx; z.y = zy;
      // attack
      const rr = z.radius + 15 + 8;
      if (d < rr && z.atk <= 0) {
        z.atk = z.type === "brute" ? 1.3 : 0.95;
        z.lunge = 1;
        let dmg = z.damage * rand(0.9, 1.15);
        if (this.round > 6) dmg *= 1 + (this.round - 6) * 0.05;
        this.damagePlayer(dmg, z.x, z.y);
      }
    }
    // separation (cheap O(n^2), n small)
    const zs = this.zombies;
    for (let i = 0; i < zs.length; i++) {
      const a = zs[i]; if (a.dead || a.spawnT > 0) continue;
      for (let j = i + 1; j < zs.length; j++) {
        const b = zs[j]; if (b.dead || b.spawnT > 0) continue;
        const dx = b.x - a.x, dy = b.y - a.y;
        const rr = a.radius + b.radius - 2;
        const d2 = dx * dx + dy * dy;
        if (d2 < rr * rr && d2 > 0.01) {
          const d = Math.sqrt(d2), push = ((rr - d) / d) * 0.5;
          a.x -= dx * push * 0.5; a.y -= dy * push * 0.5;
          b.x += dx * push * 0.5; b.y += dy * push * 0.5;
        }
      }
    }
    // remove long-dead
    if (this.zombies.length > 60) this.zombies = this.zombies.filter((z) => !z.dead || z.deathT > -2);
    else this.zombies = this.zombies.filter((z) => !z.dead || z.deathT > 0);

    /* drops (ímã aumenta o raio de coleta) */
    const magnetR = MAGNET_R[this.abilityLevels["magnet"] ?? 0] ?? 34;
    for (let i = this.drops.length - 1; i >= 0; i--) {
      const d = this.drops[i];
      d.t -= dt;
      if (d.t <= 0) { this.drops.splice(i, 1); continue; }
      if (dist2(d.x, d.y, this.px, this.py) < magnetR * magnetR) {
        this.drops.splice(i, 1);
        this.applyDrop(d);
      }
    }

    /* ---- habilidades ativas (campo, lâminas, nova, raios, regen) ---- */
    this.tickAbilities(dt);

    this.updateFx(dt);

    /* fog drift */
    for (const f of this.fogs) {
      f.x += f.s * dt;
      if (f.x - f.r > MAP_W) f.x = -f.r;
    }

    this.updateCamera(rawDt);
  }

  private applyDrop(d: Drop) {
    sound.pickup();
    this.burst(d.x, d.y, 24, "#7dff9a", 260, 0.7);
    if (d.type === "max") {
      for (const w of this.weapons) { w.reserve = WEAPONS[w.defId].maxReserve; w.mag = WEAPONS[w.defId].magSize; }
      this.reloading = false;
      this.addText(d.x, d.y - 30, "MUNIÇÃO MÁXIMA!", "#7dff9a", 19);
      this.banner = "MAX AMMO"; this.bannerSub = "MUNIÇÃO RESTAURADA"; this.bannerT = 2;
    } else if (d.type === "insta") {
      this.instaT = 30;
      this.addText(d.x, d.y - 30, "INSTA-KILL 30s!", "#ff5d5d", 19);
      this.banner = "INSTA-KILL"; this.bannerSub = "UM TIRO, UMA MORTE — 30s"; this.bannerT = 2;
    } else if (d.type === "double") {
      this.doubleT = 30;
      this.addText(d.x, d.y - 30, "PONTOS EM DOBRO 30s!", "#ffd94f", 19);
      this.banner = "DOUBLE POINTS"; this.bannerSub = "PONTOS EM DOBRO — 30s"; this.bannerT = 2;
    } else {
      // nuke
      this.nukeFlash = 1.4; this.trauma = 1;
      sound.nuke();
      this.burst(this.px, this.py, 40, "#fff2c9", 500, 1);
      for (const z of this.zombies) {
        if (!z.dead && z.spawnT <= 0.4) {
          z.hp = 0; this.killZombie(z, false);
        }
      }
      this.queue = 0;
      this.banner = "NUKE!"; this.bannerSub = "TUDO MORREU — APROVEITE"; this.bannerT = 2.4;
    }
  }

  private updateFx(dt: number) {
    for (let i = this.parts.length - 1; i >= 0; i--) {
      const p = this.parts[i];
      p.life -= dt;
      if (p.life <= 0) { this.parts.splice(i, 1); continue; }
      if (p.kind === 4) continue; // ring expands, no move
      p.vx -= p.vx * p.drag * dt; p.vy -= p.vy * p.drag * dt;
      p.vy += (p.grav || 0) * dt;
      p.x += p.vx * dt; p.y += p.vy * dt;
    }
    for (let i = this.tracers.length - 1; i >= 0; i--) {
      this.tracers[i].life -= dt;
      if (this.tracers[i].life <= 0) this.tracers.splice(i, 1);
    }
    for (let i = this.texts.length - 1; i >= 0; i--) {
      const t = this.texts[i];
      t.life -= dt * 0.9; t.y -= 42 * dt;
      if (t.life <= 0) this.texts.splice(i, 1);
    }
    for (let i = this.hitmarks.length - 1; i >= 0; i--) {
      this.hitmarks[i].life -= dt;
      if (this.hitmarks[i].life <= 0) this.hitmarks.splice(i, 1);
    }
  }

  private updateCamera(dt: number) {
    const look = 46;
    const tx = clamp(this.px + Math.cos(this.aim) * look - this.vw / 2, -60, MAP_W - this.vw + 60);
    const ty = clamp(this.py + Math.sin(this.aim) * look - this.vh / 2, -60, MAP_H - this.vh + 60);
    const k = Math.min(1, 6 * dt);
    this.camX += (tx - this.camX) * k;
    this.camY += (ty - this.camY) * k;
    const sh = this.trauma * this.trauma;
    this.shakeX = rand(-1, 1) * sh * 22;
    this.shakeY = rand(-1, 1) * sh * 22;
  }

  /* ---------------- render ---------------- */
  private render() {
    const { ctx } = this;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    // bg
    ctx.fillStyle = "#050705";
    ctx.fillRect(0, 0, this.vw, this.vh);
    const camX = this.camX + this.shakeX, camY = this.camY + this.shakeY;

    ctx.save();
    ctx.translate(-camX, -camY);

    // ground (scaled to MAP)
    if (this.ground) ctx.drawImage(this.ground, 0, 0, MAP_W, MAP_H);
    // map border — electric fence vibe
    ctx.strokeStyle = "rgba(93,255,141,0.28)"; ctx.lineWidth = 4;
    ctx.strokeRect(24, 24, MAP_W - 48, MAP_H - 48);
    ctx.strokeStyle = "rgba(93,255,141,0.12)"; ctx.lineWidth = 10;
    ctx.strokeRect(24, 24, MAP_W - 48, MAP_H - 48);

    // decals (blood pools)
    for (const d of this.decals) {
      ctx.save(); ctx.translate(d.x, d.y); ctx.rotate(d.rot);
      ctx.globalAlpha = d.a;
      ctx.fillStyle = "#5a0a0a";
      ctx.beginPath(); ctx.ellipse(0, 0, d.r, d.r * 0.7, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = "#7d1010";
      ctx.beginPath(); ctx.ellipse(d.r * 0.2, -d.r * 0.1, d.r * 0.5, d.r * 0.35, 0, 0, TAU); ctx.fill();
      ctx.restore();
    }
    ctx.globalAlpha = 1;

    // spawn gates glow
    const t = this.time;
    for (const s of this.spawns) {
      const p = 0.5 + Math.sin(t * 3 + s.x) * 0.2;
      ctx.fillStyle = `rgba(140,30,30,${0.25 + p * 0.2})`;
      ctx.beginPath(); ctx.arc(s.x, s.y, 26, 0, TAU); ctx.fill();
      ctx.strokeStyle = `rgba(255,60,60,${0.3 + p * 0.3})`; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(s.x, s.y, 26, 0, TAU); ctx.stroke();
    }

    // obstacles — crates
    for (const o of this.obstacles) {
      ctx.fillStyle = "rgba(0,0,0,0.45)";
      ctx.fillRect(o.x + 6, o.y + 8, o.w, o.h);
      const g = ctx.createLinearGradient(o.x, o.y, o.x, o.y + o.h);
      g.addColorStop(0, "#4d3d27"); g.addColorStop(1, "#2c2314");
      ctx.fillStyle = g;
      ctx.fillRect(o.x, o.y, o.w, o.h);
      ctx.strokeStyle = "#151009"; ctx.lineWidth = 3;
      ctx.strokeRect(o.x, o.y, o.w, o.h);
      ctx.strokeStyle = "rgba(0,0,0,0.4)"; ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(o.x, o.y); ctx.lineTo(o.x + o.w, o.y + o.h);
      ctx.moveTo(o.x + o.w, o.y); ctx.lineTo(o.x, o.y + o.h);
      ctx.stroke();
      ctx.fillStyle = "rgba(255,220,150,0.08)";
      ctx.fillRect(o.x, o.y, o.w, 6);
    }

    // buy stations
    for (const s of this.stations) {
      const def = WEAPONS[s.weaponId];
      const owned = this.weapons.some((w) => w.defId === s.weaponId);
      const near = this.nearestStation() === s;
      const pulse = 0.5 + Math.sin(t * 4 + s.x * 0.01) * 0.25;
      // pad
      ctx.save();
      ctx.translate(s.x, s.y);
      ctx.fillStyle = "rgba(0,0,0,0.5)";
      ctx.beginPath(); ctx.ellipse(0, 26, 64, 20, 0, 0, TAU); ctx.fill();
      // glow ring
      ctx.strokeStyle = s.color; ctx.globalAlpha = 0.35 + pulse * 0.4; ctx.lineWidth = near ? 4 : 2;
      ctx.beginPath(); ctx.ellipse(0, 20, 58, 18, 0, 0, TAU); ctx.stroke();
      ctx.globalAlpha = 1;
      // weapon crate
      ctx.fillStyle = "#141a15";
      ctx.fillRect(-44, -34, 88, 52);
      ctx.strokeStyle = near ? "#ffffff" : s.color; ctx.lineWidth = near ? 3 : 1.5;
      ctx.strokeRect(-44, -34, 88, 52);
      // gun glyph
      ctx.strokeStyle = s.color; ctx.lineWidth = 3; ctx.lineCap = "round";
      ctx.beginPath();
      if (s.weaponId === "raygun") {
        ctx.moveTo(-26, 4); ctx.lineTo(26, 4); ctx.moveTo(10, 4); ctx.lineTo(20, -8);
        ctx.moveTo(-10, 4); ctx.lineTo(-14, 14);
      } else {
        ctx.moveTo(-28, 0); ctx.lineTo(28, 0); ctx.moveTo(4, 0); ctx.lineTo(0, 12);
        ctx.moveTo(-6, 0); ctx.lineTo(-10, -10);
      }
      ctx.stroke();
      // price tag
      ctx.fillStyle = owned ? "#0d1512" : "#0d1512";
      ctx.fillRect(-40, -58, 80, 20);
      ctx.strokeStyle = owned ? "rgba(154,220,255,0.7)" : s.color; ctx.lineWidth = 1;
      ctx.strokeRect(-40, -58, 80, 20);
      ctx.fillStyle = owned ? "#9adcff" : "#ffe9a8";
      ctx.font = "bold 12px monospace"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      const price = owned ? def.ammoPrice : def.price;
      ctx.fillText(owned ? `MUN ${price}` : `${price} PTS`, 0, -47);
      ctx.fillStyle = s.color; ctx.font = "bold 11px monospace";
      ctx.fillText(owned ? "✓ OWNED" : s.label, 0, 32);
      ctx.restore();
    }

    // drops
    for (const d of this.drops) {
      const bob = Math.sin(t * 5 + d.id) * 5;
      const blink = d.t < 5 ? (Math.sin(t * 12) > 0 ? 1 : 0.25) : 1;
      ctx.save(); ctx.translate(d.x, d.y + bob); ctx.globalAlpha = blink;
      const col = d.type === "max" ? "#7dff9a" : d.type === "insta" ? "#ff5d5d" : d.type === "double" ? "#ffd94f" : "#ff9d2e";
      const gr = ctx.createRadialGradient(0, 0, 4, 0, 0, 34);
      gr.addColorStop(0, col); gr.addColorStop(1, "transparent");
      ctx.globalAlpha = blink * 0.5; ctx.fillStyle = gr;
      ctx.beginPath(); ctx.arc(0, 0, 34, 0, TAU); ctx.fill();
      ctx.globalAlpha = blink;
      ctx.fillStyle = "#0a0f0c";
      ctx.beginPath(); ctx.arc(0, 0, 16, 0, TAU); ctx.fill();
      ctx.strokeStyle = col; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.arc(0, 0, 16, 0, TAU); ctx.stroke();
      ctx.fillStyle = col; ctx.font = "bold 13px monospace"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.fillText(d.type === "max" ? "AM" : d.type === "insta" ? "IK" : d.type === "double" ? "2X" : "☢", 0, 1);
      ctx.restore();
    }
    ctx.globalAlpha = 1;

    // zombies
    for (const z of this.zombies) this.drawZombie(z);

    // campo de força (embaixo do jogador)
    this.drawForceField();
    // player
    if (this.dying <= 0 || Math.sin(this.time * 20) > -0.4) this.drawPlayer();
    // lâminas orbitais (por cima)
    this.drawBlades();

    // tracers (additive)
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const tr of this.tracers) {
      const a = tr.life / tr.max;
      ctx.globalAlpha = a;
      ctx.strokeStyle = tr.color; ctx.lineWidth = tr.w; ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(tr.x1, tr.y1); ctx.lineTo(tr.x2, tr.y2); ctx.stroke();
      ctx.fillStyle = tr.color;
      ctx.beginPath(); ctx.arc(tr.x2, tr.y2, tr.w * 1.6 * a + 1, 0, TAU); ctx.fill();
    }
    // particles
    for (const p of this.parts) {
      const a = clamp(p.life / p.max, 0, 1);
      if (p.kind === 4) {
        ctx.globalAlpha = a * 0.6;
        ctx.strokeStyle = p.color; ctx.lineWidth = 4;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (1.4 - a * 0.4), 0, TAU); ctx.stroke();
      } else if (p.kind === 3) {
        ctx.globalAlpha = a * 0.5;
        ctx.fillStyle = p.color;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.size * a + 1, 0, TAU); ctx.fill();
      } else if (p.kind === 2) {
        ctx.globalAlpha = a;
        ctx.fillStyle = p.color;
        ctx.fillRect(p.x - 1.5, p.y - 1, 3, 2);
      } else {
        ctx.globalAlpha = a;
        ctx.fillStyle = p.color;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (0.5 + a * 0.5), 0, TAU); ctx.fill();
      }
    }
    ctx.restore();
    ctx.globalAlpha = 1;

    // floating texts
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    for (const ft of this.texts) {
      const a = clamp(ft.life, 0, 1);
      ctx.globalAlpha = a;
      ctx.font = `bold ${ft.size}px monospace`;
      ctx.strokeStyle = "rgba(0,0,0,0.8)"; ctx.lineWidth = 3;
      ctx.strokeText(ft.text, ft.x, ft.y);
      ctx.fillStyle = ft.color;
      ctx.fillText(ft.text, ft.x, ft.y);
    }
    ctx.globalAlpha = 1;

    ctx.restore(); // un-translate (screen space from here)

    /* ---- atmosphere / lighting ---- */
    const pxs = this.px - camX, pys = this.py - camY;
    // flashlight cone
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const cone = ctx.createRadialGradient(pxs, pys, 10, pxs, pys, 300);
    cone.addColorStop(0, "rgba(255,244,200,0.20)");
    cone.addColorStop(0.4, "rgba(255,244,200,0.07)");
    cone.addColorStop(1, "transparent");
    ctx.fillStyle = cone;
    ctx.beginPath(); ctx.arc(pxs, pys, 300, 0, TAU); ctx.fill();
    // beam toward aim
    ctx.translate(pxs, pys); ctx.rotate(this.aim);
    const beam = ctx.createLinearGradient(0, 0, 420, 0);
    beam.addColorStop(0, "rgba(255,246,210,0.13)");
    beam.addColorStop(1, "transparent");
    ctx.fillStyle = beam;
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(420, -90); ctx.lineTo(420, 90); ctx.closePath(); ctx.fill();
    // muzzle light
    if (this.muzzle > 0) {
      ctx.fillStyle = "rgba(255,200,90,0.5)";
      ctx.beginPath(); ctx.arc(30, 0, 70, 0, TAU); ctx.fill();
    }
    // insta-kill red tint on player
    if (this.instaT > 0) {
      ctx.fillStyle = "rgba(255,40,40,0.08)";
      ctx.beginPath(); ctx.arc(0, 0, 200, 0, TAU); ctx.fill();
    }
    ctx.restore();

    // fog blobs (screen-space drift)
    ctx.save();
    for (const f of this.fogs) {
      const sx = f.x - camX * 0.6, sy = f.y - camY * 0.6;
      if (sx < -f.r || sx > this.vw + f.r || sy < -f.r || sy > this.vh + f.r) continue;
      const fg = ctx.createRadialGradient(sx, sy, 10, sx, sy, f.r);
      fg.addColorStop(0, `rgba(120,160,130,${f.a})`);
      fg.addColorStop(1, "transparent");
      ctx.fillStyle = fg;
      ctx.beginPath(); ctx.arc(sx, sy, f.r, 0, TAU); ctx.fill();
    }
    ctx.restore();

    // darkness vignette
    if (!this.vignette) {
      const v = ctx.createRadialGradient(this.vw / 2, this.vh / 2, Math.min(this.vw, this.vh) * 0.32, this.vw / 2, this.vh / 2, Math.max(this.vw, this.vh) * 0.72);
      v.addColorStop(0, "rgba(0,0,0,0)");
      v.addColorStop(1, "rgba(0,0,0,0.62)");
      this.vignette = v;
    }
    ctx.fillStyle = this.vignette;
    ctx.fillRect(0, 0, this.vw, this.vh);

    // damage flash + low hp
    const lowHp = this.hp / this.maxHp < 0.35;
    const dmgA = clamp(this.recentHit * 0.45 + (lowHp ? 0.16 + Math.sin(this.time * 6) * 0.08 : 0) + (this.dying > 0 ? 0.45 : 0), 0, 0.8);
    if (dmgA > 0.01) {
      const dg = ctx.createRadialGradient(this.vw / 2, this.vh / 2, Math.min(this.vw, this.vh) * 0.25, this.vw / 2, this.vh / 2, Math.max(this.vw, this.vh) * 0.7);
      dg.addColorStop(0, "transparent");
      dg.addColorStop(1, `rgba(160,10,10,${dmgA})`);
      ctx.fillStyle = dg;
      ctx.fillRect(0, 0, this.vw, this.vh);
    }
    if (this.nukeFlash > 0) {
      ctx.fillStyle = `rgba(255,246,220,${clamp(this.nukeFlash, 0, 0.9)})`;
      ctx.fillRect(0, 0, this.vw, this.vh);
    }

    // crosshair
    if (!this.isTouch && this.dying <= 0) {
      const spreadPx = 10 + this.crossKick * 16;
      ctx.strokeStyle = this.hitmarks.length ? "#ff4d4d" : "rgba(255,255,255,0.9)";
      ctx.lineWidth = 2; ctx.lineCap = "round";
      ctx.beginPath();
      for (const [ox, oy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
        ctx.moveTo(this.mouseX + ox * spreadPx, this.mouseY + oy * spreadPx);
        ctx.lineTo(this.mouseX + ox * (spreadPx + 7), this.mouseY + oy * (spreadPx + 7));
      }
      ctx.stroke();
      ctx.fillStyle = "#fff";
      ctx.beginPath(); ctx.arc(this.mouseX, this.mouseY, 1.8, 0, TAU); ctx.fill();
    }
    // hitmarkers
    for (const h of this.hitmarks) {
      const a = h.life / h.max;
      const s = 10 + (1 - a) * 6;
      ctx.save(); ctx.translate(this.mouseX, this.mouseY); ctx.rotate(Math.PI / 4);
      ctx.globalAlpha = a;
      ctx.strokeStyle = h.kill ? "#ff2d2d" : h.head ? "#ff7a2d" : "#ffffff";
      ctx.lineWidth = h.kill ? 3.5 : 2.5;
      ctx.beginPath();
      ctx.moveTo(-s, -4); ctx.lineTo(-s + 8, -4); ctx.moveTo(s, -4); ctx.lineTo(s - 8, -4);
      ctx.moveTo(-s, 4); ctx.lineTo(-s + 8, 4); ctx.moveTo(s, 4); ctx.lineTo(s - 8, 4);
      // simpler X:
      ctx.moveTo(-s, -s); ctx.lineTo(-s + 7, -s + 7);
      ctx.moveTo(s, -s); ctx.lineTo(s - 7, -s + 7);
      ctx.moveTo(-s, s); ctx.lineTo(-s + 7, s - 7);
      ctx.moveTo(s, s); ctx.lineTo(s - 7, s - 7);
      ctx.stroke();
      ctx.restore();
    }
    ctx.globalAlpha = 1;
  }

  private drawZombie(z: Zombie) {
    const { ctx } = this;
    ctx.save();
    ctx.translate(z.x, z.y);
    if (z.spawnT > 0) {
      // rising from ground
      const p = 1 - z.spawnT / 1.1;
      ctx.globalAlpha = 0.4 + p * 0.6;
      ctx.fillStyle = "#1c2019";
      ctx.beginPath(); ctx.ellipse(0, 6, z.radius + 6, 10, 0, 0, TAU); ctx.fill();
      ctx.translate(0, (1 - p) * 26);
      ctx.scale(1, 0.4 + p * 0.6);
    }
    if (z.dead) {
      const p = 1 - z.deathT / 0.5;
      ctx.globalAlpha = clamp(1 - p * 0.7, 0, 1);
      ctx.rotate(z.deadRot + p * 0.6);
      ctx.scale(1 + p * 0.35, 1 - p * 0.25);
    }
    const ang = Math.atan2(this.py - z.y, this.px - z.x);
    // shadow
    ctx.fillStyle = "rgba(0,0,0,0.4)";
    ctx.beginPath(); ctx.ellipse(0, z.radius * 0.7, z.radius, z.radius * 0.45, 0, 0, TAU); ctx.fill();
    ctx.rotate(ang + Math.PI / 2);
    const wob = Math.sin(z.wob) * (z.type === "runner" ? 4 : 2.5);
    const R = z.radius;
    // legs shamble
    ctx.strokeStyle = "#242b22"; ctx.lineWidth = R * 0.5; ctx.lineCap = "round";
    const lp = Math.sin(z.wob) * R * 0.4;
    ctx.beginPath(); ctx.moveTo(-R * 0.35, 0); ctx.lineTo(-R * 0.35 + lp, R * 0.9); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(R * 0.35, 0); ctx.lineTo(R * 0.35 - lp, R * 0.9); ctx.stroke();
    // torso
    const torso = z.type === "brute" ? "#4a3d33" : z.type === "runner" ? "#3a4034" : "#39413a";
    ctx.fillStyle = torso;
    ctx.beginPath(); ctx.ellipse(wob * 0.4, 0, R * 0.85, R * 1.05, 0, 0, TAU); ctx.fill();
    // rips
    ctx.strokeStyle = "rgba(0,0,0,0.5)"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(-R * 0.4, -R * 0.3); ctx.lineTo(R * 0.1, R * 0.2); ctx.stroke();
    // arms reaching forward (toward -y after rotation = toward player)
    const lungeExt = z.lunge * R * 0.5;
    ctx.strokeStyle = "#4c5847"; ctx.lineWidth = R * 0.32;
    ctx.beginPath(); ctx.moveTo(-R * 0.6, -R * 0.2); ctx.lineTo(-R * 0.75 + wob * 0.3, -R * 1.25 - lungeExt); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(R * 0.6, -R * 0.2); ctx.lineTo(R * 0.75 - wob * 0.3, -R * 1.25 - lungeExt); ctx.stroke();
    // hands/claws
    ctx.fillStyle = "#6f7d66";
    ctx.beginPath(); ctx.arc(-R * 0.75 + wob * 0.3, -R * 1.3 - lungeExt, R * 0.18, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.arc(R * 0.75 - wob * 0.3, -R * 1.3 - lungeExt, R * 0.18, 0, TAU); ctx.fill();
    // head
    ctx.fillStyle = z.type === "brute" ? "#7a6a55" : "#67755f";
    ctx.beginPath(); ctx.arc(wob * 0.3, -R * 1.15, R * 0.52, 0, TAU); ctx.fill();
    // eyes (glow toward player)
    const eg = z.type === "brute" ? "#ff9d2e" : "#ff3b3b";
    ctx.fillStyle = eg;
    ctx.beginPath(); ctx.arc(wob * 0.3 - R * 0.18, -R * 1.32, R * 0.1, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.arc(wob * 0.3 + R * 0.18, -R * 1.32, R * 0.1, 0, TAU); ctx.fill();
    // mouth
    ctx.fillStyle = "#120806";
    ctx.beginPath(); ctx.ellipse(wob * 0.3, -R * 0.95, R * 0.16, R * 0.1, 0, 0, TAU); ctx.fill();
    // brute spikes
    if (z.type === "brute") {
      ctx.fillStyle = "#2b2b2b";
      for (let s = -1; s <= 1; s++) {
        ctx.beginPath();
        ctx.moveTo(s * R * 0.5 - 5, R * 0.4); ctx.lineTo(s * R * 0.5, R * 0.9); ctx.lineTo(s * R * 0.5 + 5, R * 0.4);
        ctx.closePath(); ctx.fill();
      }
    }
    // hit flash
    if (z.flash > 0) {
      ctx.globalAlpha = Math.min(1, z.flash * 8) * 0.7;
      ctx.fillStyle = "#ffeeee";
      ctx.beginPath(); ctx.ellipse(0, -R * 0.4, R, R * 1.2, 0, 0, TAU); ctx.fill();
      ctx.globalAlpha = z.dead ? clamp(1 - (1 - z.deathT / 0.5) * 0.7, 0, 1) : 1;
    }
    // lentidão do campo de força: brilho azul
    if ((z.slowT ?? 0) > 0 && !z.dead) {
      ctx.globalAlpha = 0.4;
      ctx.fillStyle = "#7db8ff";
      ctx.beginPath(); ctx.ellipse(0, -R * 0.4, R * 0.9, R * 1.15, 0, 0, TAU); ctx.fill();
      ctx.globalAlpha = 1;
    }
    ctx.restore();
    // brute hp bar
    if (z.type === "brute" && !z.dead && z.hp < z.maxHp) {
      ctx.fillStyle = "rgba(0,0,0,0.6)";
      ctx.fillRect(z.x - 26, z.y - z.radius - 18, 52, 6);
      ctx.fillStyle = "#ff9d2e";
      ctx.fillRect(z.x - 26, z.y - z.radius - 18, 52 * clamp(z.hp / z.maxHp, 0, 1), 6);
    }
  }

  private drawPlayer() {
    const { ctx } = this;
    ctx.save();
    ctx.translate(this.px, this.py);
    // shadow
    ctx.fillStyle = "rgba(0,0,0,0.45)";
    ctx.beginPath(); ctx.ellipse(0, 10, 16, 8, 0, 0, TAU); ctx.fill();
    // movement tilt
    const moving = Math.hypot(this.pvx, this.pvy) > 40;
    const bob = moving ? Math.sin(this.time * 11) * 1.5 : 0;
    ctx.translate(0, bob * 0.4);
    const bodyAng = this.aim;
    ctx.rotate(bodyAng + Math.PI / 2);
    // legs
    ctx.strokeStyle = "#1d2126"; ctx.lineWidth = 8; ctx.lineCap = "round";
    const lp = moving ? Math.sin(this.time * 11) * 6 : 0;
    ctx.beginPath(); ctx.moveTo(-5, 2); ctx.lineTo(-6, 14 + lp); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(5, 2); ctx.lineTo(6, 14 - lp); ctx.stroke();
    // torso (tactical vest)
    ctx.fillStyle = "#2e3a2e";
    ctx.beginPath(); ctx.ellipse(0, -2, 12, 14, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = "#1c241c";
    ctx.fillRect(-8, -10, 16, 12);
    // head/helmet
    ctx.fillStyle = "#c9a189";
    ctx.beginPath(); ctx.arc(0, -16, 7, 0, TAU); ctx.fill();
    ctx.fillStyle = "#37402f";
    ctx.beginPath(); ctx.arc(0, -17, 8.5, Math.PI, TAU); ctx.fill();
    // gun
    const w = this.weapons[this.cur];
    const def = WEAPONS[w.defId];
    const gunLen = def.id === "m1911" ? 20 : def.id === "raygun" ? 30 : 34;
    ctx.rotate(-Math.PI / 2); // now facing +x (aim dir)
    ctx.fillStyle = def.id === "raygun" ? "#1d3a26" : "#101216";
    ctx.fillRect(4, -3.5, gunLen, 7);
    ctx.fillStyle = def.id === "raygun" ? "#5dff8d" : def.id === "mp5k" ? "#57c8ff" : def.id === "ak47" ? "#c98a3d" : "#8a8f96";
    ctx.fillRect(4 + gunLen - 8, -2, 8, 4);
    // hands
    ctx.fillStyle = "#c9a189";
    ctx.beginPath(); ctx.arc(12, -6, 4, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.arc(22, 3, 4, 0, TAU); ctx.fill();
    // muzzle flash
    if (this.muzzle > 0) {
      const mx = 4 + gunLen;
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.fillStyle = def.id === "raygun" ? "rgba(93,255,141,0.9)" : "rgba(255,200,100,0.9)";
      ctx.beginPath();
      const r = def.id === "raygun" ? 16 : 12;
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * TAU + rand(-0.2, 0.2);
        const rr = r * rand(0.6, 1.3);
        ctx.lineTo(mx + Math.cos(a) * rr, Math.sin(a) * rr);
      }
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = "#fff";
      ctx.beginPath(); ctx.arc(mx, 0, 4, 0, TAU); ctx.fill();
      ctx.restore();
    }
    ctx.restore();
    // reload ring
    if (this.reloading) {
      const def2 = this.curDef();
      const p = 1 - this.reloadT / def2.reloadTime;
      ctx.strokeStyle = "rgba(0,0,0,0.5)"; ctx.lineWidth = 5;
      ctx.beginPath(); ctx.arc(this.px, this.py - 28, 12, 0, TAU); ctx.stroke();
      ctx.strokeStyle = "#ffe9a8"; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(this.px, this.py - 28, 12, -Math.PI / 2, -Math.PI / 2 + p * TAU); ctx.stroke();
    }
  }

  /* ---------------- snapshot ---------------- */
  getSnapshot(): HudSnapshot {
    const w = this.weapons[this.cur];
    const def = WEAPONS[w.defId];
    const alive = this.zombies.filter((z) => !z.dead).length;
    const st = this.nearestStation();
    let nearBuy: NearBuy | null = null;
    if (st) {
      const d = WEAPONS[st.weaponId];
      const owned = this.weapons.some((x) => x.defId === st.weaponId);
      const price = owned ? d.ammoPrice : d.price;
      nearBuy = {
        label: owned ? `${d.name} — MUNIÇÃO` : d.name,
        price, can: this.points >= price && !(owned && this.weapons.find((x) => x.defId === st.weaponId)?.reserve === d.maxReserve),
        hint: owned ? "Recarregar estoque" : this.weapons.length >= 2 ? "Troca pela arma atual" : "Nova arma",
      };
    }
    return {
      hp: Math.ceil(this.hp), maxHp: this.maxHp, points: this.points,
      score: this.earned + this.round * 250, round: Math.max(1, this.round),
      zombiesLeft: alive + this.queue + (this.intermission > 0 ? 0 : 0),
      alive, kills: this.kills, headshots: this.heads, shots: this.shots, hits: this.hits,
      accuracy: this.shots ? Math.round((this.hits / this.shots) * 100) : 0,
      gameTime: this.time, weaponName: def.name, weaponShort: def.short,
      mag: w.mag, reserve: w.reserve, magSize: def.magSize,
      reloading: this.reloading, reloadPct: this.reloading ? 1 - this.reloadT / def.reloadTime : 0,
      weapons: this.weapons.map((x, i) => ({ short: WEAPONS[x.defId].short, mag: x.mag, reserve: x.reserve, active: i === this.cur })),
      doubleT: Math.max(0, this.doubleT), instaT: Math.max(0, this.instaT),
      banner: this.banner, bannerSub: this.bannerSub, bannerT: Math.max(0, this.bannerT),
      nearBuy, intermission: Math.max(0, this.intermission),
      lowHp: this.hp / this.maxHp < 0.35, recentHit: clamp(this.recentHit, 0, 1),
      nukeFlash: this.nukeFlash, dying: this.dying, fps: this.fps,
      level: this.level, xp: Math.floor(this.xp), xpNeed: this.xpNeed,
      abilities: Object.entries(this.abilityLevels)
        .filter(([, l]) => l > 0)
        .map(([id, l]) => ({ id, name: ABILITIES[id]?.name ?? id, level: l, color: ABILITIES[id]?.color ?? "#fff", icon: ABILITIES[id]?.icon ?? "spark" })),
    };
  }
}

// ============================================================
// DEAD OPS — Ranking REAL (sem nomes falsos) + pronto p/ Firebase
//
// Hoje: 100% local (localStorage), só com partidas de verdade.
// Futuro: troque o backend por Firebase sem mudar as telas —
// veja `src/game/online.ts` e o guia no final deste arquivo.
// ============================================================

export type GameMode = "single" | "duo";

export interface HighScore {
  id: string;
  name: string;
  score: number;
  round: number;
  kills: number;
  /** nível de XP alcançado na partida */
  level: number;
  mode: GameMode;
  date: string;
  createdAt: number;
}

export type NewHighScore = Omit<HighScore, "id" | "createdAt"> & {
  id?: string;
  createdAt?: number;
};

const KEY_V2 = "deadops_nacht_highscores_v2";
const KEY_V1 = "deadops_nacht_highscores_v1";
export const MAX_SCORES = 8;

/** Nomes do ranking antigo de mentira — nunca mais exibidos nem migrados. */
const FAKE_NAMES = new Set(["DEMPSEY", "NIKOLAI", "TAKEO", "RICHTOFEN"]);

export const MODE_LABEL: Record<GameMode, string> = {
  single: "1 JOGADOR",
  duo: "2 JOGADORES",
};

function uid(): string {
  try {
    if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  } catch { /* noop */ }
  return `id-${Date.now()}-${Math.floor(Math.random() * 1e9)}`;
}

function normalize(entry: unknown): HighScore | null {
  if (!entry || typeof entry !== "object") return null;
  const e = entry as Record<string, unknown>;
  const name = String(e.name ?? "SOBREVIVENTE").toUpperCase().slice(0, 12) || "SOBREVIVENTE";
  if (FAKE_NAMES.has(name)) return null; // joga fora o ranking fake antigo
  const score = Number(e.score ?? 0);
  if (!Number.isFinite(score) || score <= 0) return null;
  const mode: GameMode = e.mode === "duo" ? "duo" : "single";
  return {
    id: String(e.id ?? uid()),
    name,
    score: Math.floor(score),
    round: Math.max(1, Math.floor(Number(e.round ?? 1))),
    kills: Math.max(0, Math.floor(Number(e.kills ?? 0))),
    level: Math.max(1, Math.floor(Number(e.level ?? 1))),
    mode,
    date: String(e.date ?? new Date(Number(e.createdAt ?? Date.now())).toLocaleDateString("pt-BR")),
    createdAt: Number(e.createdAt ?? Date.now()),
  };
}

function readAll(): HighScore[] {
  // tenta o formato novo
  try {
    const raw = localStorage.getItem(KEY_V2);
    if (raw) {
      const arr = JSON.parse(raw) as unknown[];
      if (Array.isArray(arr)) {
        const clean = arr.map(normalize).filter((x): x is HighScore => x !== null);
        // migração preguiçosa: garante ordenação
        clean.sort((a, b) => b.score - a.score);
        return clean;
      }
    }
  } catch { /* noop */ }
  // migra recordes REAIS do formato antigo (ignora os fakes)
  try {
    const raw = localStorage.getItem(KEY_V1);
    if (raw) {
      const arr = JSON.parse(raw) as unknown[];
      if (Array.isArray(arr)) {
        const clean = arr.map(normalize).filter((x): x is HighScore => x !== null);
        if (clean.length > 0) {
          persistAll(clean);
          return clean;
        }
      }
    }
  } catch { /* noop */ }
  return [];
}

function persistAll(list: HighScore[]) {
  try {
    list.sort((a, b) => b.score - a.score);
    localStorage.setItem(KEY_V2, JSON.stringify(list.slice(0, 32)));
  } catch { /* noop */ }
}

/** Ranking real deste dispositivo, filtrado por modo. Vazio = sem partidas ainda. */
export function loadScores(mode: GameMode = "single"): HighScore[] {
  return readAll()
    .filter((s) => s.mode === mode)
    .slice(0, MAX_SCORES);
}

export function qualifies(scores: HighScore[], score: number): boolean {
  if (!Number.isFinite(score) || score <= 0) return false;
  if (scores.length < MAX_SCORES) return true;
  return score > scores[scores.length - 1].score;
}

/** Salva um recorde REAL e devolve o top atualizado daquele modo. */
export function saveScore(entry: NewHighScore): HighScore[] {
  const full: HighScore = {
    id: entry.id ?? uid(),
    createdAt: entry.createdAt ?? Date.now(),
    name: (entry.name.trim() || "SOBREVIVENTE").toUpperCase().slice(0, 12),
    score: Math.floor(entry.score),
    round: entry.round,
    kills: entry.kills,
    level: entry.level ?? 1,
    mode: entry.mode ?? "single",
    date: entry.date || new Date().toLocaleDateString("pt-BR"),
  };
  if (full.score <= 0) return loadScores(full.mode);
  const all = readAll();
  all.push(full);
  persistAll(all);
  return loadScores(full.mode);
}

/** Apaga os recordes locais (útil p/ testar que o ranking é de verdade). */
export function clearScores(mode?: GameMode): void {
  try {
    if (!mode) {
      localStorage.removeItem(KEY_V2);
      return;
    }
    persistAll(readAll().filter((s) => s.mode !== mode));
  } catch { /* noop */ }
}

export function formatTime(s: number): string {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

// ============================================================
// BACKEND ABSTRAÍDO — é aqui que o Firebase vai entrar.
// As telas (StartScreen / GameOverScreen) só falam com estas
// funções. Quando o Firebase chegar, implemente a classe abaixo
// e troque `scoresBackend` — nada nas telas precisa mudar.
// ============================================================

export interface ScoreBackend {
  readonly kind: "local" | "firebase";
  loadScores(mode: GameMode): Promise<HighScore[]>;
  saveScore(entry: NewHighScore): Promise<HighScore[]>;
}

export class LocalScoreBackend implements ScoreBackend {
  readonly kind = "local" as const;
  async loadScores(mode: GameMode): Promise<HighScore[]> {
    return loadScores(mode);
  }
  async saveScore(entry: NewHighScore): Promise<HighScore[]> {
    return saveScore(entry);
  }
}

/** Backend ativo hoje. Futuro: `scoresBackend = new FirebaseScoreBackend(db)`. */
export const scoresBackend: ScoreBackend = new LocalScoreBackend();

/*
────────────────────────────────────────────────────────────
GUIA RÁPIDO — FIREBASE (quando você for ligar o online)
────────────────────────────────────────────────────────────
1) npm install firebase
2) Crie `src/game/firebase.ts`:

   import { initializeApp } from "firebase/app";
   import { getFirestore } from "firebase/firestore";
   const app = initializeApp({ apiKey, authDomain, projectId, ... });
   export const db = getFirestore(app);

3) Implemente o backend online (single + duo) com a MESMA interface:

   import { collection, addDoc, query, where, orderBy, limit, getDocs } from "firebase/firestore";
   import type { GameMode, HighScore, NewHighScore, ScoreBackend } from "./scores";

   export class FirebaseScoreBackend implements ScoreBackend {
     readonly kind = "firebase" as const;
     async loadScores(mode: GameMode) {
       const q = query(
         collection(db, "scores"),
         where("mode", "==", mode),
         orderBy("score", "desc"),
         limit(8),
       );
       const snap = await getDocs(q);
       return snap.docs.map(d => ({ id: d.id, ...(d.data() as Omit<HighScore,"id">) }));
     }
     async saveScore(entry: NewHighScore) {
       await addDoc(collection(db, "scores"), { ...entry, createdAt: Date.now() });
       return this.loadScores(entry.mode ?? "single");
     }
   }

   Regras sugeridas (Firestore): leitura pública, escrita autenticada
   (Anonymous Auth basta p/ começar).

4) Para o MULTIPLAYER de 2 jogadores, use Realtime Database ou
   Firestore p/ sala + estado (ver `src/game/online.ts`).
────────────────────────────────────────────────────────────
*/

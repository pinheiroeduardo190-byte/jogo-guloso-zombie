// ============================================================
// DEAD OPS — Camada ONLINE (Firebase) — single + duo (2 jogadores)
//
// STATUS HOJE: OFFLINE. O jogo roda 100% local em modo single.
// Este arquivo deixa tudo tipado e pronto para quando você
// ligar o Firebase, sem precisar reescrever as telas.
//
// ROADMAP SUGERIDO:
//  1) Ranking online (single + duo)  -> Firestore, coleção "scores"
//  2) Multiplayer 2 jogadores        -> sala + estado em tempo real
//     (Realtime Database p/ posição/tiros a 10-15Hz + Firestore p/ resultado)
// ============================================================

import type { GameMode } from "./scores";

export const ONLINE_ENABLED = false;
export const FIREBASE_CONFIGURED = false;

/** Modos de jogo. "duo" fica bloqueado até o Firebase entrar. */
export type PlayMode = GameMode;

export const PLAY_MODES: { id: PlayMode; label: string; hint: string; available: boolean }[] = [
  { id: "single", label: "1 JOGADOR", hint: "Sobreviva sozinho — online e local", available: true },
  { id: "duo", label: "2 JOGADORES", hint: "Co-op online — requer Firebase (em breve)", available: false },
];

/** Estado mínimo de um jogador remoto (para o netcode futuro). */
export interface NetPlayerState {
  id: string;
  name: string;
  x: number;
  y: number;
  aim: number;
  hp: number;
  weapon: string;
  updatedAt: number;
}

/** Estado da sala duo (2 jogadores). */
export interface DuoRoom {
  code: string; // ex: "NACHT-4F8K"
  hostId: string;
  players: NetPlayerState[];
  round: number;
  seed: number;
  createdAt: number;
}

export function makeRoomCode(): string {
  const chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 4; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return `NACHT-${s}`;
}

/** Chamado quando alguém tenta abrir o modo duo antes do Firebase. */
export function duoUnavailableMessage(): string {
  return "Modo 2 jogadores chega com o Firebase — ranking e co-op online. Por enquanto, o modo single já salva tudo.";
}

/*
────────────────────────────────────────────────────────────
COMO LIGAR O MULTIPLAYER (quando chegar a hora)
────────────────────────────────────────────────────────────
1) npm install firebase
2) Configure `src/game/firebase.ts` (ver guia em scores.ts).
3) Salas duo com Realtime Database:

   rooms/{code} = {
     hostId, round, seed, createdAt,
     players: { [playerId]: NetPlayerState },
     events: { [pushId]: { type: "shot"|"hit"|"kill"|"drop", ... } }
   }

   - Host = autoridade do round/spawn; guest espelha.
   - Envie posição a ~12Hz, tiros como eventos (não a 60fps).
   - Valide kills/pontos no host para evitar cheat.
4) No final, salve o recorde com mode: "duo" na coleção "scores".
5) Troque PLAY_MODES duo -> available: true e ONLINE_ENABLED = true.
────────────────────────────────────────────────────────────
*/

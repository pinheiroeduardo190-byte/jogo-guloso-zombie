/* Procedural WebAudio sound manager — no assets needed, COD-Zombies flavoured */

export class SoundManager {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private ambienceNodes: { stop: () => void } | null = null;
  muted = false;

  constructor() {
    try {
      this.muted = localStorage.getItem("dz_muted") === "1";
    } catch {
      this.muted = false;
    }
  }

  /** Must be called from a user gesture */
  ensure() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return;
    }
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.55;
      this.master.connect(this.ctx.destination);
      // shared noise buffer (2s)
      const len = this.ctx.sampleRate * 2;
      this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    } catch {
      this.ctx = null;
    }
  }

  setMuted(m: boolean) {
    this.muted = m;
    try {
      localStorage.setItem("dz_muted", m ? "1" : "0");
    } catch { /* noop */ }
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.55, this.ctx.currentTime, 0.02);
    }
  }

  private now() {
    return this.ctx ? this.ctx.currentTime : 0;
  }

  private noise(dur: number, filterType: BiquadFilterType, freq: number, gain: number, when = 0, sweepTo?: number, q = 1) {
    if (!this.ctx || !this.master || !this.noiseBuf) return;
    const t = this.now() + when;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    src.playbackRate.value = 0.7 + Math.random() * 0.6;
    const f = this.ctx.createBiquadFilter();
    f.type = filterType;
    f.frequency.setValueAtTime(freq, t);
    if (sweepTo !== undefined) f.frequency.exponentialRampToValueAtTime(Math.max(20, sweepTo), t + dur);
    f.Q.value = q;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(gain, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(g); g.connect(this.master);
    src.start(t, Math.random() * 1.5);
    src.stop(t + dur + 0.05);
  }

  private tone(type: OscillatorType, f0: number, f1: number, dur: number, gain: number, when = 0, curve: "exp" | "lin" = "exp") {
    if (!this.ctx || !this.master) return;
    const t = this.now() + when;
    const o = this.ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(Math.max(20, f0), t);
    if (curve === "exp") o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    else o.frequency.linearRampToValueAtTime(Math.max(20, f1), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(gain, t + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(this.master);
    o.start(t); o.stop(t + dur + 0.05);
  }

  ui() { this.ensure(); this.tone("square", 700, 500, 0.06, 0.08); }
  empty() { this.tone("square", 2200, 1800, 0.04, 0.1); }
  hitmark() { this.tone("sine", 1900, 1500, 0.045, 0.12); }
  headshot() { this.tone("square", 2600, 1800, 0.06, 0.14); this.tone("sine", 3400, 2600, 0.08, 0.08, 0.01); }
  reload() {
    this.noise(0.07, "bandpass", 2500, 0.25);
    this.noise(0.07, "bandpass", 1500, 0.3, 0.16);
    this.noise(0.09, "bandpass", 3200, 0.3, 0.34);
  }
  shoot(id: string) {
    this.ensure();
    if (!this.ctx) return;
    if (id === "m1911") {
      this.tone("square", 220, 45, 0.13, 0.5);
      this.noise(0.12, "highpass", 900, 0.5);
      this.noise(0.2, "lowpass", 5000, 0.35, 0, 300);
    } else if (id === "mp5k") {
      this.tone("square", 300, 60, 0.09, 0.4);
      this.noise(0.09, "highpass", 1400, 0.4);
      this.noise(0.14, "lowpass", 6000, 0.28, 0, 400);
    } else if (id === "ak47") {
      this.tone("sawtooth", 160, 35, 0.16, 0.55);
      this.noise(0.14, "highpass", 700, 0.5);
      this.noise(0.25, "lowpass", 3500, 0.4, 0, 200);
    } else {
      // raygun — retro sci-fi zap
      this.tone("sawtooth", 1400, 90, 0.28, 0.4);
      this.tone("square", 700, 60, 0.28, 0.25, 0.01);
      this.noise(0.25, "highpass", 3000, 0.25);
      this.tone("sine", 2200, 300, 0.2, 0.15, 0.02);
    }
  }
  zombieHit() { this.noise(0.1, "lowpass", 500, 0.35); this.tone("sine", 180, 90, 0.1, 0.2); }
  bloodKill() {
    this.noise(0.25, "lowpass", 600, 0.5, 0, 120);
    this.tone("sine", 140, 40, 0.25, 0.4);
  }
  groan() {
    if (!this.ctx || this.muted) return;
    if (Math.random() < 0.5) return; // throttle
    const kind = Math.random();
    if (kind < 0.45) {
      // MACHO BRUTO: gutural profundo de peito
      const p = 48 + Math.random() * 35;
      this.tone("sawtooth", p, p * 0.5, 0.9 + Math.random() * 0.5, 0.11);
      this.tone("sawtooth", p * 1.5, p * 0.7, 0.7, 0.06, 0.06);
      this.noise(0.5, "lowpass", 350, 0.08, 0.05, 150);
    } else if (kind < 0.8) {
      // rosnado agressivo com distorção
      const p = 70 + Math.random() * 45;
      this.tone("sawtooth", p, p * 0.6, 0.55, 0.09);
      this.tone("square", p * 0.5, p * 0.32, 0.6, 0.07, 0.04);
      this.noise(0.3, "lowpass", 500, 0.07, 0.02, 200);
    } else {
      // urro de runner — grave e feroz (nada agudo)
      const p = 130 + Math.random() * 70;
      this.tone("sawtooth", p, p * 0.45, 0.5, 0.08);
      this.tone("sawtooth", p * 0.5, p * 0.3, 0.55, 0.06, 0.05);
      this.noise(0.3, "bandpass", 600, 0.07, 0.02);
    }
  }
  zombieAttack() {
    if (!this.ctx || this.muted) return;
    this.noise(0.14, "lowpass", 600, 0.35);
    this.tone("sawtooth", 120, 50, 0.28, 0.28);
    this.tone("square", 70, 38, 0.3, 0.18, 0.03);
  }
  barrierHit() {
    if (!this.ctx) return;
    this.noise(0.1, "lowpass", 900, 0.4);
    this.tone("square", 180, 90, 0.09, 0.22);
    this.noise(0.06, "highpass", 1800, 0.12, 0.01);
  }
  plankBreak() {
    if (!this.ctx) return;
    this.noise(0.22, "lowpass", 1400, 0.5, 0, 200);
    this.tone("square", 300, 80, 0.18, 0.25);
    this.noise(0.12, "highpass", 2500, 0.2, 0.02);
  }
  rebuild() {
    if (!this.ctx) return;
    // marteladas: 2 batidas secas + clique de madeira
    this.noise(0.06, "bandpass", 2200, 0.4, 0, 900, 2);
    this.tone("square", 420, 180, 0.06, 0.2);
    this.noise(0.06, "bandpass", 2400, 0.35, 0.11, 900, 2);
    this.tone("square", 460, 200, 0.06, 0.18, 0.11);
  }
  doorBuy() {
    if (!this.ctx) return;
    // rangido + metal pesado + clique
    this.tone("sawtooth", 90, 60, 0.7, 0.25);
    this.noise(0.5, "lowpass", 600, 0.35, 0.05, 150);
    this.tone("square", 240, 480, 0.12, 0.18, 0.55);
    this.noise(0.08, "highpass", 3000, 0.2, 0.55);
  }
  cash() {
    if (!this.ctx) return;
    this.tone("sine", 1320, 1320, 0.06, 0.12);
    this.tone("sine", 1760, 1760, 0.09, 0.12, 0.06);
  }
  powerUp() {
    if (!this.ctx) return;
    this.tone("sawtooth", 60, 120, 0.5, 0.25);
    this.tone("sine", 120, 480, 0.6, 0.18, 0.1);
    this.noise(0.4, "highpass", 2000, 0.12, 0.3);
    this.tone("sine", 880, 880, 0.2, 0.16, 0.55);
  }
  packPunch() {
    if (!this.ctx) return;
    this.tone("sawtooth", 200, 800, 0.4, 0.25);
    this.tone("sawtooth", 100, 400, 0.5, 0.2, 0.1);
    this.noise(0.5, "bandpass", 3000, 0.2, 0.15, 800, 2);
    this.tone("sine", 1320, 1320, 0.3, 0.18, 0.5);
  }
  detector() {
    if (!this.ctx) return;
    for (let i = 0; i < 3; i++) {
      this.tone("square", 2100, 2100, 0.09, 0.2, i * 0.12);
    }
  }
  relay() {
    if (!this.ctx) return;
    this.tone("sine", 660, 1320, 0.4, 0.2);
    this.tone("sine", 990, 1980, 0.4, 0.12, 0.1);
    this.noise(0.3, "highpass", 4000, 0.1, 0.2);
  }
  perkBuy() {
    if (!this.ctx) return;
    this.tone("sine", 440, 440, 0.1, 0.2);
    this.tone("sine", 554, 554, 0.1, 0.2, 0.1);
    this.tone("sine", 659, 659, 0.18, 0.22, 0.2);
  }
  partPickup() {
    if (!this.ctx) return;
    this.tone("triangle", 700, 1400, 0.15, 0.2);
    this.noise(0.1, "highpass", 5000, 0.12, 0.05);
  }
  antenna() {
    if (!this.ctx) return;
    this.tone("sine", 300, 900, 1.0, 0.25);
    this.tone("sine", 150, 450, 1.2, 0.2, 0.1);
    this.noise(1.0, "lowpass", 2000, 0.3, 0.1, 200);
  }
  playerHurt() {
    this.tone("sawtooth", 200, 60, 0.3, 0.4);
    this.noise(0.25, "lowpass", 800, 0.4);
    this.tone("sine", 65, 40, 0.4, 0.5, 0.02);
  }
  buy() {
    this.tone("sine", 880, 880, 0.09, 0.2);
    this.tone("sine", 1320, 1320, 0.14, 0.2, 0.09);
    this.noise(0.08, "highpass", 5000, 0.12, 0.02);
  }
  deny() { this.tone("square", 160, 110, 0.22, 0.2); }
  pickup() {
    this.tone("sine", 520, 520, 0.08, 0.2);
    this.tone("sine", 660, 660, 0.08, 0.2, 0.08);
    this.tone("sine", 880, 880, 0.12, 0.22, 0.16);
  }
  nuke() {
    this.noise(1.6, "lowpass", 2500, 0.8, 0, 60);
    this.tone("sine", 70, 24, 1.6, 0.7);
    this.noise(0.4, "highpass", 2000, 0.4);
  }
  roundStart() {
    this.tone("sawtooth", 58, 55, 1.1, 0.35);
    this.tone("sawtooth", 87, 82, 1.1, 0.25, 0.02);
    this.tone("sine", 440, 438, 0.9, 0.08, 0.05);
    this.noise(0.8, "lowpass", 300, 0.25, 0, 80);
  }
  gameOver() {
    this.tone("sawtooth", 220, 55, 1.6, 0.3);
    this.tone("sawtooth", 165, 41, 1.8, 0.25, 0.15);
    this.tone("sine", 55, 30, 2.0, 0.4, 0.1);
  }
  wave() { this.tone("sine", 300, 600, 0.15, 0.12); }
  levelup() {
    this.tone("sine", 520, 520, 0.1, 0.22);
    this.tone("sine", 660, 660, 0.1, 0.22, 0.09);
    this.tone("sine", 880, 880, 0.16, 0.24, 0.18);
    this.tone("sine", 1320, 1320, 0.24, 0.16, 0.27);
    this.noise(0.3, "highpass", 6000, 0.1, 0.05);
  }
  nova() {
    this.tone("sine", 180, 40, 0.5, 0.5);
    this.noise(0.4, "lowpass", 3000, 0.4, 0, 200);
    this.tone("sine", 1200, 2400, 0.25, 0.1);
  }
  thunder() {
    this.noise(0.18, "highpass", 2500, 0.5);
    this.tone("sawtooth", 1800, 120, 0.3, 0.3);
    this.tone("sine", 90, 35, 0.4, 0.4, 0.02);
  }
  knifeSwing() {
    this.ensure(); if (!this.ctx) return;
    this.noise(0.16, "bandpass", 2600, 0.4, 0, 700, 2.5);
    this.tone("sine", 900, 300, 0.12, 0.1);
  }
  knifeHit() {
    if (!this.ctx) return;
    this.noise(0.14, "lowpass", 900, 0.55);
    this.tone("sawtooth", 320, 90, 0.16, 0.35);
    this.tone("sine", 1400, 900, 0.07, 0.16, 0.01);
  }
  jump() { this.noise(0.09, "bandpass", 700, 0.14); this.tone("sine", 220, 340, 0.1, 0.08); }
  land() {
    if (!this.ctx) return;
    this.noise(0.12, "lowpass", 500, 0.4);
    this.tone("sine", 120, 55, 0.14, 0.3);
  }
  step(run = false) {
    if (!this.ctx || this.muted) return;
    if (Math.random() < 0.4) return;
    const f = 380 + Math.random() * 260;
    this.noise(0.05, "bandpass", f, run ? 0.13 : 0.09, 0, f * 0.6, 1.4);
  }

  startAmbience() {
    this.ensure();
    if (!this.ctx || !this.master || this.ambienceNodes) return;
    try {
      const ctx = this.ctx;
      const g = ctx.createGain();
      g.gain.value = 0.045;
      g.connect(this.master);
      const src = ctx.createBufferSource();
      src.buffer = this.noiseBuf;
      src.loop = true;
      const f = ctx.createBiquadFilter();
      f.type = "lowpass"; f.frequency.value = 240; f.Q.value = 0.6;
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 0.07;
      const lfoG = ctx.createGain();
      lfoG.gain.value = 90;
      lfo.connect(lfoG); lfoG.connect(f.frequency);
      const drone = ctx.createOscillator();
      drone.type = "sine"; drone.frequency.value = 48;
      const droneG = ctx.createGain();
      droneG.gain.value = 0.5;
      drone.connect(droneG); droneG.connect(g);
      src.connect(f); f.connect(g);
      src.start(); lfo.start(); drone.start();
      this.ambienceNodes = {
        stop: () => { try { src.stop(); lfo.stop(); drone.stop(); } catch { /*noop*/ } g.disconnect(); },
      };
    } catch { /* noop */ }
  }
}

export const sound = new SoundManager();

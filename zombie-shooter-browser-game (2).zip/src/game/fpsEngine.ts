/* ============================================================
   DEAD OPS: NACHT — 3D FPS engine v2 (Three.js, visual overhaul)
   Bloom + sombras dinâmicas + PBR + ADS + props + FX ricos.
   Mesma API/gameplay — só o visual foi 100% refeito.
   ============================================================ */
import * as THREE from "three";
import { EffectComposer } from "three/addons/postprocessing/EffectComposer.js";
import { RenderPass } from "three/addons/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/addons/postprocessing/UnrealBloomPass.js";
import { ShaderPass } from "three/addons/postprocessing/ShaderPass.js";
import { OutputPass } from "three/addons/postprocessing/OutputPass.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { MAPS, outerGaps, type MapDef, type MapId } from "./maps";
import { sound } from "./audio";
import { voice } from "./voice";
import {
  ABILITIES, rollChoices, xpNeedForLevel, fieldParams, bladeParams, novaParams, thunderParams,
  RAPID_MULT, DMG_MULT, PIERCE_N, CRIT_CH, CRIT_MULT, BOOTS_MULT, MAGNET_R, MAGNET_XP,
  REGEN_MAX, REGEN_RATE, VAMP_KILL, VAMP_HIT,
  type Choice,
} from "./abilities";

export interface HudWeapon { short: string; mag: number; reserve: number; active: boolean; }
export interface NearBuy { label: string; price: number; can: boolean; hint: string; kind: "station" | "door" | "window" | "power" | "pack" | "perk" | "relay" | "workbench"; lockedReason?: string; }
export interface AbilityHud { id: string; name: string; level: number; color: string; icon: string; }
export interface HudSnapshot {
  hp: number; maxHp: number; points: number; score: number; round: number;
  zombiesLeft: number; alive: number; kills: number; headshots: number;
  shots: number; hits: number; accuracy: number; gameTime: number;
  weaponName: string; weaponShort: string; mag: number; reserve: number; magSize: number;
  reloading: boolean; reloadPct: number; weapons: HudWeapon[];
  doubleT: number; instaT: number; banner: string; bannerSub: string; bannerT: number;
  nearBuy: NearBuy | null; intermission: number; lowHp: boolean; recentHit: number;
  nukeFlash: number; dying: number; fps: number;
  level: number; xp: number; xpNeed: number; abilities: AbilityHud[];
  hitA: number; hitKill: boolean; hitHead: boolean;
  locked: boolean; spread: number; ads: number;
  crouched: boolean; airborne: boolean; knifing: number;
}
export interface GameStats { score: number; points: number; round: number; kills: number; headshots: number; shots: number; hits: number; time: number; level: number; }

interface WeaponDef {
  id: string; name: string; short: string; damage: number; headMult: number;
  interval: number; magSize: number; startReserve: number; maxReserve: number;
  reloadTime: number; spread: number; range: number; auto: boolean;
  price: number; ammoPrice: number; kick: number; tracer: string; aoe: number;
}
const WEAPONS: Record<string, WeaponDef> = {
  m1911: { id: "m1911", name: "M1911 Pistola", short: "M1911", damage: 46, headMult: 2.2, interval: 0.24, magSize: 8, startReserve: 96, maxReserve: 160, reloadTime: 1.05, spread: 0.014, range: 60, auto: true, price: 0, ammoPrice: 300, kick: 0.1, tracer: "#ffd37a", aoe: 0 },
  mp5k: { id: "mp5k", name: "MP5K", short: "MP5K", damage: 32, headMult: 1.9, interval: 0.092, magSize: 30, startReserve: 150, maxReserve: 300, reloadTime: 1.6, spread: 0.028, range: 55, auto: true, price: 1000, ammoPrice: 500, kick: 0.055, tracer: "#9adcff", aoe: 0 },
  ak47: { id: "ak47", name: "AK-47", short: "AK47", damage: 60, headMult: 2.0, interval: 0.132, magSize: 30, startReserve: 120, maxReserve: 270, reloadTime: 1.9, spread: 0.018, range: 70, auto: true, price: 2500, ammoPrice: 1000, kick: 0.09, tracer: "#ffb066", aoe: 0 },
  raygun: { id: "raygun", name: "Ray Gun MK-II", short: "RAY", damage: 230, headMult: 1.6, interval: 0.34, magSize: 20, startReserve: 80, maxReserve: 160, reloadTime: 2.0, spread: 0.006, range: 80, auto: true, price: 5000, ammoPrice: 2000, kick: 0.22, tracer: "#7dff9a", aoe: 4.5 },
  reaper: { id: "reaper", name: "Ceifador Aethelgard", short: "CEIF", damage: 150, headMult: 1.8, interval: 0.17, magSize: 40, startReserve: 200, maxReserve: 400, reloadTime: 2.1, spread: 0.02, range: 70, auto: true, price: 0, ammoPrice: 1500, kick: 0.08, tracer: "#c77dff", aoe: 0 },
};

interface Owned { defId: string; mag: number; reserve: number; upgraded?: boolean; }
type ZType = "walker" | "runner" | "brute";
interface Zombie {
  id: number; type: ZType;
  group: THREE.Group;
  legL: THREE.Object3D; legR: THREE.Object3D; armL: THREE.Object3D; armR: THREE.Object3D; headM: THREE.Object3D;
  mats: THREE.MeshStandardMaterial[]; eyeGlow: THREE.Sprite;
  dropFromSky: boolean;
  x: number; z: number;
  hp: number; maxHp: number; speed: number; radius: number; damage: number;
  atk: number; spawnT: number; deathT: number; dead: boolean; deadGone: number;
  wob: number; flash: number; lunge: number; groan: number;
  bladeCd: number; slowT: number; slowMult: number;
  scale: number;
  // janelas / barricada
  winId: number; state: "towin" | "barrier" | "enter" | "chase"; barAtk: number;
}
interface Drop { id: number; x: number; z: number; type: "max" | "insta" | "double" | "nuke"; t: number; mesh: THREE.Group; label: THREE.Sprite; beam: THREE.Mesh; }
interface Station { weaponId: string; x: number; z: number; rotY: number; label: string; color: string; zone: string; group: THREE.Group; tag: THREE.Sprite; ring: THREE.Mesh; beam: THREE.Mesh; }
type ZoneId = string;
interface SwitchBox {
  kind: "power" | "relay"; label: string; x: number; z: number; zone: string;
  done: boolean; group: THREE.Group; tag: THREE.Sprite; light: THREE.PointLight; ring: THREE.Mesh;
}
interface PackMachine {
  x: number; z: number; zone: string; label: string;
  group: THREE.Group; tag: THREE.Sprite; light: THREE.PointLight; ring: THREE.Mesh;
}
interface PerkMachine {
  perk: "vigor" | "swift"; x: number; z: number; zone: string; label: string; cost: number; buys: number;
  group: THREE.Group; tag: THREE.Sprite; light: THREE.PointLight;
}
interface PartPickup { x: number; z: number; zone: string; label: string; taken: boolean; mesh: THREE.Group; }
interface Workbench { x: number; z: number; zone: string; label: string; group: THREE.Group; tag: THREE.Sprite; light: THREE.PointLight }
interface Detector { x: number; z: number; zone: string; group: THREE.Group; cd: number }
interface PlankMesh { mesh: THREE.Mesh; full: number; }
interface GameWindow {
  id: number; zone: ZoneId; x: number; z: number; rotY: number;
  inX: number; inZ: number; outX: number; outZ: number;
  planks: number; maxPlanks: number; plankMeshes: PlankMesh[];
  group: THREE.Group; glowMat: THREE.MeshBasicMaterial; tag: THREE.Sprite | null;
  hitT: number; rebuildCd: number; vent?: boolean;
}
interface GameDoor {
  id: string; label: string; x: number; z: number; rotY: number; w: number;
  cost: number; reqRound: number; zone: ZoneId; opened: boolean; opening: number;
  group: THREE.Group; panel: THREE.Mesh; panelL: THREE.Mesh; panelR: THREE.Mesh;
  tag: THREE.Sprite; colliderIdx: number; light: THREE.PointLight; signMat: THREE.MeshBasicMaterial;
}
interface FloatText { spr: THREE.Sprite; cv: HTMLCanvasElement; tex: THREE.CanvasTexture; life: number; max: number; vy: number; }
interface TracerFx { mesh: THREE.Mesh; mat: THREE.MeshBasicMaterial; life: number; max: number; }
interface Particle { alive: boolean; x: number; y: number; z: number; vx: number; vy: number; vz: number; life: number; max: number; size: number; r: number; g: number; b: number; grav: number; drag: number; }
interface Smoke { spr: THREE.Sprite; mat: THREE.SpriteMaterial; life: number; max: number; vx: number; vy: number; vz: number; grow: number; }
interface Hole { mesh: THREE.Mesh; life: number; }
interface Lamp { group: THREE.Group; light: THREE.PointLight; bulb: THREE.Mesh; glow: THREE.Sprite; base: number; phase: number; }
interface FogPlane { mesh: THREE.Mesh; speed: number; }

const TAU = Math.PI * 2;
const rand = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => v < a ? a : v > b ? b : v;
const EYE = 1.66;
const CROUCH_EYE = 0.92;
const MAP_W = 120, MAP_H = 96;
const KNIFE_DMG = 150;
const KNIFE_RANGE = 3.1;

function hexRGB(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  const v = parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16);
  return [((v >> 16) & 255) / 255, ((v >> 8) & 255) / 255, (v & 255) / 255];
}

function canvasTexture(size: number, draw: (c: CanvasRenderingContext2D, s: number) => void, repeat = true): THREE.CanvasTexture {
  const cv = document.createElement("canvas");
  cv.width = cv.height = size;
  const c = cv.getContext("2d")!;
  draw(c, size);
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  if (repeat) tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  else tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.anisotropy = 8;
  return tex;
}

let _glowTex: THREE.Texture | null = null;
function glowTexture(): THREE.Texture {
  if (_glowTex) return _glowTex;
  _glowTex = canvasTexture(128, (c, s) => {
    const g = c.createRadialGradient(s / 2, s / 2, 2, s / 2, s / 2, s / 2);
    g.addColorStop(0, "rgba(255,255,255,1)");
    g.addColorStop(0.35, "rgba(255,255,255,0.5)");
    g.addColorStop(1, "rgba(255,255,255,0)");
    c.fillStyle = g; c.fillRect(0, 0, s, s);
  }, false);
  return _glowTex;
}

let _smokeTex: THREE.Texture | null = null;
function smokeTexture(): THREE.Texture {
  if (_smokeTex) return _smokeTex;
  _smokeTex = canvasTexture(128, (c, s) => {
    for (let i = 0; i < 26; i++) {
      const x = s / 2 + rand(-22, 22), y = s / 2 + rand(-22, 22), r = rand(10, 30);
      const g = c.createRadialGradient(x, y, 1, x, y, r);
      g.addColorStop(0, "rgba(255,255,255,0.16)");
      g.addColorStop(1, "rgba(255,255,255,0)");
      c.fillStyle = g;
      c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
    }
  }, false);
  return _smokeTex;
}

export class ZombieEngine {
  private canvas: HTMLCanvasElement;
  private onGameOver: (s: GameStats) => void;
  private renderer: THREE.WebGLRenderer;
  private composer: EffectComposer | null = null;
  private bloom: UnrealBloomPass | null = null;
  private gradePass: unknown = null;
  private impactLight!: THREE.PointLight;
  private alertLight!: THREE.PointLight;
  private projectorBeam!: THREE.Mesh;
  private ember!: THREE.Points;
  private emberVel!: Float32Array;
  private skyFlashT = 0; private skyFlashLight!: THREE.DirectionalLight;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private raf = 0;
  private running = false;
  paused = false;
  private destroyed = false;
  private last = 0;
  private time = 0;
  private fps = 60;
  private fpsAcc = 0; private fpsN = 0; private fpsT = 0;
  private clockT = 0;
  private quality: "high" | "low";

  onPauseKey: (() => void) | null = null;
  onLevelUp: ((c: Choice[] | null) => void) | null = null;
  onLockLost: (() => void) | null = null;

  // look / move
  private yaw = 0; private pitch = 0;
  private px = 0; private pz = 10; private pvx = 0; private pvz = 0;
  // pulo + agachar
  private feetY = 0; private vy = 0; private grounded = true;
  private crouchK = 0; private landDip = 0; private coyote = 0; private jumpBuf = 0;
  private touchCrouch = false;
  // faca (botão direito)
  private knifeT = 0; private knifeCd = 0; private knifeDidHit = false;
  private rmbHeld = false; private rmbDownT = 0; private rmbFiredKnife = false;
  private knifeRig = new THREE.Group(); private knifeBlade!: THREE.Mesh; private knifeTrail!: THREE.Mesh; private knifeTrailMat!: THREE.MeshBasicMaterial;
  private knifeLight!: THREE.PointLight;
  private keys = new Set<string>();
  private mouseDown = false;
  private locked = false;
  private bobPhase = 0; private stepT = 0;
  private trauma = 0;
  private fovKick = 0;
  private swayX = 0; private swayY = 0;
  private kickT = 0;
  private ads = false; private adsK = 0;
  isTouch = false;
  private touchMove = { x: 0, y: 0 };
  private touchFiring = false;

  // player state
  private hp = 150; private maxHp = 150; private lastDmg = -99;
  private weapons: Owned[] = [{ defId: "m1911", mag: 8, reserve: 96 }];
  private cur = 0; private fireCd = 0; private reloadT = 0; private reloading = false;
  private muzzleT = 0; private recentHit = 0; private dying = 0; private deadDone = false;
  private crossKick = 0;
  private hitA = 0; private hitKill = false; private hitHead = false;

  // rounds
  private round = 1; private queue = 0; private spawnT = 0; private spawnInterval = 1;
  private intermission = 0; private banner = ""; private bannerSub = ""; private bannerT = 0;
  private zid = 1;

  // xp & abilities
  level = 1; private xp = 0; private xpNeed = xpNeedForLevel(1);
  private abilityLevels: Record<string, number> = {};
  private pendingLevels = 0;
  private currentChoices: Choice[] | null = null;
  private bladeAngle = 0; private novaT = 0; private thunderT = 0;
  private perkVigor = 0; private perkSwift = 0;

  // score
  private points = 500; private earned = 500; private kills = 0; private heads = 0; private shots = 0; private hits = 0;
  private doubleT = 0; private instaT = 0; private nukeFlash = 0;
  private voiceStreak = 0; private voiceStreakT = 0;

  // world
  mapId: MapId = "subzero";
  private mapDef: MapDef = MAPS.subzero;
  private zombies: Zombie[] = [];
  private drops: Drop[] = [];
  private stations: Station[] = [];
  private spawns: { x: number; z: number }[] = [];
  private windows: GameWindow[] = [];
  private doors: GameDoor[] = [];
  private switches: SwitchBox[] = [];
  private packMachine: PackMachine | null = null;
  private perkMachines: PerkMachine[] = [];
  private partPickups: PartPickup[] = [];
  private workbench: Workbench | null = null;
  private detectors: Detector[] = [];
  private powerOn = false;
  private partsFound = 0;
  private relaysDone = 0;
  private attractT = 0;
  private zonesOpen: Record<string, boolean> = { start: true };
  private winId = 1;
  private repairCd = 0;
  private colliders: { x1: number; z1: number; x2: number; z2: number }[] = [];
  private blockerMeshes: THREE.Object3D[] = [];
  private gateMats: THREE.MeshBasicMaterial[] = [];
  private lamps: Lamp[] = [];
  private fogPlanes: FogPlane[] = [];
  private dust!: THREE.Points;
  private dustVel!: Float32Array;
  private dropId = 1;

  // fx
  private particles: Particle[] = [];
  private pMesh!: THREE.InstancedMesh;
  private pDummy = new THREE.Object3D();
  private pColor = new THREE.Color();
  private tracers: TracerFx[] = [];
  private texts: FloatText[] = [];
  private decals: { mesh: THREE.Mesh; mat: THREE.MeshBasicMaterial; life: number }[] = [];
  private smokes: Smoke[] = [];
  private holes: Hole[] = [];
  private holeTex!: THREE.Texture;
  private bloodTex!: THREE.Texture;
  private raycaster = new THREE.Raycaster();
  private tmpV1 = new THREE.Vector3(); private tmpV2 = new THREE.Vector3();
  private tmpDir = new THREE.Vector3();

  // lights & weapon
  private flash!: THREE.SpotLight;
  private muzzleLight!: THREE.PointLight;
  private boomLight!: THREE.PointLight;
  private gunRoot = new THREE.Group();
  private muzzleTip = new THREE.Object3D();
  private flashSprite!: THREE.Sprite;
  private flashStar!: THREE.Mesh;
  private novaMesh!: THREE.Mesh; private novaMat!: THREE.MeshBasicMaterial; private novaAnim = 0;
  private novaRing!: THREE.Mesh; private novaRingMat!: THREE.MeshBasicMaterial;
  private boltGroup = new THREE.Group(); private boltAnim = 0;
  private fieldGroup = new THREE.Group(); private fieldMat!: THREE.MeshBasicMaterial; private fieldWire!: THREE.Mesh; private fieldRing!: THREE.Mesh;
  private bladeMeshes: THREE.Group[] = [];
  private bladeGlows: THREE.Sprite[] = [];

  // shared assets
  private geoBox = new THREE.BoxGeometry(1, 1, 1);
  private geoSphere = new THREE.SphereGeometry(0.5, 12, 10);
  private geoCyl = new THREE.CylinderGeometry(0.5, 0.5, 1, 12);
  private gunMetal = new THREE.MeshStandardMaterial({ color: 0x1b1e24, metalness: 0.75, roughness: 0.32 });
  private gunPoly = new THREE.MeshStandardMaterial({ color: 0x23262c, metalness: 0.2, roughness: 0.7 });
  private gunWood = new THREE.MeshStandardMaterial({ color: 0x6b4a2c, metalness: 0.05, roughness: 0.75 });
  private handMat = new THREE.MeshStandardMaterial({ color: 0x8a6f52, roughness: 0.85 });
  private sleeveMat = new THREE.MeshStandardMaterial({ color: 0x2c3327, roughness: 0.9 });

  private detachFns: (() => void)[] = [];
  private started = false;

  constructor(canvas: HTMLCanvasElement, onGameOver: (s: GameStats) => void, mapId: MapId = "subzero") {
    this.canvas = canvas;
    this.onGameOver = onGameOver;
    this.mapId = mapId;
    this.mapDef = MAPS[mapId];
    const coarse = window.matchMedia?.("(pointer: coarse)").matches || "ontouchstart" in window || navigator.maxTouchPoints > 0;
    this.quality = coarse ? "low" : "high";
    this.isTouch = coarse;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: "high-performance" });
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.setPixelRatio(clamp(window.devicePixelRatio || 1, 1, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.scene.fog = new THREE.FogExp2(0x070a07, 0.011);
    this.scene.background = new THREE.Color(0x020302);
    this.camera = new THREE.PerspectiveCamera(75, 1, 0.08, 220);
    this.scene.add(this.camera);
    // reflexos PBR suaves (ambiente) — o pulo visual mais barato
    try {
      const pmrem = new THREE.PMREMGenerator(this.renderer);
      const env = pmrem.fromScene(new RoomEnvironment(), 0.06).texture;
      this.scene.environment = env;
      if ("environmentIntensity" in this.scene) (this.scene as unknown as { environmentIntensity: number }).environmentIntensity = 0.32;
      pmrem.dispose();
    } catch { /* noop */ }
    this.buildLights();
    this.buildWorld();
    this.buildParticles();
    this.buildWeaponRig();
    this.buildKnifeRig();
    this.buildAbilityMeshes();
    this.buildComposer();
    this.resize();
    this.attach();
  }

  private buildComposer() {
    try {
      this.composer = new EffectComposer(this.renderer);
      if (typeof (this.composer as unknown as { setPixelRatio?: (n: number) => void }).setPixelRatio === "function") {
        (this.composer as unknown as { setPixelRatio: (n: number) => void }).setPixelRatio(clamp(window.devicePixelRatio || 1, 1, 2));
      }
      this.composer.addPass(new RenderPass(this.scene, this.camera));
      const size = new THREE.Vector2(
        this.canvas.clientWidth || window.innerWidth,
        this.canvas.clientHeight || window.innerHeight
      );
      this.bloom = new UnrealBloomPass(
        size,
        this.quality === "high" ? 0.32 : 0.18,
        0.45,
        0.85
      );
      this.composer.addPass(this.bloom);
      // grade LIMPA 4K: sem grão, sem aberração cromática — só cor + vinheta leve + dano/flash
      const GradeShader = {
        uniforms: {
          tDiffuse: { value: null as unknown as THREE.Texture },
          uTime: { value: 0 },
          uDamage: { value: 0 },
          uFlash: { value: 0 },
        },
        vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
        fragmentShader: `
          uniform sampler2D tDiffuse; uniform float uTime; uniform float uDamage; uniform float uFlash;
          varying vec2 vUv;
          void main(){
            vec2 uv = vUv;
            vec2 cc = uv - 0.5;
            float r2 = dot(cc, cc);
            // amostragem única: imagem nítida, sem franja azul/vermelha
            vec3 col = texture2D(tDiffuse, uv).rgb;
            // teal & orange SUAVE: sombras levemente frias, altas levemente quentes
            float lum = dot(col, vec3(0.299, 0.587, 0.114));
            col = mix(col, col * vec3(0.97, 1.015, 1.01) + vec3(0.0, 0.006, 0.007), (1.0 - smoothstep(0.0, 0.55, lum)) * 0.5);
            col = mix(col, col * vec3(1.025, 1.0, 0.97) + vec3(0.006, 0.002, 0.0), smoothstep(0.45, 1.0, lum) * 0.4);
            col *= 1.02;
            // vinheta LEVE (só nas bordas, não escurece o jogo)
            col *= mix(1.0, smoothstep(1.05, 0.35, r2 * 1.4), 0.32);
            // flash de dano nas bordas (sangue)
            col = mix(col, vec3(0.45, 0.02, 0.03), uDamage * smoothstep(0.25, 0.9, r2 * 2.0) * 0.85);
            // flash branco (nuke / tiro)
            col = mix(col, vec3(1.0, 0.97, 0.9), clamp(uFlash, 0.0, 1.0) * 0.9);
            gl_FragColor = vec4(col, 1.0);
          }`,
      };
      const grade = new ShaderPass(GradeShader);
      this.composer.addPass(grade);
      this.gradePass = grade;
      this.composer.addPass(new OutputPass());
    } catch {
      this.composer = null;
    }
  }

  /* ============================== LIGHTS ============================== */
  private buildLights() {
    // realismo COD por mapa: base do tema + quentes práticos, sombras nítidas
    const th = this.mapDef.theme;
    this.scene.add(new THREE.HemisphereLight(th.hemiSky, th.hemiGround, 0.9));
    this.scene.add(new THREE.AmbientLight(0x202620, 0.75));
    const moon = new THREE.DirectionalLight(th.moonColor, th.moonIntensity);
    moon.position.set(30, 42, 18);
    moon.castShadow = true;
    moon.shadow.mapSize.set(this.quality === "high" ? 2048 : 1024, this.quality === "high" ? 2048 : 1024);
    moon.shadow.camera.left = -65; moon.shadow.camera.right = 65;
    moon.shadow.camera.top = 55; moon.shadow.camera.bottom = -55;
    moon.shadow.camera.far = 160;
    moon.shadow.bias = -0.0004;
    moon.shadow.normalBias = 0.025;
    this.scene.add(moon);
    // rim verde tóxico vindo do fundo (contraluz)
    const rim = new THREE.DirectionalLight(0x2bff7a, 0.3);
    rim.position.set(-18, 12, -30);
    this.scene.add(rim);
    // preenchimento quente baixo (rebote das lâmpadas)
    const warm = new THREE.PointLight(0xffc98a, 12, 60, 1.8);
    warm.position.set(0, 5.5, 20);
    this.scene.add(warm);
    // lanterna tática (com sombra!)
    this.flash = new THREE.SpotLight(0xfff0c8, 90, 46, 0.6, 0.45, 1.3);
    this.camera.add(this.flash);
    this.flash.position.set(0.15, -0.1, 0.1);
    this.flash.castShadow = true;
    this.flash.shadow.mapSize.set(this.quality === "high" ? 1024 : 512, this.quality === "high" ? 1024 : 512);
    this.flash.shadow.bias = -0.002;
    this.flash.shadow.camera.near = 0.3;
    this.flash.shadow.camera.far = 40;
    this.scene.add(this.flash.target);
    this.muzzleLight = new THREE.PointLight(0xffc06a, 0, 11, 1.6);
    this.muzzleLight.position.set(0.25, -0.15, -0.8);
    this.camera.add(this.muzzleLight);
    this.boomLight = new THREE.PointLight(0xbfffcf, 0, 30, 1.4);
    this.boomLight.position.set(0, 2, 0);
    this.scene.add(this.boomLight);
    // luz de impacto (reaproveitada a cada tiro na parede)
    this.impactLight = new THREE.PointLight(0xffd9a0, 0, 7, 1.8);
    this.scene.add(this.impactLight);
    // alerta giratório vermelho (rounds altos / vida baixa)
    this.alertLight = new THREE.PointLight(0xff2222, 0, 40, 1.4);
    this.alertLight.position.set(0, 6, 0);
    this.scene.add(this.alertLight);
    // flash de relâmpago no céu
    this.skyFlashLight = new THREE.DirectionalLight(0xcfe0ff, 0);
    this.skyFlashLight.position.set(-20, 50, -30);
    this.scene.add(this.skyFlashLight);
    // faca: luz fria rápida no corte
    this.knifeLight = new THREE.PointLight(0xbfe0ff, 0, 6, 1.8);
    this.camera.add(this.knifeLight);
    this.knifeLight.position.set(0.3, -0.1, -1);
  }

  /* ============================== TEXTURES ============================== */
  private groundTex() {
    return canvasTexture(1024, (c, s) => {
      const g0 = c.createLinearGradient(0, 0, s, s);
      g0.addColorStop(0, "#181b18"); g0.addColorStop(0.5, "#121512"); g0.addColorStop(1, "#171a16");
      c.fillStyle = g0; c.fillRect(0, 0, s, s);
      for (let i = 0; i < 2600; i++) {
        const v = Math.random();
        c.fillStyle = v < 0.45 ? `rgba(30,36,30,${0.12 + Math.random() * 0.28})` : v < 0.75 ? `rgba(6,8,6,${0.15 + Math.random() * 0.3})` : v < 0.9 ? `rgba(58,70,56,${0.05 + Math.random() * 0.12})` : `rgba(90,20,20,${0.04 + Math.random() * 0.08})`;
        const r = 2 + Math.random() * 26;
        c.beginPath(); c.ellipse(Math.random() * s, Math.random() * s, r, r * (0.35 + Math.random() * 0.65), Math.random() * 3, 0, TAU); c.fill();
      }
      // SEM grade de concreto: piso limpo 4K, só microfissuras sutis
      c.strokeStyle = "rgba(0,0,0,0.28)"; c.lineWidth = 1.5;
      for (let i = 0; i < 10; i++) {
        let x = Math.random() * s, y = Math.random() * s;
        c.beginPath(); c.moveTo(x, y);
        for (let k = 0; k < 4; k++) { x += rand(-50, 50); y += rand(-50, 50); c.lineTo(x, y); }
        c.stroke();
      }
      // manchas de sangue antigas
      for (let i = 0; i < 14; i++) {
        const x = Math.random() * s, y = Math.random() * s, r = rand(12, 46);
        const g = c.createRadialGradient(x, y, 2, x, y, r);
        g.addColorStop(0, "rgba(70,8,8,0.5)"); g.addColorStop(1, "rgba(70,8,8,0)");
        c.fillStyle = g;
        c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
      }
      // papéis / detritos claros
      for (let i = 0; i < 130; i++) {
        c.fillStyle = `rgba(150,140,110,${0.05 + Math.random() * 0.12})`;
        c.save(); c.translate(Math.random() * s, Math.random() * s); c.rotate(rand(0, 3));
        c.fillRect(0, 0, rand(3, 12), rand(2, 7)); c.restore();
      }
    });
  }

  private wallTex() {
    return canvasTexture(512, (c, s) => {
      c.fillStyle = "#211a14"; c.fillRect(0, 0, s, s);
      c.fillStyle = "rgba(74,56,40,0.55)";
      for (let y = 0; y < s; y += 64) c.fillRect(0, y, s, 5);
      c.fillStyle = "rgba(0,0,0,0.35)";
      for (let x = 0; x < s; x += 64) c.fillRect(x, 0, 3, s);
      for (let i = 0; i < 420; i++) {
        c.fillStyle = `rgba(0,0,0,${0.08 + Math.random() * 0.22})`;
        c.fillRect(Math.random() * s, Math.random() * s, 2 + Math.random() * 10, 2 + Math.random() * 10);
      }
      // mofo verde na base
      const g = c.createLinearGradient(0, s * 0.7, 0, s);
      g.addColorStop(0, "rgba(40,120,60,0)"); g.addColorStop(1, "rgba(30,110,55,0.35)");
      c.fillStyle = g; c.fillRect(0, s * 0.7, s, s * 0.3);
      // respingos de sangue
      for (let i = 0; i < 12; i++) {
        c.fillStyle = `rgba(110,12,12,${0.15 + Math.random() * 0.25})`;
        c.beginPath(); c.arc(Math.random() * s, Math.random() * s, rand(2, 9), 0, TAU); c.fill();
      }
    });
  }

  private textSprite(text: string, opts: { size?: number; color?: string; bg?: string; pad?: number; scale?: number } = {}): THREE.Sprite {
    const { size = 44, color = "#ffe9a8", bg = "rgba(5,8,6,0.82)", pad = 18, scale = 1 } = opts;
    const cv = document.createElement("canvas");
    const c = cv.getContext("2d")!;
    c.font = `bold ${size}px monospace`;
    const w = Math.ceil(c.measureText(text).width) + pad * 2;
    cv.width = w; cv.height = size + pad * 2;
    const c2 = cv.getContext("2d")!;
    c2.fillStyle = bg; c2.fillRect(0, 0, cv.width, cv.height);
    c2.strokeStyle = "rgba(255,255,255,0.25)"; c2.lineWidth = 2; c2.strokeRect(1, 1, cv.width - 2, cv.height - 2);
    c2.font = `bold ${size}px monospace`;
    c2.textAlign = "center"; c2.textBaseline = "middle";
    c2.fillStyle = color;
    c2.fillText(text, cv.width / 2, cv.height / 2 + 2);
    const tex = new THREE.CanvasTexture(cv);
    tex.colorSpace = THREE.SRGBColorSpace;
    const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false });
    const spr = new THREE.Sprite(mat);
    spr.scale.set((cv.width / cv.height) * 0.5 * scale, 0.5 * scale, 1);
    return spr;
  }

  /* ============================== WORLD ============================== */
  private buildWorld() {
    const W = MAP_W, H = MAP_H;
    const th = this.mapDef.theme;
    this.scene.fog = new THREE.FogExp2(th.fogColor, th.fogDensity);
    // céu por mapa
    const skyTex = canvasTexture(512, (c, s) => {
      const g = c.createLinearGradient(0, 0, 0, s);
      g.addColorStop(0, th.skyTop); g.addColorStop(0.55, th.skyMid); g.addColorStop(0.8, th.skyMid); g.addColorStop(1, th.skyBot);
      c.fillStyle = g; c.fillRect(0, 0, s, s);
      for (let i = 0; i < 220; i++) {
        c.fillStyle = `rgba(200,220,255,${0.2 + Math.random() * 0.7})`;
        c.fillRect(Math.random() * s, Math.random() * s * 0.6, 1.4, 1.4);
      }
    }, false);
    const sky = new THREE.Mesh(
      new THREE.SphereGeometry(160, 24, 16),
      new THREE.MeshBasicMaterial({ map: skyTex, side: THREE.BackSide, fog: false, toneMapped: false })
    );
    this.scene.add(sky);

    // chão PBR com tinta do mapa
    const gtex = this.groundTex();
    gtex.repeat.set(9, 7);
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(W + 10, H + 10),
      new THREE.MeshStandardMaterial({ map: gtex, color: th.floorTint, roughness: 0.94, metalness: 0.04 })
    );
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    this.scene.add(floor);
    // faixa central de desgaste por mapa
    this.buildFloorRunner();

    // paredes + pilastras + trim
    const wtex = this.wallTex();
    wtex.repeat.set(8, 1);
    const wallMat = new THREE.MeshStandardMaterial({ map: wtex, color: 0xcbbfa8, roughness: 0.9 });
    const pilMat = new THREE.MeshStandardMaterial({ color: 0x2e2620, roughness: 0.85 });
    void pilMat;
    // paredes externas SEGMENTADAS com vãos nas janelas (dá p/ atirar através)
    const wallGapW = 2.7;
    const mkWallGaps = (horizontal: boolean, fixed: number, from: number, to: number, gaps: number[]) => {
      const sorted = [...gaps].sort((a, b) => a - b);
      let cur = from;
      const segs: [number, number][] = [];
      for (const g of sorted) {
        const gs = g - wallGapW / 2, ge = g + wallGapW / 2;
        if (gs > cur) segs.push([cur, gs]);
        cur = Math.max(cur, ge);
      }
      if (cur < to) segs.push([cur, to]);
      for (const [a, b] of segs) {
        const len = b - a;
        if (len < 0.3) continue;
        const mid = (a + b) / 2;
        if (horizontal) {
          const m = new THREE.Mesh(new THREE.BoxGeometry(len, 7.5, 1), wallMat);
          m.position.set(mid, 3.75, fixed);
          m.castShadow = true; m.receiveShadow = true;
          this.scene.add(m); this.blockerMeshes.push(m);
        } else {
          const m = new THREE.Mesh(new THREE.BoxGeometry(1, 7.5, len), wallMat);
          m.position.set(fixed, 3.75, mid);
          m.castShadow = true; m.receiveShadow = true;
          this.scene.add(m); this.blockerMeshes.push(m);
        }
      }
      // verga acima de cada vão (parede continua em cima)
      for (const g of sorted) {
        if (horizontal) {
          const l = new THREE.Mesh(new THREE.BoxGeometry(wallGapW, 4.1, 1), wallMat);
          l.position.set(g, 5.45, fixed);
          l.castShadow = true;
          this.scene.add(l); this.blockerMeshes.push(l);
        } else {
          const l = new THREE.Mesh(new THREE.BoxGeometry(1, 4.1, wallGapW), wallMat);
          l.position.set(fixed, 5.45, g);
          l.castShadow = true;
          this.scene.add(l); this.blockerMeshes.push(l);
        }
      }
      // pilastras (pulando os vãos)
      const total = to - from;
      const n = Math.max(2, Math.floor(total / 8));
      for (let i = 0; i <= n; i++) {
        const p = from + (total / n) * i;
        if (sorted.some((g) => Math.abs(g - p) < wallGapW)) continue;
        const post = new THREE.Mesh(this.geoBox, pilMat);
        post.scale.set(1, 7.5, 1.4);
        post.castShadow = true;
        if (horizontal) post.position.set(p, 3.75, fixed + 0.5);
        else { post.position.set(fixed + 0.5, 3.75, p); post.rotation.y = Math.PI / 2; }
        this.scene.add(post);
      }
    };
    // vãos derivados das janelas do mapa (a bala atravessa)
    const gaps = outerGaps(this.mapDef);
    mkWallGaps(true, -H / 2 - 0.5, -W / 2 - 1, W / 2 + 1, gaps.north);
    mkWallGaps(true, H / 2 + 0.5, -W / 2 - 1, W / 2 + 1, gaps.south);
    mkWallGaps(false, -W / 2 - 0.5, -H / 2 - 1, H / 2 + 1, gaps.west);
    mkWallGaps(false, W / 2 + 0.5, -H / 2 - 1, H / 2 + 1, gaps.east);
    const trimMat = new THREE.MeshBasicMaterial({ color: 0x2bff7a, toneMapped: false });
    const trim = new THREE.Mesh(new THREE.BoxGeometry(W + 2, 0.12, 0.12), trimMat);
    trim.position.set(0, 2.3, -H / 2 + 0.06); this.scene.add(trim);
    const trim2 = trim.clone(); trim2.position.z = H / 2 - 0.06; this.scene.add(trim2);

    // teto + vigas (interior fechado e realista, sem vazio)
    const ceil = new THREE.Mesh(
      new THREE.PlaneGeometry(W + 10, H + 10),
      new THREE.MeshStandardMaterial({ color: 0x141310, roughness: 0.95 })
    );
    ceil.rotation.x = Math.PI / 2; ceil.position.y = 7.5;
    this.scene.add(ceil);
    const beamMat = new THREE.MeshStandardMaterial({ color: 0x241c12, roughness: 0.85 });
    const coffMat = new THREE.MeshStandardMaterial({ color: 0x1c1712, roughness: 0.9 });
    for (let i = -5; i <= 5; i++) {
      const b = new THREE.Mesh(this.geoBox, beamMat);
      b.scale.set(W, 0.55, 0.8); b.position.set(0, 7.1, i * 8);
      this.scene.add(b);
      const c = new THREE.Mesh(this.geoBox, coffMat);
      c.scale.set(W, 0.12, 3.2); c.position.set(0, 7.42, i * 8 + 4);
      this.scene.add(c);
    }

    // peça central + coberturas + barris por mapa
    this.buildCenterpiece();
    this.buildCover();
    this.buildBarrels();

    // cantos limpos: rodapé + faixas de desgaste alinhadas (sem entulho espalhado)
    const baseMat = new THREE.MeshStandardMaterial({ color: 0x0e0e0c, roughness: 0.9 });
    const skirtN = new THREE.Mesh(this.geoBox, baseMat);
    skirtN.scale.set(W + 2, 0.5, 0.25); skirtN.position.set(0, 0.25, -H / 2 + 0.15);
    this.scene.add(skirtN);
    const skirtS = skirtN.clone(); skirtS.position.z = H / 2 - 0.15; this.scene.add(skirtS);
    const skirtW = new THREE.Mesh(this.geoBox, baseMat);
    skirtW.scale.set(0.25, 0.5, H + 2); skirtW.position.set(-W / 2 + 0.15, 0.25, 0);
    this.scene.add(skirtW);
    const skirtE = skirtW.clone(); skirtE.position.x = W / 2 - 0.15; this.scene.add(skirtE);

    // luzes práticas do teto por mapa
    this.buildMapLamps();
    // névoa em planos + poeira flutuante (tinta do mapa)
    this.buildAtmosphere();
    // fallback de spawn = pontos internos das janelas (uso emergencial)
    // wallbuys do mapa
    for (const s of this.mapDef.stations) this.makeStation(s.w, s.x, s.z, s.ry, s.label, s.color, s.zone);
    // salas, portas e janelas barricadas do mapa
    this.buildRooms();

    // lua com halo
    const moonSpr = this.textSprite("●", { size: 60, color: "#e8efff", bg: "rgba(0,0,0,0)", scale: 7 });
    moonSpr.position.set(34, 46, -70);
    moonSpr.material.fog = false;
    this.scene.add(moonSpr);
    const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: 0x8fa8ff, transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false, fog: false }));
    halo.scale.setScalar(26); halo.position.copy(moonSpr.position);
    this.scene.add(halo);

    // vestimenta do mapa: props, luzes práticas, brasas e lore
    this.dressMap();

    // texturas de FX
    this.holeTex = canvasTexture(128, (c, s) => {
      c.clearRect(0, 0, s, s);
      c.fillStyle = "rgba(0,0,0,0.95)";
      c.beginPath(); c.arc(s / 2, s / 2, 10, 0, TAU); c.fill();
      c.strokeStyle = "rgba(20,12,8,0.9)"; c.lineWidth = 3;
      for (let i = 0; i < 7; i++) {
        const a = (i / 7) * TAU + rand(-0.2, 0.2);
        c.beginPath(); c.moveTo(s / 2 + Math.cos(a) * 8, s / 2 + Math.sin(a) * 8);
        c.lineTo(s / 2 + Math.cos(a) * rand(20, 40), s / 2 + Math.sin(a) * rand(20, 40)); c.stroke();
      }
      c.fillStyle = "rgba(120,90,60,0.5)";
      c.beginPath(); c.arc(s / 2, s / 2, 16, 0, TAU); c.fill();
      c.fillStyle = "rgba(0,0,0,1)";
      c.beginPath(); c.arc(s / 2, s / 2, 9, 0, TAU); c.fill();
    }, false);
    this.bloodTex = canvasTexture(128, (c, s) => {
      c.clearRect(0, 0, s, s);
      const g = c.createRadialGradient(s / 2, s / 2, 4, s / 2, s / 2, 52);
      g.addColorStop(0, "rgba(110,10,10,0.95)"); g.addColorStop(0.6, "rgba(80,8,8,0.7)"); g.addColorStop(1, "rgba(60,5,5,0)");
      c.fillStyle = g;
      c.beginPath(); c.arc(s / 2, s / 2, 52, 0, TAU); c.fill();
      for (let i = 0; i < 10; i++) {
        const a = rand(0, TAU), r = rand(30, 58);
        c.fillStyle = "rgba(90,10,10,0.8)";
        c.beginPath(); c.arc(s / 2 + Math.cos(a) * r, s / 2 + Math.sin(a) * r, rand(2, 6), 0, TAU); c.fill();
      }
    }, false);
  }

  private makeStation(weaponId: string, x: number, z: number, rotY: number, label: string, color: string, zone: string) {
    const g = new THREE.Group();
    g.position.set(x, 0, z); g.rotation.y = rotY;
    const board = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x0e130e, roughness: 0.7 }));
    board.scale.set(2.6, 2.2, 0.3); board.position.set(0, 1.6, 0);
    board.castShadow = true;
    g.add(board);
    const cm = new THREE.MeshBasicMaterial({ color: new THREE.Color(color), toneMapped: false });
    const frame = new THREE.Mesh(this.geoBox, cm);
    frame.scale.set(2.8, 0.12, 0.34); frame.position.set(0, 2.75, 0);
    g.add(frame);
    const frame2 = frame.clone(); frame2.position.y = 0.45; g.add(frame2);
    const gunMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(color), toneMapped: false });
    const gun = new THREE.Mesh(this.geoBox, gunMat);
    gun.scale.set(weaponId === "raygun" ? 1.2 : 1.9, 0.16, 0.16); gun.position.set(0, 1.7, 0.2);
    g.add(gun);
    const grip = new THREE.Mesh(this.geoBox, gunMat);
    grip.scale.set(0.14, 0.5, 0.14); grip.position.set(0.3, 1.4, 0.2);
    g.add(grip);
    // feixe de luz subindo (chama atenção)
    const beam = new THREE.Mesh(
      new THREE.PlaneGeometry(1.6, 3.4),
      new THREE.MeshBasicMaterial({ color: new THREE.Color(color), transparent: true, opacity: 0.14, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false })
    );
    beam.position.set(0, 1.7, 0.35);
    g.add(beam);
    const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: new THREE.Color(color), transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false }));
    halo.scale.setScalar(2.6); halo.position.set(0, 1.7, 0.4);
    g.add(halo);
    // anel no chão (na frente do painel, conforme a rotação)
    const ringPos = new THREE.Vector3(x + Math.sin(rotY) * 1.5, 0.03, z + Math.cos(rotY) * 1.5);
    const ring = new THREE.Mesh(
      new THREE.RingGeometry(1.0, 1.45, 32),
      new THREE.MeshBasicMaterial({ color: new THREE.Color(color), transparent: true, opacity: 0.55, side: THREE.DoubleSide, toneMapped: false, depthWrite: false })
    );
    ring.rotation.x = -Math.PI / 2; ring.position.copy(ringPos);
    this.scene.add(ring);
    const tag = this.textSprite(label, { color, scale: 1.6 });
    tag.position.set(x, 3.5, z);
    this.scene.add(tag);
    if (this.quality === "high") {
      const l = new THREE.PointLight(new THREE.Color(color), 10, 10, 1.8);
      l.position.set(x, 2.4, z + Math.cos(rotY) * 1.6);
      this.scene.add(l);
    }
    this.scene.add(g);
    this.stations.push({ weaponId, x, z, rotY, label, color, zone, group: g, tag, ring, beam });
  }

  /* ============ SALAS / PORTAS / JANELAS (modo clássico) ============ */
  private roomWallMat = new THREE.MeshStandardMaterial({ color: 0x2b241c, roughness: 0.9 });
  private plankMat = new THREE.MeshStandardMaterial({ color: 0x7a5c38, roughness: 0.85 });
  private plankMat2 = new THREE.MeshStandardMaterial({ color: 0x5e462b, roughness: 0.9 });

  private addWallSeg(cx: number, cz: number, w: number, d: number, h = 4.2, mat?: THREE.Material) {
    const m = new THREE.Mesh(this.geoBox, mat ?? this.roomWallMat);
    m.scale.set(w, h, d); m.position.set(cx, h / 2, cz);
    m.castShadow = true; m.receiveShadow = true;
    this.scene.add(m); this.blockerMeshes.push(m);
    this.colliders.push({ x1: cx - w / 2, z1: cz - d / 2, x2: cx + w / 2, z2: cz + d / 2 });
    // faixa superior iluminada
    const strip = new THREE.Mesh(this.geoBox, new THREE.MeshBasicMaterial({ color: 0x1d5c33, toneMapped: false }));
    strip.scale.set(w === d ? w : Math.max(w, 0.2), 0.08, d === w ? d : Math.max(d, 0.2));
    strip.position.set(cx, h + 0.05, cz);
    this.scene.add(strip);
    return m;
  }

  private makeWindow(zone: ZoneId, x: number, z: number, rotY: number, vent = false) {
    const id = this.winId++;
    if (vent) {
      // duto de ventilação no teto: os zumbis CAEM dele (sem barricada)
      const g = new THREE.Group();
      g.position.set(x, 0, z);
      const ductMat = new THREE.MeshStandardMaterial({ color: 0x3a4048, roughness: 0.5, metalness: 0.7 });
      const duct = new THREE.Mesh(this.geoBox, ductMat);
      duct.scale.set(1.6, 1.2, 1.6); duct.position.y = 5.6;
      duct.castShadow = true;
      g.add(duct);
      const grate = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x14161a, roughness: 0.6, metalness: 0.5 }));
      grate.scale.set(1.3, 0.12, 1.3); grate.position.y = 4.95;
      g.add(grate);
      for (let i = -1; i <= 1; i++) {
        const slat = new THREE.Mesh(this.geoBox, grate.material);
        slat.scale.set(1.2, 0.05, 0.12); slat.position.set(0, 4.88, i * 0.35);
        g.add(slat);
      }
      const warn = new THREE.Mesh(this.geoBox, new THREE.MeshBasicMaterial({ color: 0xb79bff, toneMapped: false }));
      warn.scale.set(1.5, 0.06, 0.1); warn.position.y = 4.8;
      g.add(warn);
      const glowMat = new THREE.MeshBasicMaterial({ color: 0x3a1a3a, transparent: true, opacity: 0.3, side: THREE.DoubleSide, toneMapped: false, blending: THREE.AdditiveBlending, depthWrite: false });
      const glow = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 1.6), glowMat);
      glow.rotation.x = -Math.PI / 2; glow.position.y = 4.7;
      g.add(glow);
      this.scene.add(g);
      this.windows.push({ id, zone, x, z, rotY, inX: x, inZ: z, outX: x, outZ: z, planks: 0, maxPlanks: 0, plankMeshes: [], group: g, glowMat, tag: null, hitT: 0, rebuildCd: 0, vent: true });
      return;
    }
    const g = new THREE.Group();
    g.position.set(x, 0, z); g.rotation.y = rotY;
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x191410, roughness: 0.7, metalness: 0.3 });
    // batentes
    for (const px of [-1.2, 1.2]) {
      const post = new THREE.Mesh(this.geoBox, frameMat);
      post.scale.set(0.28, 3.4, 0.5); post.position.set(px, 1.7, 0);
      post.castShadow = true;
      g.add(post);
    }
    const top = new THREE.Mesh(this.geoBox, frameMat);
    top.scale.set(2.7, 0.3, 0.5); top.position.set(0, 3.3, 0);
    top.castShadow = true;
    g.add(top);
    const sill = new THREE.Mesh(this.geoBox, frameMat);
    sill.scale.set(2.7, 0.22, 0.7); sill.position.set(0, 0.55, 0);
    g.add(sill);
    // brilho de alerta (fica vermelho quando zumbi perto)
    const glowMat = new THREE.MeshBasicMaterial({ color: 0x3a1a1a, transparent: true, opacity: 0.35, side: THREE.DoubleSide, toneMapped: false, blending: THREE.AdditiveBlending, depthWrite: false });
    const glow = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 2.6), glowMat);
    glow.position.set(0, 1.9, 0);
    g.add(glow);
    // tábuas (5)
    const plankMeshes: PlankMesh[] = [];
    for (let i = 0; i < 5; i++) {
      const pm = new THREE.Mesh(this.geoBox, i % 2 ? this.plankMat2 : this.plankMat);
      pm.scale.set(2.3, 0.28, 0.1);
      pm.position.set(rand(-0.05, 0.05), 0.95 + i * 0.45, 0);
      pm.rotation.z = rand(-0.06, 0.06);
      pm.castShadow = true;
      g.add(pm);
      plankMeshes.push({ mesh: pm, full: pm.position.y });
    }
    this.scene.add(g);
    // pontos dentro/fora (ao longo da normal)
    const nx = Math.sin(rotY), nz = Math.cos(rotY);
    const inX = x + nx * 1.8, inZ = z + nz * 1.8;
    const outX = x - nx * 3.2, outZ = z - nz * 3.2;
    this.windows.push({ id, zone, x, z, rotY, inX, inZ, outX, outZ, planks: 5, maxPlanks: 5, plankMeshes, group: g, glowMat, tag: null, hitT: 0, rebuildCd: 0 });
  }

  private makeDoor(id: string, label: string, x: number, z: number, rotY: number, w: number, cost: number, reqRound: number, zone: ZoneId) {
    const g = new THREE.Group();
    g.position.set(x, 0, z); g.rotation.y = rotY;
    // portal de pedra/madeira maciça — bem acabado
    const stoneMat = new THREE.MeshStandardMaterial({ color: 0x3a332a, roughness: 0.85 });
    const trimMat = new THREE.MeshStandardMaterial({ color: 0x1f1a13, roughness: 0.7 });
    const brassMat = new THREE.MeshStandardMaterial({ color: 0x8a6f3c, metalness: 0.85, roughness: 0.3 });
    for (const px of [-w / 2 - 0.45, w / 2 + 0.45]) {
      const post = new THREE.Mesh(this.geoBox, stoneMat);
      post.scale.set(0.9, 4.6, 1.1); post.position.set(px, 2.3, 0);
      post.castShadow = true; post.receiveShadow = true;
      g.add(post);
      const cap = new THREE.Mesh(this.geoBox, trimMat);
      cap.scale.set(1.1, 0.25, 1.3); cap.position.set(px, 4.7, 0);
      g.add(cap);
      const base = new THREE.Mesh(this.geoBox, trimMat);
      base.scale.set(1.1, 0.4, 1.3); base.position.set(px, 0.2, 0);
      g.add(base);
    }
    const lintel = new THREE.Mesh(this.geoBox, stoneMat);
    lintel.scale.set(w + 1.8, 0.7, 1.1); lintel.position.set(0, 4.5, 0);
    lintel.castShadow = true;
    g.add(lintel);
    const lintelTrim = new THREE.Mesh(this.geoBox, brassMat);
    lintelTrim.scale.set(w + 1.8, 0.08, 1.12); lintelTrim.position.set(0, 4.12, 0);
    g.add(lintelTrim);
    // portas duplas de madeira com almofadas + vigia + maçaneta
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x4a3421, roughness: 0.65, metalness: 0.08 });
    const woodDark = new THREE.MeshStandardMaterial({ color: 0x2e2114, roughness: 0.7 });
    const mkLeaf = (side: number) => {
      const leaf = new THREE.Group();
      const slab = new THREE.Mesh(this.geoBox, woodMat);
      slab.scale.set(w / 2 - 0.04, 3.7, 0.22); slab.position.set(0, 1.85, 0);
      slab.castShadow = true;
      leaf.add(slab);
      // almofadas
      for (const py of [1.05, 2.2, 3.0]) {
        const inset = new THREE.Mesh(this.geoBox, woodDark);
        inset.scale.set(w / 2 - 0.5, py === 3.0 ? 0.5 : 0.75, 0.06);
        inset.position.set(0, py, 0.1);
        leaf.add(inset);
      }
      // vigia redondo com grade
      const port = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.3, 16), brassMat);
      port.rotation.x = Math.PI / 2; port.position.set(0, 2.9, 0);
      leaf.add(port);
      const glass = new THREE.Mesh(new THREE.CircleGeometry(0.17, 16), new THREE.MeshStandardMaterial({ color: 0x11100c, roughness: 0.2, metalness: 0.6 }));
      glass.position.set(0, 2.9, 0.12);
      leaf.add(glass);
      // maçaneta + placa de empurrar
      const knob = new THREE.Mesh(this.geoSphere, brassMat);
      knob.scale.set(0.12, 0.12, 0.12); knob.position.set(side * -(w / 4 - 0.35), 1.7, 0.18);
      leaf.add(knob);
      const kick = new THREE.Mesh(this.geoBox, brassMat);
      kick.scale.set(w / 2 - 0.3, 0.28, 0.03); kick.position.set(0, 0.3, 0.12);
      leaf.add(kick);
      // faixa de contenção (fita zebra sutil)
      const tape = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x8f1d2c, roughness: 0.8 }));
      tape.scale.set(w / 2 - 0.1, 0.16, 0.26); tape.position.set(0, 1.35, 0);
      leaf.add(tape);
      leaf.position.x = side * w / 4;
      g.add(leaf);
      return leaf;
    };
    const leafL = mkLeaf(-1); const leafR = mkLeaf(1);
    const panelL = leafL.children[0] as THREE.Mesh;
    // letreiro luminoso acima
    const signMat = new THREE.MeshBasicMaterial({ color: 0xffd94f, toneMapped: false });
    const signBack = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x0b0b09, roughness: 0.6 }));
    signBack.scale.set(Math.max(3.4, w + 0.6), 0.7, 0.25); signBack.position.set(0, 5.25, 0.1);
    g.add(signBack);
    const signBar = new THREE.Mesh(this.geoBox, signMat);
    signBar.scale.set(Math.max(3.4, w + 0.6), 0.08, 0.27); signBar.position.set(0, 4.86, 0.1);
    g.add(signBar);
    const tag = this.textSprite(`${label} · ${cost} $ · R${reqRound}`, { color: "#ffd94f", scale: 1.35 });
    tag.position.set(x, 5.9, z);
    this.scene.add(tag);
    // arandelas laterais
    for (const px of [-w / 2 - 0.45, w / 2 + 0.45]) {
      const bulb = new THREE.Mesh(this.geoSphere, new THREE.MeshBasicMaterial({ color: 0xffd9a0, toneMapped: false }));
      bulb.scale.setScalar(0.16);
      const holder = new THREE.Group();
      holder.position.set(px, 3.4, 0.7);
      holder.add(bulb);
      const gl = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: 0xffc98a, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false }));
      gl.scale.setScalar(1.4);
      holder.add(gl);
      g.add(holder);
    }
    const light = new THREE.PointLight(0xffd94f, 9, 9, 1.8);
    light.position.set(x, 3.6, z);
    this.scene.add(light);
    this.scene.add(g);
    const alongX = Math.abs(Math.sin(rotY)) < 0.5;
    const c = alongX
      ? { x1: x - w / 2, z1: z - 0.55, x2: x + w / 2, z2: z + 0.55 }
      : { x1: x - 0.55, z1: z - w / 2, x2: x + 0.55, z2: z + w / 2 };
    this.colliders.push(c);
    const colliderIdx = this.colliders.length - 1;
    this.doors.push({ id, label, x, z, rotY, w, cost, reqRound, zone, opened: false, opening: 0, group: g, panel: panelL, panelL: leafL as unknown as THREE.Mesh, panelR: leafR as unknown as THREE.Mesh, tag, colliderIdx, light, signMat: signBar.material as THREE.MeshBasicMaterial });
  }

  private buildRooms() {
    const def = this.mapDef;
    for (const wl of def.walls) this.addWallSeg(wl.x, wl.z, wl.w, wl.d);
    // placas de zona no centróide dos pontos de interesse
    for (const z of def.zones) {
      const pts: [number, number][] = [];
      for (const d of def.doors) if (d.zone === z.id) pts.push([d.x, d.z]);
      for (const w of def.windows) if (w.zone === z.id && !w.vent) pts.push([w.x, w.z]);
      for (const s of def.stations) if (s.zone === z.id) pts.push([s.x, s.z]);
      if (!pts.length) continue;
      const cx = pts.reduce((a, p) => a + p[0], 0) / pts.length;
      const cz = pts.reduce((a, p) => a + p[1], 0) / pts.length;
      const s = this.textSprite(z.label, { color: z.color, scale: 1.4 });
      s.position.set(cx, 5.0, cz);
      this.scene.add(s);
    }
    for (const d of def.doors) this.makeDoor(d.id, d.label, d.x, d.z, d.rotY, d.w, d.cost, d.reqRound, d.zone);
    for (const w of def.windows) this.makeWindow(w.zone, w.x, w.z, w.rotY, !!w.vent);
    this.buildSystems();
    this.dressMap();
  }

  zoneLabel(id: string): string {
    return this.mapDef.zones.find((z) => z.id === id)?.label ?? id.toUpperCase();
  }

  /* ============ CONSTRUTORES POR MAPA ============ */
  private lorePlaque(lines: string[], x: number, y: number, z: number, ry: number, w: number, color: string, flat = false) {
    const cv = document.createElement("canvas");
    cv.width = 512; cv.height = 56 + lines.length * 56;
    const c = cv.getContext("2d")!;
    c.fillStyle = "rgba(4,6,5,0.88)"; c.fillRect(0, 0, cv.width, cv.height);
    c.strokeStyle = color; c.lineWidth = 4; c.strokeRect(4, 4, cv.width - 8, cv.height - 8);
    c.textAlign = "center"; c.textBaseline = "middle";
    lines.forEach((ln, i) => {
      c.font = "bold 38px monospace";
      c.fillStyle = color;
      c.fillText(ln.slice(0, 30), cv.width / 2, 48 + i * 56);
    });
    const tex = new THREE.CanvasTexture(cv);
    tex.colorSpace = THREE.SRGBColorSpace;
    const m = new THREE.Mesh(
      new THREE.PlaneGeometry(w, (w * cv.height) / cv.width),
      new THREE.MeshBasicMaterial({ map: tex, transparent: true, toneMapped: false })
    );
    if (flat) { m.rotation.x = -Math.PI / 2; m.position.set(x, 0.03, z); }
    else { m.position.set(x, y, z); m.rotation.y = ry; }
    this.scene.add(m);
  }

  private buildFloorRunner() {
    const conf: Record<string, { color: number; w: number; z0: number; z1: number }> = {
      subzero: { color: 0x1a2a3a, w: 5, z0: 26, z1: 46 },
      terminal: { color: 0x4a1214, w: 8, z0: 24, z1: 46 },
      fortaleza: { color: 0x4a1214, w: 6, z0: 26, z1: 46 },
    };
    const cf = conf[this.mapId] ?? conf.subzero;
    const len = cf.z1 - cf.z0;
    const rug = new THREE.Mesh(
      new THREE.PlaneGeometry(cf.w, len),
      new THREE.MeshStandardMaterial({ color: cf.color, roughness: 1 })
    );
    rug.rotation.x = -Math.PI / 2;
    rug.position.set(this.mapDef.spawn.x, 0.015, (cf.z0 + cf.z1) / 2);
    rug.receiveShadow = true;
    this.scene.add(rug);
  }

  private crate(x: number, z: number, w: number, d: number, tint: number) {
    const m = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: tint, roughness: 0.8 }));
    m.scale.set(w, 1.5, d); m.position.set(x, 0.75, z);
    m.castShadow = true; m.receiveShadow = true;
    this.scene.add(m); this.blockerMeshes.push(m);
    const lid = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x1c1712, roughness: 0.85 }));
    lid.scale.set(w + 0.12, 0.14, d + 0.12); lid.position.set(x, 1.55, z);
    lid.castShadow = true;
    this.scene.add(lid);
    this.colliders.push({ x1: x - w / 2, z1: z - d / 2, x2: x + w / 2, z2: z + d / 2 });
  }

  private buildCover() {
    if (this.mapId === "subzero") {
      const t = 0x3d4a55;
      this.crate(-8, 32, 3, 3, t); this.crate(8, 32, 3, 3, t);
      this.crate(-20, 20, 3.4, 2, t); this.crate(20, 20, 3.4, 2, t);
      this.crate(-30, 2, 3.4, 2, t); this.crate(30, 2, 3.4, 2, t);
      this.crate(-14, -22, 3, 3, t); this.crate(14, -22, 3, 3, t);
      this.crate(-34, -34, 3.4, 2, t); this.crate(34, -34, 3.4, 2, t);
    } else if (this.mapId === "terminal") {
      const t = 0x6b5a48;
      this.crate(-24, 34, 3, 2.4, t); this.crate(24, 34, 3, 2.4, t);
      this.crate(-8, 18, 2.4, 2.4, t); this.crate(8, 18, 2.4, 2.4, t);
      this.crate(-36, 0, 3.4, 2, t); this.crate(36, 0, 3.4, 2, t);
      this.crate(-20, -24, 3.4, 2, 0x3a3f45); this.crate(20, -24, 3.4, 2, 0x3a3f45);
      this.crate(-40, -38, 3, 3, 0x3a3f45); this.crate(40, -38, 3, 3, 0x3a3f45);
    } else {
      const t = 0x4a4238;
      this.crate(-16, 36, 3, 3, t); this.crate(16, 36, 3, 3, t);
      this.crate(-24, 12, 3.4, 2, t); this.crate(24, 12, 3.4, 2, t);
      this.crate(-20, -8, 3, 3, 0x3a3f45); this.crate(20, -8, 3, 3, 0x3a3f45);
      this.crate(-12, -32, 3, 3, t); this.crate(12, -32, 3, 3, t);
    }
  }

  private barrel(x: number, z: number, toxic: boolean, accent = 0x5dff8d) {
    const mat = toxic
      ? new THREE.MeshStandardMaterial({ color: 0x1d4d2a, roughness: 0.5, metalness: 0.5, emissive: 0x1d8f3f, emissiveIntensity: 0.55 })
      : new THREE.MeshStandardMaterial({ color: 0x5a3a22, roughness: 0.9, metalness: 0.3 });
    const b = new THREE.Mesh(this.geoCyl, mat);
    b.scale.set(1.1, 2, 1.1); b.position.set(x, 1, z);
    b.castShadow = true; b.receiveShadow = true;
    this.scene.add(b); this.blockerMeshes.push(b);
    if (toxic) {
      const band = new THREE.Mesh(this.geoCyl, new THREE.MeshBasicMaterial({ color: accent, toneMapped: false }));
      band.scale.set(1.13, 0.18, 1.13); band.position.set(x, 1.3, z);
      this.scene.add(band);
    }
    this.colliders.push({ x1: x - 0.6, z1: z - 0.6, x2: x + 0.6, z2: z + 0.6 });
  }

  private buildBarrels() {
    if (this.mapId === "subzero") {
      this.barrel(-13, 42, true, 0x7dd7ff); this.barrel(13, 42, false);
      this.barrel(-30, 24, false); this.barrel(30, 24, true, 0xb79bff);
      this.barrel(-44, -4, true, 0x7dd7ff); this.barrel(44, -4, false);
      this.barrel(-20, -40, true, 0x8affc1); this.barrel(20, -40, true, 0x8affc1);
    } else if (this.mapId === "terminal") {
      this.barrel(-40, 44, false); this.barrel(40, 44, true, 0xb79bff);
      this.barrel(-10, 18, false); this.barrel(10, 18, false);
      this.barrel(-48, -4, true, 0xb79bff); this.barrel(48, -4, true, 0xb79bff);
      this.barrel(-24, -40, true, 0xb79bff); this.barrel(24, -40, false);
    } else {
      this.barrel(-28, 42, false); this.barrel(28, 42, true, 0xb79bff);
      this.barrel(-36, 4, false); this.barrel(36, 4, false);
      this.barrel(-32, -18, true, 0xb79bff); this.barrel(32, -18, true, 0xb79bff);
      this.barrel(-18, -30, false); this.barrel(18, -30, false);
    }
  }

  private hangingLamp(x: number, z: number, color: number, base: number, dist: number, shade = 0x1f2a1f) {
    const g = new THREE.Group(); g.position.set(x, 6.4, z);
    const cord = new THREE.Mesh(this.geoCyl, new THREE.MeshStandardMaterial({ color: 0x0c0c0c, roughness: 0.8 }));
    cord.scale.set(0.06, 1.6, 0.06); cord.position.y = -0.8;
    g.add(cord);
    const sh = new THREE.Mesh(new THREE.ConeGeometry(0.9, 0.7, 12, 1, true), new THREE.MeshStandardMaterial({ color: shade, roughness: 0.6, metalness: 0.5, side: THREE.DoubleSide }));
    sh.position.y = -1.8;
    g.add(sh);
    const bulb = new THREE.Mesh(this.geoSphere, new THREE.MeshBasicMaterial({ color, toneMapped: false }));
    bulb.scale.setScalar(0.3); bulb.position.y = -2.05;
    g.add(bulb);
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false }));
    glow.scale.setScalar(3.2); glow.position.y = -2.05;
    g.add(glow);
    const li = new THREE.PointLight(color, base, dist, 1.7);
    li.position.y = -2.1;
    g.add(li);
    this.scene.add(g);
    this.lamps.push({ group: g, light: li, bulb, glow, base, phase: rand(0, 6) });
  }

  private buildMapLamps() {
    if (this.mapId === "subzero") {
      this.hangingLamp(-8, 38, 0xbfd4ff, 24, 22);
      this.hangingLamp(8, 38, 0xbfd4ff, 24, 22);
      this.hangingLamp(-15, 20, 0xb79bff, 20, 20);
      this.hangingLamp(15, 20, 0xb79bff, 20, 20);
      this.hangingLamp(-15, 2, 0xd8ecff, 26, 24);
      this.hangingLamp(15, 2, 0xd8ecff, 26, 24);
      this.hangingLamp(0, -24, 0x8affc1, 26, 26);
      this.hangingLamp(0, -40, 0x8affc1, 22, 22);
    } else if (this.mapId === "terminal") {
      this.hangingLamp(-20, 38, 0xffd9a0, 26, 24);
      this.hangingLamp(0, 38, 0xffd9a0, 26, 24);
      this.hangingLamp(20, 38, 0xffd9a0, 26, 24);
      this.hangingLamp(-20, 0, 0xffd9a0, 26, 26);
      this.hangingLamp(20, 0, 0xffd9a0, 26, 26);
      this.hangingLamp(-20, -30, 0xbfd4ff, 30, 30);
      this.hangingLamp(20, -30, 0xbfd4ff, 30, 30);
    } else {
      this.hangingLamp(-16, 36, 0xffb060, 24, 22, 0x2a1a10);
      this.hangingLamp(16, 36, 0xffb060, 24, 22, 0x2a1a10);
      this.hangingLamp(-16, 12, 0xffc98a, 26, 24);
      this.hangingLamp(16, 12, 0xffc98a, 26, 24);
      this.hangingLamp(-15, -12, 0xb79bff, 22, 22);
      this.hangingLamp(15, -12, 0xb79bff, 22, 22);
      this.hangingLamp(0, -38, 0xcfe0ff, 26, 28);
    }
  }

  private buildAtmosphere() {
    const tint = this.mapId === "subzero" ? 0x4a6a8a : this.mapId === "terminal" ? 0x6a4a7a : 0x4a4a6a;
    const fogTex = smokeTexture();
    for (let i = 0; i < (this.quality === "high" ? 6 : 3); i++) {
      const m = new THREE.Mesh(
        new THREE.PlaneGeometry(rand(18, 30), rand(8, 12)),
        new THREE.MeshBasicMaterial({ map: fogTex, color: tint, transparent: true, opacity: 0.05, depthWrite: false, blending: THREE.AdditiveBlending })
      );
      m.position.set(rand(-MAP_W / 2, MAP_W / 2), rand(1, 3.5), rand(-MAP_H / 2, MAP_H / 2));
      m.rotation.y = rand(0, TAU);
      this.scene.add(m);
      this.fogPlanes.push({ mesh: m, speed: rand(0.15, 0.5) });
    }
    const dustN = this.quality === "high" ? 260 : 120;
    const dg = new THREE.BufferGeometry();
    const dp = new Float32Array(dustN * 3);
    this.dustVel = new Float32Array(dustN);
    for (let i = 0; i < dustN; i++) {
      dp[i * 3] = rand(-MAP_W / 2, MAP_W / 2); dp[i * 3 + 1] = rand(0.2, 7); dp[i * 3 + 2] = rand(-MAP_H / 2, MAP_H / 2);
      this.dustVel[i] = rand(0.08, 0.3);
    }
    dg.setAttribute("position", new THREE.BufferAttribute(dp, 3));
    this.dust = new THREE.Points(dg, new THREE.PointsMaterial({ color: 0x9ab08e, size: 0.045, transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, depthWrite: false }));
    this.scene.add(this.dust);
    // brasas / faíscas por mapa
    const spots = this.mapId === "subzero"
      ? [[-13, 42], [13, 42], [0, -40]]
      : this.mapId === "terminal"
        ? [[-24, -40], [24, -40], [0, -58]]
        : [[-16, 36], [16, 36], [0, -40]];
    const emberN = this.quality === "high" ? 90 : 45;
    const eg = new THREE.BufferGeometry();
    const ep = new Float32Array(emberN * 3);
    this.emberVel = new Float32Array(emberN * 2);
    for (let i = 0; i < emberN; i++) {
      const sp2 = spots[i % spots.length];
      ep[i * 3] = sp2[0] + rand(-1, 1); ep[i * 3 + 1] = rand(0.5, 5); ep[i * 3 + 2] = sp2[1] + rand(-1, 1);
      this.emberVel[i * 2] = rand(0.4, 1.1); this.emberVel[i * 2 + 1] = rand(0, TAU);
    }
    eg.setAttribute("position", new THREE.BufferAttribute(ep, 3));
    const emberColor = this.mapId === "subzero" ? 0xbfd4ff : 0xff9d4d;
    this.ember = new THREE.Points(eg, new THREE.PointsMaterial({ color: emberColor, size: 0.09, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false }));
    this.scene.add(this.ember);
  }

  private buildCenterpiece() {
    if (this.mapId === "subzero") {
      // câmara de contenção rompida no Lab Central
      const g = new THREE.Group(); g.position.set(0, 0, 4);
      const plat = new THREE.Mesh(this.geoCyl, new THREE.MeshStandardMaterial({ color: 0x2a3138, metalness: 0.7, roughness: 0.4 }));
      plat.scale.set(5.4, 0.4, 5.4); plat.position.y = 0.2; plat.receiveShadow = true;
      g.add(plat);
      const glass = new THREE.Mesh(
        new THREE.CylinderGeometry(2.0, 2.0, 4.4, 18, 1, true),
        new THREE.MeshStandardMaterial({ color: 0x9fd4ff, roughness: 0.1, metalness: 0.3, transparent: true, opacity: 0.28, side: THREE.DoubleSide })
      );
      glass.position.y = 2.6;
      g.add(glass);
      const rimB = new THREE.Mesh(new THREE.TorusGeometry(2.0, 0.14, 10, 24), new THREE.MeshStandardMaterial({ color: 0x3a4048, metalness: 0.8, roughness: 0.35 }));
      rimB.rotation.x = Math.PI / 2; rimB.position.y = 0.5;
      g.add(rimB);
      const rimT = rimB.clone(); rimT.position.y = 4.8; rimT.rotation.z = 0.2;
      g.add(rimT);
      const core = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: 0xb46aff, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false }));
      core.scale.setScalar(3.4); core.position.y = 2.4;
      g.add(core);
      for (let i = 0; i < 5; i++) {
        const shard = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x9fd4ff, roughness: 0.1, metalness: 0.4, transparent: true, opacity: 0.7 }));
        shard.scale.set(0.3, rand(0.5, 1.1), 0.06);
        const a = (i / 5) * TAU;
        shard.position.set(Math.cos(a) * 2.8, rand(0.3, 1), Math.sin(a) * 2.8);
        shard.rotation.set(rand(0, 1), rand(0, 3), rand(0, 1));
        g.add(shard);
      }
      const li = new THREE.PointLight(0xb46aff, 26, 20, 1.7);
      li.position.y = 2.6;
      g.add(li);
      this.scene.add(g);
      this.lamps.push({ group: g, light: li, bulb: core as unknown as THREE.Mesh, glow: core, base: 26, phase: 1 });
      this.colliders.push({ x1: -2.7, z1: 1.3, x2: 2.7, z2: 6.7 });
    } else if (this.mapId === "terminal") {
      // avião de carga Aethelgard na pista
      const g = new THREE.Group(); g.position.set(-6, 0, -38);
      const hullMat = new THREE.MeshStandardMaterial({ color: 0x5a6068, metalness: 0.6, roughness: 0.45 });
      const fus = new THREE.Mesh(new THREE.CylinderGeometry(2.2, 2.2, 14, 16), hullMat);
      fus.rotation.x = Math.PI / 2; fus.position.y = 2.8;
      fus.castShadow = true;
      g.add(fus);
      const nose = new THREE.Mesh(this.geoSphere, hullMat);
      nose.scale.set(4.4, 4.4, 4.4); nose.position.set(0, 2.8, -7.4);
      g.add(nose);
      const wing = new THREE.Mesh(this.geoBox, hullMat);
      wing.scale.set(19, 0.35, 3.2); wing.position.set(0, 3.4, 0.5);
      wing.castShadow = true;
      g.add(wing);
      const tail = new THREE.Mesh(this.geoBox, hullMat);
      tail.scale.set(0.35, 4.5, 2.6); tail.position.set(0, 5.4, 6.4);
      g.add(tail);
      const ramp = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x3a3f45, metalness: 0.5, roughness: 0.6 }));
      ramp.scale.set(3.4, 0.2, 5); ramp.position.set(0, 0.7, 9); ramp.rotation.x = 0.28;
      ramp.receiveShadow = true;
      g.add(ramp);
      const engine1 = new THREE.Mesh(this.geoCyl, hullMat);
      engine1.scale.set(1.2, 2.6, 1.2); engine1.rotation.z = Math.PI / 2; engine1.position.set(-6, 2.6, 0.5);
      g.add(engine1);
      const engine2 = engine1.clone(); engine2.position.x = 6; g.add(engine2);
      this.scene.add(g);
      this.colliders.push({ x1: -8.4, z1: -45.5, x2: -3.6, z2: -31 });
      // 3 aviões colididos fora da pista (silhuetas + fogo)
      const wrecks: [number, number, number][] = [[-30, -58, 0.5], [5, -64, -0.3], [32, -57, 0.9]];
      wrecks.forEach(([wx, wz, tilt], i) => {
        const wg = new THREE.Group(); wg.position.set(wx, 0, wz); wg.rotation.y = tilt;
        const f = new THREE.Mesh(new THREE.CylinderGeometry(2.4, 2.4, 16, 10), new THREE.MeshStandardMaterial({ color: 0x2a2a2c, roughness: 0.9 }));
        f.rotation.z = Math.PI / 2; f.rotation.y = 0.15; f.position.y = 2.2;
        wg.add(f);
        const wg2 = new THREE.Mesh(this.geoBox, f.material);
        wg2.scale.set(3, 0.3, 14); wg2.position.y = 2.6; wg2.rotation.y = 0.4;
        wg.add(wg2);
        const fire = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: 0xff7a2d, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false }));
        fire.scale.setScalar(7); fire.position.y = 3;
        wg.add(fire);
        const fl = new THREE.PointLight(0xff7a2d, 40, 40, 1.6);
        fl.position.y = 3.5;
        wg.add(fl);
        this.scene.add(wg);
        this.lamps.push({ group: wg, light: fl, bulb: fire as unknown as THREE.Mesh, glow: fire, base: 40, phase: i * 2 });
        const smoke = new THREE.Sprite(new THREE.SpriteMaterial({ map: smokeTexture(), color: 0x4a3a5a, transparent: true, opacity: 0.55, depthWrite: false }));
        smoke.scale.set(10, 16, 1); smoke.position.set(wx, 12, wz);
        this.scene.add(smoke);
      });
    } else {
      // antena colossal da torre + estátua do pátio
      const g = new THREE.Group(); g.position.set(0, 0, -40);
      const base = new THREE.Mesh(this.geoCyl, new THREE.MeshStandardMaterial({ color: 0x2c2620, roughness: 0.8 }));
      base.scale.set(5, 1, 5); base.position.y = 0.5; base.receiveShadow = true;
      g.add(base);
      const needle = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.5, 10, 10), new THREE.MeshStandardMaterial({ color: 0x3a3f45, metalness: 0.85, roughness: 0.3 }));
      needle.position.y = 6;
      needle.castShadow = true;
      g.add(needle);
      for (let i = 0; i < 3; i++) {
        const ring = new THREE.Mesh(new THREE.TorusGeometry(0.9 + i * 0.5, 0.09, 8, 24), new THREE.MeshBasicMaterial({ color: 0xb46aff, toneMapped: false }));
        ring.rotation.x = Math.PI / 2; ring.position.y = 3.5 + i * 2;
        g.add(ring);
      }
      const core = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: 0xb46aff, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false }));
      core.scale.setScalar(5); core.position.y = 8;
      g.add(core);
      const li = new THREE.PointLight(0xb46aff, 40, 30, 1.6);
      li.position.y = 6;
      g.add(li);
      this.scene.add(g);
      this.lamps.push({ group: g, light: li, bulb: core as unknown as THREE.Mesh, glow: core, base: 40, phase: 3 });
      this.colliders.push({ x1: -2.5, z1: -42.5, x2: 2.5, z2: -37.5 });
      const gold = new THREE.Mesh(new THREE.RingGeometry(4.2, 4.6, 40), new THREE.MeshBasicMaterial({ color: 0xc9a24a, toneMapped: false, side: THREE.DoubleSide }));
      gold.rotation.x = -Math.PI / 2; gold.position.set(0, 0.03, -40);
      this.scene.add(gold);
      // estátua celta rachada com luz roxa
      const st = new THREE.Group(); st.position.set(0, 0, 30);
      const ped = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x1c1a18, roughness: 0.9 }));
      ped.scale.set(3, 1, 3); ped.position.y = 0.5; ped.castShadow = true;
      st.add(ped);
      const body = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x232120, roughness: 0.85 }));
      body.scale.set(1.4, 3.4, 1.1); body.position.y = 2.7; body.castShadow = true;
      st.add(body);
      const head = new THREE.Mesh(this.geoSphere, body.material);
      head.scale.set(0.8, 0.9, 0.8); head.position.y = 4.9;
      st.add(head);
      const crack = new THREE.Mesh(this.geoBox, new THREE.MeshBasicMaterial({ color: 0xb46aff, toneMapped: false }));
      crack.scale.set(0.12, 3.0, 1.14); crack.position.y = 2.7;
      st.add(crack);
      const sgl = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: 0xb46aff, transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false }));
      sgl.scale.setScalar(3); sgl.position.y = 2.7;
      st.add(sgl);
      this.scene.add(st);
      this.colliders.push({ x1: -1.5, z1: 28.5, x2: 1.5, z2: 31.5 });
    }
  }

  private dressMap() {
    // lore do manual em cada mapa
    for (const l of this.mapDef.lore) this.lorePlaque(l.lines, l.x, l.y, l.z, l.ry, l.w, l.color);
    if (this.mapId === "subzero") this.dressSubZero();
    else if (this.mapId === "terminal") this.dressTerminal();
    else this.dressCastle();
  }

  private truck(x: number, z: number, ry: number) {
    const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = ry;
    const paint = new THREE.MeshStandardMaterial({ color: 0x8a2f23, roughness: 0.6, metalness: 0.3 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x1c1c1e, roughness: 0.8 });
    const bed = new THREE.Mesh(this.geoBox, paint);
    bed.scale.set(4.6, 1.7, 2.2); bed.position.set(-1.2, 1.35, 0); bed.castShadow = true;
    g.add(bed);
    const cab = new THREE.Mesh(this.geoBox, paint);
    cab.scale.set(1.9, 1.9, 2.2); cab.position.set(2.2, 1.35, 0); cab.castShadow = true;
    g.add(cab);
    const shield = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x9fc0d8, roughness: 0.15, metalness: 0.5 }));
    shield.scale.set(0.15, 0.9, 1.8); shield.position.set(3.15, 1.6, 0);
    g.add(shield);
    const plow = new THREE.Mesh(this.geoBox, dark);
    plow.scale.set(0.25, 1.0, 2.8); plow.position.set(3.5, 0.6, 0); plow.rotation.z = -0.2;
    g.add(plow);
    for (const wx of [-2.6, -1.2, 2.2]) {
      for (const wz of [-1.1, 1.1]) {
        const wh = new THREE.Mesh(this.geoCyl, dark);
        wh.scale.set(1.0, 0.4, 1.0); wh.rotation.x = Math.PI / 2;
        wh.position.set(wx, 0.5, wz);
        g.add(wh);
      }
    }
    const hl = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: 0xffe2b0, transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false }));
    hl.scale.setScalar(1.2); hl.position.set(3.3, 1.2, 0);
    g.add(hl);
    this.scene.add(g);
    this.colliders.push({ x1: x - 2.8, z1: z - 1.4, x2: x + 2.8, z2: z + 1.4 });
  }

  private cryoCapsule(x: number, z: number, occupied: boolean) {
    const g = new THREE.Group(); g.position.set(x, 0, z);
    const body = new THREE.Mesh(this.geoCyl, new THREE.MeshStandardMaterial({ color: 0x3a4048, metalness: 0.75, roughness: 0.35 }));
    body.scale.set(1.4, 2.7, 1.4); body.position.y = 1.45; body.castShadow = true;
    g.add(body);
    const glass = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 1.9), new THREE.MeshStandardMaterial({ color: 0x9fd4ff, roughness: 0.1, metalness: 0.3, transparent: true, opacity: 0.35 }));
    glass.position.set(0, 1.5, 0.72);
    g.add(glass);
    const frost = new THREE.Mesh(new THREE.PlaneGeometry(1.3, 2.4), new THREE.MeshBasicMaterial({ color: 0xd8ecff, transparent: true, opacity: 0.12, depthWrite: false }));
    frost.position.set(0, 1.4, 0.74);
    g.add(frost);
    const lamp = new THREE.Mesh(this.geoSphere, new THREE.MeshBasicMaterial({ color: occupied ? 0xb46aff : 0x8affc1, toneMapped: false }));
    lamp.scale.setScalar(0.12); lamp.position.y = 2.95;
    g.add(lamp);
    if (occupied) {
      const eyes = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: 0xb46aff, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false }));
      eyes.scale.setScalar(0.5); eyes.position.set(0, 1.9, 0.5);
      g.add(eyes);
      const sil = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x0c0e12, roughness: 1 }));
      sil.scale.set(0.5, 1.5, 0.3); sil.position.set(0, 1.2, 0.3);
      g.add(sil);
    }
    this.scene.add(g);
    this.colliders.push({ x1: x - 0.75, z1: z - 0.75, x2: x + 0.75, z2: z + 0.75 });
  }

  private dressSubZero() {
    // garagem: caminhões de neve batidos + pegadas de sangue + bancada
    this.truck(-9, 43, 0.25); this.truck(9, 43, -0.2);
    const bloodMat = new THREE.MeshBasicMaterial({ color: 0x4a0808, transparent: true, opacity: 0.8, depthWrite: false });
    const trail: [number, number][] = [[-8, 40], [-8.2, 37], [-8, 34], [-8.1, 31], [-8, 28.5], [8, 40], [8.2, 37], [8, 34], [8.1, 31], [8, 28.5]];
    for (const [fx, fz] of trail) {
      const fp = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.7), bloodMat);
      fp.rotation.x = -Math.PI / 2; fp.rotation.z = rand(-0.4, 0.4);
      fp.position.set(fx, 0.025, fz);
      this.scene.add(fp);
    }
    const bench = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x4a4f55, metalness: 0.6, roughness: 0.5 }));
    bench.scale.set(3, 0.9, 1.2); bench.position.set(-12.5, 0.45, 44);
    bench.castShadow = true; bench.receiveShadow = true;
    this.scene.add(bench);
    this.colliders.push({ x1: -14, z1: 43.4, x2: -11, z2: 44.6 });
    const mug = new THREE.Mesh(this.geoCyl, new THREE.MeshStandardMaterial({ color: 0xd8d2c0, roughness: 0.6 }));
    mug.scale.set(0.16, 0.22, 0.16); mug.position.set(-13.2, 1.0, 44);
    this.scene.add(mug);
    // tubulação estourada com vapor
    const pipeMat = new THREE.MeshStandardMaterial({ color: 0x5a6068, metalness: 0.7, roughness: 0.4 });
    for (const px of [-15, 15]) {
      const pipe = new THREE.Mesh(this.geoCyl, pipeMat);
      pipe.scale.set(0.5, 16, 0.5); pipe.rotation.x = Math.PI / 2; pipe.position.set(px, 5.6, 38);
      this.scene.add(pipe);
      const joint = new THREE.Mesh(this.geoSphere, pipeMat);
      joint.scale.setScalar(0.7); joint.position.set(px, 5.6, 34);
      this.scene.add(joint);
      const vap = new THREE.Sprite(new THREE.SpriteMaterial({ map: smokeTexture(), color: 0xbfd4ff, transparent: true, opacity: 0.35, depthWrite: false }));
      vap.scale.set(2.5, 3.5, 1); vap.position.set(px, 4.2, 34);
      this.scene.add(vap);
    }
    // vestiários: armários retorcidos + fluido roxo
    const lockMat = new THREE.MeshStandardMaterial({ color: 0x3d4a55, metalness: 0.5, roughness: 0.5 });
    for (const sx of [-1, 1]) {
      for (let i = 0; i < 5; i++) {
        const lk = new THREE.Mesh(this.geoBox, lockMat);
        lk.scale.set(1.0, 2.2, 0.8);
        lk.position.set(sx * 30, 1.1, 15.5 + i * 2.1);
        lk.rotation.y = (i === 2 ? 0.35 : 0) * sx;
        lk.rotation.z = i === 3 ? 0.18 : 0;
        lk.castShadow = true;
        this.scene.add(lk);
      }
    }
    this.colliders.push({ x1: -31.5, z1: 15, x2: -29.5, z2: 26 });
    this.colliders.push({ x1: 29.5, z1: 15, x2: 31.5, z2: 26 });
    for (const [px, pz] of [[-22, 19], [5, 22], [22, 17]] as [number, number][]) {
      const pud = new THREE.Mesh(new THREE.CircleGeometry(1.4, 16), new THREE.MeshStandardMaterial({ color: 0x4a1a6a, emissive: 0x6a2a9a, emissiveIntensity: 0.7, roughness: 0.2, transparent: true, opacity: 0.85 }));
      pud.rotation.x = -Math.PI / 2; pud.position.set(px, 0.025, pz);
      this.scene.add(pud);
    }
    // lab: bancadas, microscópios, tubos de ensaio, quadros de DNA
    const deskMat = new THREE.MeshStandardMaterial({ color: 0x9aa0a8, metalness: 0.4, roughness: 0.5 });
    for (const dx of [-24, -10, 10, 24]) {
      const desk = new THREE.Mesh(this.geoBox, deskMat);
      desk.scale.set(4, 0.85, 1.4); desk.position.set(dx, 0.42, -6);
      desk.castShadow = true; desk.receiveShadow = true;
      this.scene.add(desk);
      const scr = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.8), new THREE.MeshBasicMaterial({ color: 0x1a3a5a, toneMapped: false }));
      scr.position.set(dx - 0.8, 1.5, -6.2); scr.rotation.y = Math.PI; scr.rotation.x = -0.15;
      this.scene.add(scr);
      const scr2 = scr.clone(); scr2.position.x = dx + 0.8; this.scene.add(scr2);
      this.colliders.push({ x1: dx - 2, z1: -6.7, x2: dx + 2, z2: -5.3 });
    }
    for (const dx of [-10, 10]) {
      const arm = new THREE.Mesh(this.geoCyl, deskMat);
      arm.scale.set(0.12, 0.8, 0.12); arm.position.set(dx + 1.2, 1.2, -6);
      this.scene.add(arm);
      const tube = new THREE.Mesh(this.geoCyl, new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.4 }));
      tube.scale.set(0.16, 0.5, 0.16); tube.rotation.x = 0.5; tube.position.set(dx + 1.2, 1.6, -5.9);
      this.scene.add(tube);
    }
    const rack = new THREE.Mesh(this.geoBox, deskMat);
    rack.scale.set(2.2, 0.9, 0.8); rack.position.set(10, 0.45, 6);
    rack.castShadow = true;
    this.scene.add(rack);
    this.colliders.push({ x1: 8.9, z1: 5.6, x2: 11.1, z2: 6.4 });
    for (let i = 0; i < 5; i++) {
      const tt = new THREE.Mesh(this.geoCyl, new THREE.MeshStandardMaterial({ color: 0xb46aff, emissive: 0x8a3adf, emissiveIntensity: 1.4, roughness: 0.2 }));
      tt.scale.set(0.12, 0.5, 0.12); tt.position.set(9.2 + i * 0.4, 1.15, 6);
      this.scene.add(tt);
    }
    // criogenia: fileiras de cápsulas + névoa baixa
    const capX = [-20, -12, -4, 4, 12, 20];
    capX.forEach((cx, i) => this.cryoCapsule(cx, -44.5, i % 3 === 1));
    this.cryoCapsule(-56, -36, true); this.cryoCapsule(56, -36, false);
    for (let i = 0; i < 3; i++) {
      const f = new THREE.Mesh(
        new THREE.PlaneGeometry(20, 9),
        new THREE.MeshBasicMaterial({ map: smokeTexture(), color: 0x8ab8d8, transparent: true, opacity: 0.12, depthWrite: false })
      );
      f.position.set(-15 + i * 15, 0.6, -30); f.rotation.y = rand(0, TAU);
      this.scene.add(f);
      this.fogPlanes.push({ mesh: f, speed: 0.3 });
    }
  }

  private dressTerminal() {
    // check-in: balcões + labirinto de malas + arame farpado
    const counterMat = new THREE.MeshStandardMaterial({ color: 0x6a6f76, metalness: 0.4, roughness: 0.5 });
    for (const cx of [-20, 0, 20]) {
      const c = new THREE.Mesh(this.geoBox, counterMat);
      c.scale.set(9, 1.15, 1.6); c.position.set(cx, 0.57, 43);
      c.castShadow = true; c.receiveShadow = true;
      this.scene.add(c);
      this.colliders.push({ x1: cx - 4.5, z1: 42.2, x2: cx + 4.5, z2: 43.8 });
      const belt = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.7 }));
      belt.scale.set(9, 0.1, 0.8); belt.position.set(cx, 1.2, 43);
      this.scene.add(belt);
    }
    const caseCols = [0x5e2a2a, 0x2a3a5e, 0x3d4a38, 0x504030, 0x444444, 0x5e4a2a];
    for (let ix = 0; ix < 8; ix++) {
      for (let iz = 0; iz < 3; iz++) {
        if ((ix + iz) % 3 === 2) continue; // vãos do labirinto
        const sc = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: caseCols[(ix + iz) % 6], roughness: 0.8 }));
        sc.scale.set(0.75, rand(0.45, 0.65), 0.5);
        sc.position.set(-10.5 + ix * 1.1, 0.28, 30 + iz * 1.0);
        sc.rotation.y = rand(-0.3, 0.3);
        sc.castShadow = true;
        this.scene.add(sc);
      }
    }
    this.colliders.push({ x1: -11, z1: 29.5, x2: -1, z2: 32.5 });
    // arame farpado nas saídas sul
    for (const wx of [-18, -6, 6, 18]) {
      const bw = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x3a3f45, metalness: 0.7, roughness: 0.4 }));
      bw.scale.set(3, 0.9, 0.6); bw.position.set(wx, 0.45, 46.8);
      bw.castShadow = true;
      this.scene.add(bw);
      for (let i = 0; i < 5; i++) {
        const spike = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.35, 5), bw.material);
        spike.position.set(wx - 1.2 + i * 0.6, 1.05, 46.8);
        this.scene.add(spike);
      }
      this.colliders.push({ x1: wx - 1.5, z1: 46.5, x2: wx + 1.5, z2: 47.1 });
    }
    // segurança: esteiras + raio-x + rádio militar
    for (const sx of [-8, 8]) {
      const tray = new THREE.Mesh(this.geoBox, counterMat);
      tray.scale.set(1.2, 0.9, 3.4); tray.position.set(sx, 0.45, 20);
      tray.castShadow = true;
      this.scene.add(tray);
      this.colliders.push({ x1: sx - 0.6, z1: 18.3, x2: sx + 0.6, z2: 21.7 });
    }
    const xray = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x2a2e34, metalness: 0.5, roughness: 0.5 }));
    xray.scale.set(2.2, 2.2, 3); xray.position.set(0, 1.1, 17);
    xray.castShadow = true;
    this.scene.add(xray);
    this.colliders.push({ x1: -1.1, z1: 15.5, x2: 1.1, z2: 18.5 });
    const radio = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x1c2a1c, roughness: 0.7 }));
    radio.scale.set(0.7, 0.4, 0.4); radio.position.set(-11.5, 1.1, 21.5);
    this.scene.add(radio);
    const ant = new THREE.Mesh(this.geoCyl, radio.material);
    ant.scale.set(0.03, 0.9, 0.03); ant.position.set(-11.5, 1.7, 21.5);
    this.scene.add(ant);
    // duty-free: vitrines saqueadas com letreiros
    const shopNames: [number, number, string, string][] = [
      [-52, -4, "ELETRÔNICOS", "#57c8ff"], [-52, 4, "PERFUMES", "#ff8ad8"],
      [52, -4, "CAFÉ 24H", "#ffb066"], [52, 4, "SOUVENIRS", "#7dff9a"],
    ];
    for (const [sx, sz, nm, col] of shopNames) {
      const front = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x23211e, roughness: 0.8 }));
      front.scale.set(1.2, 3, 6); front.position.set(sx, 1.5, sz);
      front.castShadow = true;
      this.scene.add(front);
      const sign = new THREE.Mesh(this.geoBox, new THREE.MeshBasicMaterial({ color: new THREE.Color(col), toneMapped: false }));
      sign.scale.set(0.3, 0.4, 5.4); sign.position.set(sx - Math.sign(sx) * 0.7, 3.4, sz);
      this.scene.add(sign);
      for (let i = 0; i < 3; i++) {
        const shelf = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x3a352c, roughness: 0.9 }));
        shelf.scale.set(0.8, 1.1, 1.4); shelf.position.set(sx - Math.sign(sx) * 1.6, 0.55, sz - 2 + i * 2);
        this.scene.add(shelf);
      }
      this.lorePlaque([nm], sx - Math.sign(sx) * 0.75, 2.6, sz, sx > 0 ? -Math.PI / 2 : Math.PI / 2, 4.5, col);
    }
    // pista: fileira de luzes + postes de holofote
    for (let i = 0; i < 8; i++) {
      const rl = new THREE.Mesh(this.geoBox, new THREE.MeshBasicMaterial({ color: 0x7db8ff, toneMapped: false }));
      rl.scale.set(0.3, 0.15, 0.3); rl.position.set(20, 0.08, -44 + i * 4);
      this.scene.add(rl);
    }
    for (const px of [-20, 20]) {
      const pole = new THREE.Mesh(this.geoCyl, new THREE.MeshStandardMaterial({ color: 0x2a2e34, metalness: 0.6, roughness: 0.5 }));
      pole.scale.set(0.3, 6.5, 0.3); pole.position.set(px, 3.25, -30);
      pole.castShadow = true;
      this.scene.add(pole);
      this.colliders.push({ x1: px - 0.3, z1: -30.3, x2: px + 0.3, z2: -29.7 });
    }
  }

  private torch(x: number, z: number) {
    const g = new THREE.Group(); g.position.set(x, 0, z);
    const pole = new THREE.Mesh(this.geoCyl, new THREE.MeshStandardMaterial({ color: 0x2a1c12, roughness: 0.9 }));
    pole.scale.set(0.16, 2.2, 0.16); pole.position.y = 1.1; pole.castShadow = true;
    g.add(pole);
    const cup = new THREE.Mesh(this.geoCyl, new THREE.MeshStandardMaterial({ color: 0x141414, roughness: 0.7 }));
    cup.scale.set(0.4, 0.3, 0.4); cup.position.y = 2.3;
    g.add(cup);
    const flame = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: 0xff9d4d, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false }));
    flame.scale.setScalar(1.1); flame.position.y = 2.7;
    g.add(flame);
    const li = new THREE.PointLight(0xff9d4d, 16, 14, 1.8);
    li.position.y = 2.7;
    g.add(li);
    this.scene.add(g);
    this.lamps.push({ group: g, light: li, bulb: flame as unknown as THREE.Mesh, glow: flame, base: 16, phase: rand(0, 6) });
    this.colliders.push({ x1: x - 0.2, z1: z - 0.2, x2: x + 0.2, z2: z + 0.2 });
  }

  private gargoyle(x: number, y: number, z: number, ry: number) {
    const g = new THREE.Group(); g.position.set(x, y, z); g.rotation.y = ry;
    const stone = new THREE.MeshStandardMaterial({ color: 0x2a2826, roughness: 0.9 });
    const body = new THREE.Mesh(new THREE.ConeGeometry(0.35, 1.0, 6), stone);
    g.add(body);
    for (const s of [-1, 1]) {
      const wing = new THREE.Mesh(this.geoBox, stone);
      wing.scale.set(0.5, 0.5, 0.08); wing.position.set(s * 0.35, 0.25, -0.1); wing.rotation.z = s * 0.5;
      g.add(wing);
      const eye = new THREE.Mesh(this.geoSphere, new THREE.MeshBasicMaterial({ color: 0xff2d2d, toneMapped: false }));
      eye.scale.setScalar(0.07); eye.position.set(s * 0.12, 0.32, 0.28);
      g.add(eye);
    }
    this.scene.add(g);
  }

  private dressCastle() {
    // pátio: tochas + gárgulas com olhos-câmera
    this.torch(-10, 38); this.torch(10, 38); this.torch(-20, 28); this.torch(20, 28);
    this.gargoyle(-14, 4.9, 26, Math.PI / 2); this.gargoyle(14, 4.9, 26, -Math.PI / 2);
    this.gargoyle(-8, 4.9, 24, 0); this.gargoyle(8, 4.9, 24, 0);
    // salão: lareira colossal + racks de servidores + tapeçarias
    const fire = new THREE.Group(); fire.position.set(-39, 0, 18);
    const stone = new THREE.MeshStandardMaterial({ color: 0x3a3630, roughness: 0.9 });
    for (const px of [-1.6, 1.6]) {
      const pil = new THREE.Mesh(this.geoBox, stone);
      pil.scale.set(0.8, 3.4, 1.2); pil.position.set(px, 1.7, 0); pil.castShadow = true;
      fire.add(pil);
    }
    const mantel = new THREE.Mesh(this.geoBox, stone);
    mantel.scale.set(4.4, 0.5, 1.4); mantel.position.y = 3.5;
    fire.add(mantel);
    const logs = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x1c1008, roughness: 1 }));
    logs.scale.set(2.4, 0.5, 0.8); logs.position.y = 0.3;
    fire.add(logs);
    const flame = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: 0xff7a2d, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false }));
    flame.scale.set(2.2, 3.0, 1); flame.position.y = 1.4;
    fire.add(flame);
    const fl = new THREE.PointLight(0xff7a2d, 30, 20, 1.7);
    fl.position.y = 1.6;
    fire.add(fl);
    this.scene.add(fire);
    this.lamps.push({ group: fire, light: fl, bulb: flame as unknown as THREE.Mesh, glow: flame, base: 30, phase: 5 });
    this.colliders.push({ x1: -41.2, z1: 17.3, x2: -36.8, z2: 18.7 });
    const rackMat = new THREE.MeshStandardMaterial({ color: 0x0e0e10, metalness: 0.6, roughness: 0.5 });
    for (const rz of [4, 10]) {
      for (const cx of [-8, 0, 8]) {
        const rk = new THREE.Mesh(this.geoBox, rackMat);
        rk.scale.set(3, 2.6, 1.2); rk.position.set(cx, 1.3, rz);
        rk.castShadow = true; rk.receiveShadow = true;
        this.scene.add(rk);
        for (let l = 0; l < 4; l++) {
          const led = new THREE.Mesh(this.geoBox, new THREE.MeshBasicMaterial({ color: l % 2 ? 0xb46aff : 0x5dff8d, toneMapped: false }));
          led.scale.set(2.8, 0.05, 0.05); led.position.set(cx, 0.5 + l * 0.55, rz - 0.62);
          this.scene.add(led);
        }
        this.colliders.push({ x1: cx - 1.5, z1: rz - 0.6, x2: cx + 1.5, z2: rz + 0.6 });
      }
    }
    for (const [tx, tr] of [[-30, 0.06], [30, -0.05]] as [number, number][]) {
      const tap = new THREE.Mesh(new THREE.PlaneGeometry(3, 4.4), new THREE.MeshStandardMaterial({ color: 0x4a2030, roughness: 1 }));
      tap.position.set(tx, 3.2, 12); tap.rotation.y = tx > 0 ? -Math.PI / 2 + tr : Math.PI / 2 + tr;
      this.scene.add(tap);
    }
    // catacumbas: tumbas + mesas cirúrgicas + braços robóticos + tanques + escrivaninha do CEO
    const tombMat = new THREE.MeshStandardMaterial({ color: 0x35322e, roughness: 0.95 });
    for (const [tx, tz] of [[-36, -4], [-36, -12], [-36, -20], [36, -4], [36, -12], [36, -20]] as [number, number][]) {
      const tb = new THREE.Mesh(this.geoBox, tombMat);
      tb.scale.set(1.2, 0.8, 2.4); tb.position.set(tx, 0.4, tz);
      tb.castShadow = true; tb.receiveShadow = true;
      this.scene.add(tb);
      const lid = new THREE.Mesh(this.geoBox, tombMat);
      lid.scale.set(1.3, 0.18, 2.5); lid.position.set(tx + 0.3, 0.9, tz); lid.rotation.z = 0.12;
      this.scene.add(lid);
      this.colliders.push({ x1: tx - 0.7, z1: tz - 1.25, x2: tx + 0.7, z2: tz + 1.25 });
    }
    const steel = new THREE.MeshStandardMaterial({ color: 0x8a9098, metalness: 0.7, roughness: 0.35 });
    for (const tx of [-12, 12]) {
      const table = new THREE.Mesh(this.geoBox, steel);
      table.scale.set(2.4, 0.9, 1.1); table.position.set(tx, 0.45, -8);
      table.castShadow = true;
      this.scene.add(table);
      const armB = new THREE.Mesh(this.geoBox, steel);
      armB.scale.set(0.18, 1.4, 0.18); armB.position.set(tx + 0.8, 1.6, -8);
      this.scene.add(armB);
      const armH = new THREE.Mesh(this.geoBox, steel);
      armH.scale.set(1.0, 0.16, 0.16); armH.position.set(tx + 0.4, 2.3, -8); armH.rotation.z = 0.3;
      this.scene.add(armH);
      this.colliders.push({ x1: tx - 1.2, z1: -8.6, x2: tx + 1.2, z2: -7.4 });
    }
    for (const tx of [-6, 0, 6]) {
      const tank = new THREE.Mesh(this.geoCyl, new THREE.MeshStandardMaterial({ color: 0x9fd4ff, roughness: 0.1, metalness: 0.2, transparent: true, opacity: 0.3 }));
      tank.scale.set(1.8, 3.2, 1.8); tank.position.set(tx, 1.7, -22);
      this.scene.add(tank);
      const fluid = new THREE.Mesh(this.geoCyl, new THREE.MeshStandardMaterial({ color: 0x5a1a8a, emissive: 0x7a2aca, emissiveIntensity: 0.9, transparent: true, opacity: 0.75 }));
      fluid.scale.set(1.5, 2.2, 1.5); fluid.position.set(tx, 1.3, -22);
      this.scene.add(fluid);
      const sil = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x0c0a10, roughness: 1 }));
      sil.scale.set(0.7, 1.8, 0.4); sil.position.set(tx, 1.4, -22);
      this.scene.add(sil);
      this.colliders.push({ x1: tx - 0.9, z1: -22.9, x2: tx + 0.9, z2: -21.1 });
    }
    const desk = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x2e1f14, roughness: 0.6 }));
    desk.scale.set(3, 0.9, 1.4); desk.position.set(8, 0.45, -16.5);
    desk.castShadow = true;
    this.scene.add(desk);
    this.colliders.push({ x1: 6.5, z1: -17.2, x2: 9.5, z2: -15.8 });
    // torre: parapeitos com ameias
    const parMat = new THREE.MeshStandardMaterial({ color: 0x3a3630, roughness: 0.9 });
    const parapet = (x: number, z: number, w: number, d: number) => {
      const p = new THREE.Mesh(this.geoBox, parMat);
      p.scale.set(w, 1.15, d); p.position.set(x, 0.57, z);
      p.castShadow = true; p.receiveShadow = true;
      this.scene.add(p);
      this.colliders.push({ x1: x - w / 2, z1: z - d / 2, x2: x + w / 2, z2: z + d / 2 });
    };
    parapet(-21, -47.4, 14, 0.7); parapet(-6, -47.4, 8, 0.7); parapet(6, -47.4, 8, 0.7); parapet(21, -47.4, 14, 0.7);
    parapet(-27.4, -36, 0.7, 22); parapet(27.4, -36, 0.7, 22);
    parapet(-15.5, -24.6, 24, 0.7); parapet(15.5, -24.6, 24, 0.7);
  }

  /* ============ SISTEMAS: energia, pack, perks, detectores, relés, peças ============ */
  private ringOnFloor(x: number, z: number, r: number, color: string, opacity = 0.5): THREE.Mesh {
    const ring = new THREE.Mesh(
      new THREE.RingGeometry(r * 0.72, r, 28),
      new THREE.MeshBasicMaterial({ color: new THREE.Color(color), transparent: true, opacity, side: THREE.DoubleSide, toneMapped: false, depthWrite: false })
    );
    ring.rotation.x = -Math.PI / 2; ring.position.set(x, 0.04, z);
    this.scene.add(ring);
    return ring;
  }

  private buildSystems() {
    const def = this.mapDef;
    const hiQ = this.quality === "high";
    // energia (1 ou 2 caixas)
    for (const pb of def.powerBoxes) {
      const g = new THREE.Group(); g.position.set(pb.x, 0, pb.z);
      const cab = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x3a3f45, metalness: 0.6, roughness: 0.45 }));
      cab.scale.set(1.3, 2.1, 0.9); cab.position.y = 1.05; cab.castShadow = true;
      g.add(cab);
      const lever = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x8a2f23, roughness: 0.6 }));
      lever.scale.set(0.12, 0.7, 0.12); lever.position.set(0.3, 1.6, 0.5); lever.rotation.x = -0.5;
      g.add(lever);
      const lampM = new THREE.Mesh(this.geoSphere, new THREE.MeshBasicMaterial({ color: 0xff4444, toneMapped: false }));
      lampM.scale.setScalar(0.14); lampM.position.set(-0.3, 1.9, 0.48);
      g.add(lampM);
      const tag = this.textSprite("⚡ ENERGIA", { color: "#ffd94f", scale: 1.2 });
      tag.position.set(pb.x, 2.9, pb.z);
      this.scene.add(tag);
      const light = new THREE.PointLight(0xffd94f, hiQ ? 8 : 0, 8, 1.8);
      light.position.set(pb.x, 2.2, pb.z);
      this.scene.add(light);
      const ring = this.ringOnFloor(pb.x, pb.z, 1.3, "#ffd94f");
      this.scene.add(g);
      this.switches.push({ kind: "power", label: pb.label ?? "ENERGIA", x: pb.x, z: pb.z, zone: pb.zone, done: false, group: g, tag, light, ring });
      this.colliders.push({ x1: pb.x - 0.65, z1: pb.z - 0.45, x2: pb.x + 0.65, z2: pb.z + 0.45 });
    }
    // pack-a-punch
    {
      const p = def.pack;
      const g = new THREE.Group(); g.position.set(p.x, 0, p.z);
      const body = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x1c2a1c, metalness: 0.5, roughness: 0.45 }));
      body.scale.set(2.4, 2.6, 1.6); body.position.y = 1.3; body.castShadow = true;
      g.add(body);
      for (const sx of [-1.35, 1.35]) {
        const tube = new THREE.Mesh(this.geoCyl, new THREE.MeshStandardMaterial({ color: 0x5dff8d, emissive: 0x2a9a4a, emissiveIntensity: 1.2, roughness: 0.3 }));
        tube.scale.set(0.3, 2.2, 0.3); tube.position.set(sx, 1.3, 0);
        g.add(tube);
      }
      const mouth = new THREE.Mesh(this.geoBox, new THREE.MeshBasicMaterial({ color: 0x0a0f0a, toneMapped: false }));
      mouth.scale.set(1.4, 0.9, 0.2); mouth.position.set(0, 1.4, 0.85);
      g.add(mouth);
      const tag = this.textSprite("PACK-A-PUNCH · 3500 $", { color: "#5dff8d", scale: 1.4 });
      tag.position.set(p.x, 3.6, p.z);
      this.scene.add(tag);
      const light = new THREE.PointLight(0x5dff8d, hiQ ? 14 : 0, 12, 1.8);
      light.position.set(p.x, 2.6, p.z);
      this.scene.add(light);
      const ring = this.ringOnFloor(p.x, p.z, 1.7, "#5dff8d", 0.6);
      this.scene.add(g);
      this.packMachine = { x: p.x, z: p.z, zone: p.zone, label: p.label, group: g, tag, light, ring };
      this.colliders.push({ x1: p.x - 1.2, z1: p.z - 0.8, x2: p.x + 1.2, z2: p.z + 0.8 });
    }
    // perks
    for (const pk of def.perks) {
      const col = pk.perk === "vigor" ? "#ff5d5d" : "#ffd94f";
      const g = new THREE.Group(); g.position.set(pk.x, 0, pk.z);
      const fr = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: pk.perk === "vigor" ? 0x5e1420 : 0x5e4a14, roughness: 0.5, metalness: 0.3 }));
      fr.scale.set(1.4, 2.2, 1.2); fr.position.y = 1.1; fr.castShadow = true;
      g.add(fr);
      const glass = new THREE.Mesh(this.geoBox, new THREE.MeshBasicMaterial({ color: new THREE.Color(col), toneMapped: false, transparent: true, opacity: 0.85 }));
      glass.scale.set(1.0, 1.2, 0.1); glass.position.set(0, 1.3, 0.62);
      g.add(glass);
      const tag = this.textSprite(`${pk.label} · ${pk.cost} $`, { color: col, scale: 1.2 });
      tag.position.set(pk.x, 3.0, pk.z);
      this.scene.add(tag);
      const light = new THREE.PointLight(new THREE.Color(col), hiQ ? 8 : 0, 8, 1.8);
      light.position.set(pk.x, 2.2, pk.z);
      this.scene.add(light);
      this.scene.add(g);
      this.perkMachines.push({ perk: pk.perk, x: pk.x, z: pk.z, zone: pk.zone, label: pk.label, cost: pk.cost, buys: 0, group: g, tag, light });
      this.colliders.push({ x1: pk.x - 0.7, z1: pk.z - 0.6, x2: pk.x + 0.7, z2: pk.z + 0.6 });
    }
    // detectores do terminal
    for (const dt of def.detectors ?? []) {
      const g = new THREE.Group(); g.position.set(dt.x, 0, dt.z);
      const mat = new THREE.MeshStandardMaterial({ color: 0x3a3f45, metalness: 0.6, roughness: 0.4 });
      for (const px of [-0.9, 0.9]) {
        const post = new THREE.Mesh(this.geoBox, mat);
        post.scale.set(0.3, 2.4, 0.6); post.position.set(px, 1.2, 0); post.castShadow = true;
        g.add(post);
      }
      const top = new THREE.Mesh(this.geoBox, mat);
      top.scale.set(2.1, 0.3, 0.6); top.position.y = 2.5;
      g.add(top);
      const eye = new THREE.Mesh(this.geoBox, new THREE.MeshBasicMaterial({ color: 0x5dff8d, toneMapped: false }));
      eye.scale.set(1.6, 0.08, 0.1); eye.position.y = 2.3;
      g.add(eye);
      this.scene.add(g);
      this.detectors.push({ x: dt.x, z: dt.z, zone: dt.zone, group: g, cd: 0 });
    }
    // relés da torre
    for (const r of def.relays ?? []) {
      const g = new THREE.Group(); g.position.set(r.x, 0, r.z);
      const ob = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x2c2620, roughness: 0.8 }));
      ob.scale.set(0.8, 2.6, 0.8); ob.position.y = 1.3; ob.castShadow = true;
      g.add(ob);
      const cry = new THREE.Mesh(new THREE.OctahedronGeometry(0.4), new THREE.MeshStandardMaterial({ color: 0xb46aff, emissive: 0x7a2aca, emissiveIntensity: 1.6, roughness: 0.2 }));
      cry.position.y = 3.0;
      g.add(cry);
      const tag = this.textSprite(r.label ?? "RETRANSMISSOR", { color: "#b79bff", scale: 1.1 });
      tag.position.set(r.x, 3.9, r.z);
      this.scene.add(tag);
      const ring = this.ringOnFloor(r.x, r.z, 1.2, "#b79bff");
      this.scene.add(g);
      const light = new THREE.PointLight(0xb46aff, hiQ ? 8 : 0, 8, 1.8);
      light.position.set(r.x, 3, r.z);
      this.scene.add(light);
      this.switches.push({ kind: "relay", label: r.label ?? "RETRANSMISSOR", x: r.x, z: r.z, zone: r.zone, done: false, group: g, tag, light, ring });
      this.colliders.push({ x1: r.x - 0.4, z1: r.z - 0.4, x2: r.x + 0.4, z2: r.z + 0.4 });
    }
    // peças + bancada (arma especial do castelo)
    for (const pt of def.parts ?? []) {
      const g = new THREE.Group(); g.position.set(pt.x, 1.0, pt.z);
      const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.32), new THREE.MeshStandardMaterial({ color: 0xffd94f, emissive: 0xa86a1a, emissiveIntensity: 1.6, roughness: 0.3 }));
      g.add(core);
      const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: 0xffd94f, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false }));
      halo.scale.setScalar(1.8);
      g.add(halo);
      const beam = new THREE.Mesh(
        new THREE.CylinderGeometry(0.25, 0.45, 5, 10, 1, true),
        new THREE.MeshBasicMaterial({ color: 0xffd94f, transparent: true, opacity: 0.14, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false })
      );
      beam.position.set(pt.x, 2.8, pt.z);
      this.scene.add(beam);
      const tag = this.textSprite(pt.label ?? "PEÇA", { color: "#ffd94f", scale: 1.0 });
      tag.position.set(pt.x, 2.1, pt.z);
      this.scene.add(tag);
      this.scene.add(g);
      this.partPickups.push({ x: pt.x, z: pt.z, zone: pt.zone, label: pt.label ?? "PEÇA", taken: false, mesh: g });
    }
    if (def.workbench) {
      const wb = def.workbench;
      const g = new THREE.Group(); g.position.set(wb.x, 0, wb.z);
      const top = new THREE.Mesh(this.geoBox, new THREE.MeshStandardMaterial({ color: 0x4a3421, roughness: 0.6 }));
      top.scale.set(2.6, 0.15, 1.2); top.position.y = 0.95; top.castShadow = true;
      g.add(top);
      for (const [lx, lz] of [[-1.1, -0.45], [1.1, -0.45], [-1.1, 0.45], [1.1, 0.45]]) {
        const leg = new THREE.Mesh(this.geoBox, top.material);
        leg.scale.set(0.12, 0.95, 0.12); leg.position.set(lx, 0.47, lz);
        g.add(leg);
      }
      const holo = new THREE.Mesh(this.geoBox, new THREE.MeshBasicMaterial({ color: 0x7dd7ff, wireframe: true, transparent: true, opacity: 0.7, toneMapped: false }));
      holo.scale.set(0.5, 0.3, 1.2); holo.position.y = 1.5;
      g.add(holo);
      const tag = this.textSprite(wb.label, { color: "#7dd7ff", scale: 1.2 });
      tag.position.set(wb.x, 2.6, wb.z);
      this.scene.add(tag);
      const light = new THREE.PointLight(0x7dd7ff, hiQ ? 8 : 0, 8, 1.8);
      light.position.set(wb.x, 2, wb.z);
      this.scene.add(light);
      this.scene.add(g);
      this.workbench = { x: wb.x, z: wb.z, zone: wb.zone, label: wb.label, group: g, tag, light };
      this.colliders.push({ x1: wb.x - 1.3, z1: wb.z - 0.6, x2: wb.x + 1.3, z2: wb.z + 0.6 });
    }
  }

  /* ============================== PARTICLES ============================== */
  private buildParticles() {
    const N = this.quality === "high" ? 600 : 380;
    for (let i = 0; i < N; i++) this.particles.push({ alive: false, x: 0, y: -99, z: 0, vx: 0, vy: 0, vz: 0, life: 0, max: 1, size: 0.1, r: 1, g: 1, b: 1, grav: 0, drag: 0 });
    const mat = new THREE.MeshBasicMaterial({ toneMapped: false });
    this.pMesh = new THREE.InstancedMesh(this.geoBox, mat, N);
    this.pMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.pMesh.frustumCulled = false;
    const c = new THREE.Color(1, 1, 1);
    for (let i = 0; i < N; i++) {
      this.pDummy.position.set(0, -99, 0); this.pDummy.scale.setScalar(0.0001); this.pDummy.updateMatrix();
      this.pMesh.setMatrixAt(i, this.pDummy.matrix);
      this.pMesh.setColorAt(i, c);
    }
    this.pMesh.instanceColor!.needsUpdate = true;
    this.scene.add(this.pMesh);
    // fumaça (sprites suaves)
    const smokeN = this.quality === "high" ? 40 : 22;
    for (let i = 0; i < smokeN; i++) {
      const m = new THREE.SpriteMaterial({ map: smokeTexture(), color: 0x9a9a9a, transparent: true, opacity: 0, depthWrite: false });
      const spr = new THREE.Sprite(m);
      spr.visible = false;
      this.scene.add(spr);
      this.smokes.push({ spr, mat: m, life: 0, max: 1, vx: 0, vy: 0, vz: 0, grow: 1 });
    }
  }

  private spawnP(x: number, y: number, z: number, vx: number, vy: number, vz: number, life: number, size: number, color: string, grav = 0, drag = 0) {
    for (let i = 0; i < this.particles.length; i++) {
      const p = this.particles[i];
      if (p.alive) continue;
      const [r, g, b] = hexRGB(color);
      p.alive = true; p.x = x; p.y = y; p.z = z; p.vx = vx; p.vy = vy; p.vz = vz;
      p.life = life; p.max = life; p.size = size; p.r = r; p.g = g; p.b = b; p.grav = grav; p.drag = drag;
      return;
    }
  }

  private spawnSmoke(x: number, y: number, z: number, color: string, life: number, size: number, vy = 0.8) {
    let s = this.smokes.find((k) => k.life <= 0);
    if (!s) s = this.smokes[0];
    s.life = life; s.max = life;
    s.spr.visible = true;
    s.spr.position.set(x, y, z);
    s.spr.scale.setScalar(size);
    s.mat.color.set(color);
    s.mat.opacity = 0.4;
    s.vx = rand(-0.4, 0.4); s.vy = vy + rand(0, 0.5); s.vz = rand(-0.4, 0.4);
    s.grow = size * 1.6;
  }

  private glowFlash(x: number, y: number, z: number, color: string, size: number, life = 0.15) {
    this.spawnSmoke(x, y, z, color, life, size, 0);
    const s = this.smokes.find((k) => k.life > 0);
    if (s) s.mat.opacity = 0.9;
  }

  private burst(x: number, y: number, z: number, n: number, color: string, speed: number, life: number, grav = 0) {
    for (let i = 0; i < n; i++) {
      const a = rand(0, TAU), b = rand(-1, 1);
      const s = rand(speed * 0.25, speed);
      const h = Math.sqrt(Math.max(0, 1 - b * b));
      this.spawnP(x, y, z, Math.cos(a) * h * s, b * s + speed * 0.25, Math.sin(a) * h * s, rand(life * 0.5, life), rand(0.05, 0.14), color, grav, 2);
    }
  }
  private blood(x: number, y: number, z: number, n: number, big = false) {
    const cols = ["#a31515", "#d42a2a", "#7a0d0d"];
    for (let i = 0; i < n; i++) {
      const a = rand(0, TAU);
      const s = rand(1, big ? 6 : 3.5);
      this.spawnP(x, y, z, Math.cos(a) * s, rand(0.5, big ? 5 : 3), Math.sin(a) * s, rand(0.3, 0.8), rand(0.06, big ? 0.18 : 0.12), cols[(Math.random() * cols.length) | 0], 9, 1.2);
    }
    this.spawnSmoke(x, y + 0.2, z, "#7a0d0d", 0.4, big ? 1.4 : 0.9, 0.6);
  }

  private updateParticles(dt: number) {
    for (let i = 0; i < this.particles.length; i++) {
      const p = this.particles[i];
      if (!p.alive) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.alive = false;
        this.pDummy.position.set(0, -99, 0); this.pDummy.scale.setScalar(0.0001); this.pDummy.updateMatrix();
        this.pMesh.setMatrixAt(i, this.pDummy.matrix);
        continue;
      }
      const dr = 1 - Math.min(1, p.drag * dt);
      p.vx *= dr; p.vz *= dr;
      p.vy = p.vy * dr - p.grav * dt;
      p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
      if (p.y < 0.03 && p.grav > 0) { p.y = 0.03; p.vy *= -0.3; p.vx *= 0.7; p.vz *= 0.7; }
      const k = p.life / p.max;
      this.pDummy.position.set(p.x, p.y, p.z);
      this.pDummy.scale.setScalar(Math.max(0.001, p.size * (0.4 + k * 0.6)));
      this.pDummy.rotation.set(0, 0, 0);
      this.pDummy.updateMatrix();
      this.pMesh.setMatrixAt(i, this.pDummy.matrix);
      this.pColor.setRGB(p.r * (0.5 + k * 0.5), p.g * (0.5 + k * 0.5), p.b * (0.5 + k * 0.5));
      this.pMesh.setColorAt(i, this.pColor);
    }
    this.pMesh.instanceMatrix.needsUpdate = true;
    if (this.pMesh.instanceColor) this.pMesh.instanceColor.needsUpdate = true;
    for (const s of this.smokes) {
      if (s.life <= 0) continue;
      s.life -= dt;
      if (s.life <= 0) { s.spr.visible = false; continue; }
      const k = s.life / s.max;
      s.spr.position.x += s.vx * dt; s.spr.position.y += s.vy * dt; s.spr.position.z += s.vz * dt;
      s.spr.scale.setScalar(s.spr.scale.x + s.grow * dt);
      s.mat.opacity = 0.4 * k;
    }
  }

  private addHole(x: number, y: number, z: number, nx: number, ny: number, nz: number) {
    if (this.holes.length > 46) {
      const old = this.holes.shift()!;
      this.scene.remove(old.mesh);
    }
    const m = new THREE.Mesh(
      new THREE.PlaneGeometry(0.28, 0.28),
      new THREE.MeshBasicMaterial({ map: this.holeTex, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 })
    );
    m.position.set(x + nx * 0.02, y + ny * 0.02, z + nz * 0.02);
    m.lookAt(x + nx, y + ny, z + nz);
    m.rotation.z = rand(0, TAU);
    this.scene.add(m);
    this.holes.push({ mesh: m, life: 60 });
  }

  private addBloodPool(x: number, z: number, big: boolean) {
    if (this.decals.length > 50) {
      const old = this.decals.shift()!;
      this.scene.remove(old.mesh);
    }
    const dm = new THREE.MeshBasicMaterial({ map: this.bloodTex, transparent: true, opacity: rand(0.75, 0.95), depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1 });
    const dc = new THREE.Mesh(new THREE.PlaneGeometry(big ? 2.6 : 1.5, big ? 2.6 : 1.5), dm);
    dc.rotation.x = -Math.PI / 2; dc.rotation.z = rand(0, TAU);
    dc.position.set(x + rand(-0.2, 0.2), 0.02, z + rand(-0.2, 0.2));
    this.scene.add(dc);
    this.decals.push({ mesh: dc, mat: dm, life: 45 });
  }

  /* ============================== WEAPON VIEWMODEL ============================== */
  private buildWeaponRig() {
    this.gunRoot.position.set(0.28, -0.27, -0.55);
    this.camera.add(this.gunRoot);
    const cv = document.createElement("canvas");
    cv.width = cv.height = 128;
    const c = cv.getContext("2d")!;
    const g = c.createRadialGradient(64, 64, 4, 64, 64, 64);
    g.addColorStop(0, "rgba(255,255,240,1)");
    g.addColorStop(0.3, "rgba(255,200,100,0.9)");
    g.addColorStop(1, "rgba(255,150,40,0)");
    c.fillStyle = g; c.fillRect(0, 0, 128, 128);
    const tex = new THREE.CanvasTexture(cv);
    tex.colorSpace = THREE.SRGBColorSpace;
    this.flashSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
    this.flashSprite.scale.set(0.5, 0.5, 1);
    this.flashSprite.visible = false;
    // estrela do clarão (2 planos cruzados)
    this.flashStar = new THREE.Mesh(
      this.geoBox,
      new THREE.MeshBasicMaterial({ color: 0xffe9b0, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false })
    );
    this.flashStar.visible = false;
    this.rebuildGun();
  }

  private bx(w: number, h: number, d: number, mat: THREE.Material, x: number, y: number, z: number, parent: THREE.Object3D, shadow = false) {
    const m = new THREE.Mesh(this.geoBox, mat);
    m.scale.set(w, h, d); m.position.set(x, y, z);
    if (shadow) m.castShadow = true;
    parent.add(m);
    return m;
  }

  /* -------- FACA TÁTICA (botão direito, 150 de dano) -------- */
  private buildKnifeRig() {
    this.knifeRig.visible = false;
    this.camera.add(this.knifeRig);
    const steel = new THREE.MeshStandardMaterial({ color: 0xcfd6dd, metalness: 0.95, roughness: 0.22, emissive: 0x5a6a7a, emissiveIntensity: 0.25 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x14161a, metalness: 0.4, roughness: 0.6 });
    const gripM = new THREE.MeshStandardMaterial({ color: 0x2a1f16, roughness: 0.85 });
    // lâmina
    this.knifeBlade = new THREE.Mesh(this.geoBox, steel);
    this.knifeBlade.scale.set(0.035, 0.05, 0.34);
    this.knifeBlade.position.set(0, 0, -0.3);
    this.knifeRig.add(this.knifeBlade);
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.025, 0.09, 4), steel);
    tip.rotation.x = -Math.PI / 2;
    tip.position.set(0, 0, -0.51);
    this.knifeRig.add(tip);
    const edge = new THREE.Mesh(this.geoBox, new THREE.MeshBasicMaterial({ color: 0xeaf4ff, toneMapped: false, transparent: true, opacity: 0.9 }));
    edge.scale.set(0.008, 0.052, 0.34);
    edge.position.set(0.02, 0, -0.3);
    this.knifeRig.add(edge);
    // guarda + cabo
    const guard = new THREE.Mesh(this.geoBox, dark);
    guard.scale.set(0.11, 0.03, 0.03); guard.position.set(0, 0, -0.12);
    this.knifeRig.add(guard);
    const grip = new THREE.Mesh(this.geoBox, gripM);
    grip.scale.set(0.045, 0.055, 0.16); grip.position.set(0, -0.01, -0.02);
    grip.rotation.x = 0.15;
    this.knifeRig.add(grip);
    // mão
    const hand = new THREE.Mesh(this.geoSphere, this.handMat);
    hand.scale.set(0.14, 0.12, 0.16); hand.position.set(0, -0.05, 0.06);
    this.knifeRig.add(hand);
    const sleeve = new THREE.Mesh(this.geoCyl, this.sleeveMat);
    sleeve.scale.set(0.22, 0.3, 0.22); sleeve.rotation.x = Math.PI / 2 - 0.3;
    sleeve.position.set(0, -0.08, 0.2);
    this.knifeRig.add(sleeve);
    // rastro do corte (arco translúcido)
    this.knifeTrailMat = new THREE.MeshBasicMaterial({ color: 0xcfe6ff, transparent: true, opacity: 0, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false });
    this.knifeTrail = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 0.5), this.knifeTrailMat);
    this.knifeTrail.position.set(0, 0, -0.9);
    this.knifeRig.add(this.knifeTrail);
    this.knifeRig.position.set(0.32, -0.3, -0.4);
    this.knifeRig.rotation.set(0.3, -0.4, 0.2);
  }

  private triggerKnife() {
    if (this.knifeCd > 0 || this.knifeT > 0 || this.dying > 0 || this.deadDone || this.paused || this.currentChoices) return;
    this.knifeT = 0.42; this.knifeCd = 0.62; this.knifeDidHit = false;
    this.reloading = false;
    this.ads = false;
    this.knifeRig.visible = true;
    sound.knifeSwing();
  }

  private updateKnife(dt: number) {
    this.knifeCd = Math.max(0, this.knifeCd - dt);
    if (this.knifeT <= 0) { this.knifeRig.visible = false; this.knifeTrailMat.opacity = 0; this.knifeLight.intensity = 0; return; }
    this.knifeT -= dt;
    const T = 0.42;
    const k = 1 - Math.max(0, this.knifeT) / T; // 0→1
    // coreografia: recolhe na direita → slash rápido p/ esquerda → recolhe
    let px2 = 0.32, py2 = -0.3, pz2 = -0.4, ry = -0.4, rx = 0.3, rz = 0.2;
    if (k < 0.3) {
      const u = k / 0.3;
      px2 = 0.32 + u * 0.06; py2 = -0.3 + u * 0.06; rz = 0.2 + u * 0.5; ry = -0.4 - u * 0.25;
    } else if (k < 0.55) {
      const u = (k - 0.3) / 0.25;
      const e = u * u * (3 - 2 * u);
      px2 = 0.38 - e * 0.75; py2 = -0.24 + Math.sin(e * Math.PI) * 0.06; pz2 = -0.4 - Math.sin(e * Math.PI) * 0.28;
      ry = -0.65 + e * 1.5; rz = 0.7 - e * 1.3; rx = 0.3 - e * 0.5;
    } else {
      const u = (k - 0.55) / 0.45;
      px2 = -0.37 + u * 0.69; py2 = -0.18 - u * 0.12; pz2 = -0.68 + u * 0.28;
      ry = 0.85 - u * 1.25; rz = -0.6 + u * 0.8; rx = -0.2 + u * 0.5;
    }
    this.knifeRig.position.set(px2, py2, pz2);
    this.knifeRig.rotation.set(rx, ry, rz);
    // rastro aparece no slash
    const slash = k > 0.3 && k < 0.62 ? 1 : 0;
    this.knifeTrailMat.opacity = slash * 0.55 * (1 - Math.abs(k - 0.46) * 3);
    this.knifeTrail.rotation.z = -0.5 + k * 1.2;
    this.knifeTrail.scale.set(0.7 + k * 0.6, 1, 1);
    this.knifeLight.intensity = slash * 9;
    // câmera acompanha o corte
    // (o shake/roll é aplicado na câmera no update principal via knifeT)
    // dano no momento do slash
    if (!this.knifeDidHit && k >= 0.38 && k <= 0.6) {
      this.knifeDidHit = true;
      this.knifeHitCheck();
    }
  }

  private knifeHitCheck() {
    this.camera.getWorldDirection(this.tmpV1);
    let best: Zombie | null = null; let bestD = KNIFE_RANGE;
    for (const z of this.zombies) {
      if (z.dead || z.spawnT > 0.35) continue;
      this.tmpV2.set(z.x - this.px, 1.2 - (EYE + this.feetY), z.z - this.pz);
      const d = this.tmpV2.length();
      if (d > KNIFE_RANGE + z.radius) continue;
      this.tmpV2.normalize();
      const dot = this.tmpV1.dot(this.tmpV2);
      if (dot > 0.72 && d < bestD) { bestD = d; best = z; }
    }
    if (best) {
      const dmgMult = DMG_MULT[this.abilityLevels["dmg"] ?? 0] ?? 1;
      const dmg = this.instaT > 0 ? 9999 : KNIFE_DMG * dmgMult;
      best.hp -= dmg; best.flash = 0.12;
      this.blood(best.x, best.group.position.y + 1.3, best.z, 16, true);
      this.spawnSmoke(best.x, 1.4, best.z, "#a31515", 0.5, 1.1, 0.8);
      this.hits++;
      this.addPoints(15);
      this.hitA = 0.35; this.hitKill = false; this.hitHead = false;
      this.trauma = Math.min(1, this.trauma + 0.3);
      sound.knifeHit(); sound.zombieHit();
      this.spawnText(best.x, best.group.position.y + 2.2, best.z, `🔪 ${Math.round(dmg)}`, "#ffd94f", 1);
      if (best.hp <= 0 && !best.dead) { this.killZombie(best, false, "knife"); this.hitKill = true; }
    } else {
      // cortou o ar — poeira leve na frente
      this.camera.getWorldDirection(this.tmpV1);
      this.spawnSmoke(this.px + this.tmpV1.x * 1.4, EYE + this.feetY - 0.1, this.pz + this.tmpV1.z * 1.4, "#8a8a8a", 0.4, 0.7, 0.3);
    }
  }

  private rebuildGun() {
    while (this.gunRoot.children.length) this.gunRoot.remove(this.gunRoot.children[0]);
    const w = this.weapons[this.cur];
    const def = WEAPONS[w.defId];
    const accent = new THREE.MeshBasicMaterial({
      color: new THREE.Color(def.id === "mp5k" ? "#57c8ff" : def.id === "ak47" ? "#ffb066" : def.id === "raygun" ? "#5dff8d" : def.id === "reaper" ? "#c77dff" : "#c8ccd2"),
      toneMapped: false,
    });
    const metal = this.gunMetal, poly = this.gunPoly;
    if (def.id === "m1911") {
      this.bx(0.075, 0.1, 0.26, metal, 0, 0.01, -0.2, this.gunRoot);
      this.bx(0.02, 0.02, 0.1, accent, 0, 0.03, -0.36, this.gunRoot);
      this.bx(0.02, 0.05, 0.02, accent, 0, 0.085, -0.3, this.gunRoot);
      const grip = this.bx(0.07, 0.19, 0.09, this.gunWood, 0, -0.13, -0.06, this.gunRoot);
      grip.rotation.x = 0.22;
      this.bx(0.06, 0.03, 0.07, metal, 0, 0.055, -0.1, this.gunRoot);
    } else if (def.id === "mp5k") {
      this.bx(0.085, 0.12, 0.4, metal, 0, 0, -0.28, this.gunRoot);
      this.bx(0.095, 0.03, 0.34, poly, 0, 0.075, -0.28, this.gunRoot);
      for (let i = 0; i < 4; i++) this.bx(0.1, 0.015, 0.03, poly, 0, -0.045, -0.36 - i * 0.055, this.gunRoot);
      this.bx(0.04, 0.04, 0.22, metal, 0, 0.01, -0.58, this.gunRoot);
      this.bx(0.05, 0.03, 0.06, accent, 0, 0.03, -0.66, this.gunRoot);
      const mag = this.bx(0.06, 0.24, 0.08, metal, 0, -0.16, -0.3, this.gunRoot);
      mag.rotation.x = -0.12;
      const grip = this.bx(0.065, 0.18, 0.08, poly, 0, -0.14, -0.1, this.gunRoot);
      grip.rotation.x = 0.3;
      this.bx(0.07, 0.1, 0.16, poly, 0, -0.02, 0.02, this.gunRoot);
      this.bx(0.02, 0.06, 0.02, accent, 0, 0.11, -0.14, this.gunRoot);
      this.bx(0.05, 0.05, 0.02, metal, 0, 0.1, -0.42, this.gunRoot);
      this.bx(0.03, 0.09, 0.2, poly, 0, -0.05, 0.1, this.gunRoot);
    } else if (def.id === "ak47") {
      this.bx(0.085, 0.11, 0.42, metal, 0, 0, -0.3, this.gunRoot);
      this.bx(0.08, 0.09, 0.26, this.gunWood, 0, -0.01, -0.55, this.gunRoot);
      this.bx(0.045, 0.045, 0.3, metal, 0, 0.02, -0.72, this.gunRoot);
      this.bx(0.05, 0.04, 0.07, accent, 0, 0.03, -0.85, this.gunRoot);
      this.bx(0.075, 0.1, 0.24, this.gunWood, 0, -0.03, 0.06, this.gunRoot);
      const mag = this.bx(0.065, 0.26, 0.09, metal, 0, -0.17, -0.32, this.gunRoot);
      mag.rotation.x = 0.35;
      const grip = this.bx(0.065, 0.18, 0.085, this.gunWood, 0, -0.13, -0.08, this.gunRoot);
      grip.rotation.x = 0.35;
      this.bx(0.02, 0.07, 0.02, accent, 0, 0.1, -0.12, this.gunRoot);
      this.bx(0.02, 0.06, 0.02, accent, 0, 0.09, -0.8, this.gunRoot);
    } else {
      // RAY GUN / CEIFADOR — corpo com bobinas (verde ou roxo)
      const isReaper = def.id === "reaper";
      const bodyMat = new THREE.MeshStandardMaterial({ color: isReaper ? 0x241430 : 0x14301c, metalness: 0.6, roughness: 0.4 });
      this.bx(0.1, 0.14, 0.4, bodyMat, 0, 0, -0.3, this.gunRoot);
      this.bx(0.11, 0.05, 0.3, accent, 0, 0.085, -0.3, this.gunRoot);
      for (let i = 0; i < 3; i++) this.bx(0.12, 0.025, 0.06, accent, 0, -0.03 + i * 0.04, -0.42, this.gunRoot);
      this.bx(0.05, 0.05, 0.24, accent, 0, 0.01, -0.6, this.gunRoot);
      const cell = new THREE.Mesh(this.geoSphere, accent);
      cell.scale.set(0.12, 0.12, 0.16); cell.position.set(0, -0.1, -0.2);
      this.gunRoot.add(cell);
      const grip = this.bx(0.07, 0.19, 0.09, bodyMat, 0, -0.15, -0.08, this.gunRoot);
      grip.rotation.x = 0.25;
      this.bx(0.02, 0.05, 0.02, accent, 0, 0.1, -0.14, this.gunRoot);
      if (isReaper) {
        // lâminas laterais do Ceifador
        for (const sx of [-1, 1]) {
          const fin = this.bx(0.02, 0.16, 0.3, accent, sx * 0.07, 0.02, -0.45, this.gunRoot);
          fin.rotation.z = sx * 0.25;
        }
      }
    }
    // mãos + mangas
    const h1 = new THREE.Mesh(this.geoSphere, this.handMat);
    h1.scale.set(0.15, 0.12, 0.15); h1.position.set(0, -0.1, -0.1);
    this.gunRoot.add(h1);
    if (def.id !== "m1911") {
      const h2 = new THREE.Mesh(this.geoSphere, this.handMat);
      h2.scale.set(0.14, 0.12, 0.14); h2.position.set(0, -0.07, -0.42);
      this.gunRoot.add(h2);
      const sleeve = new THREE.Mesh(this.geoCyl, this.sleeveMat);
      sleeve.scale.set(0.22, 0.3, 0.22); sleeve.rotation.x = Math.PI / 2 - 0.25;
      sleeve.position.set(0, -0.09, -0.62);
      this.gunRoot.add(sleeve);
    }
    const sleeveR = new THREE.Mesh(this.geoCyl, this.sleeveMat);
    sleeveR.scale.set(0.24, 0.34, 0.24); sleeveR.rotation.x = Math.PI / 2 - 0.4;
    sleeveR.position.set(0.02, -0.2, 0.12);
    this.gunRoot.add(sleeveR);
    // boca do cano + flash
    this.muzzleTip.position.set(0, 0.02, def.id === "m1911" ? -0.42 : def.id === "raygun" ? -0.75 : -0.9);
    this.gunRoot.add(this.muzzleTip);
    this.flashSprite.position.copy(this.muzzleTip.position);
    this.flashSprite.scale.set(0.55, 0.55, 1);
    this.gunRoot.add(this.flashSprite);
    this.flashStar.position.copy(this.muzzleTip.position);
    this.flashStar.scale.set(0.06, 0.06, def.id === "raygun" ? 0.5 : 0.34);
    this.gunRoot.add(this.flashStar);
  }

  private buildAbilityMeshes() {
    // CAMPO SUTIL NO CHÃO: só um filete + véu quase invisível (sem bolha, sem wire, sem bloom)
    this.fieldMat = new THREE.MeshBasicMaterial({ color: 0x3f9e63, transparent: true, opacity: 0.05, side: THREE.DoubleSide, depthWrite: false });
    const disc = new THREE.Mesh(new THREE.CircleGeometry(1, 40), this.fieldMat);
    disc.rotation.x = -Math.PI / 2; disc.position.y = 0;
    this.fieldGroup.add(disc);
    this.fieldWire = new THREE.Mesh(
      new THREE.RingGeometry(0.985, 1.0, 48),
      new THREE.MeshBasicMaterial({ color: 0x4fae72, transparent: true, opacity: 0.28, side: THREE.DoubleSide, depthWrite: false })
    );
    this.fieldWire.rotation.x = -Math.PI / 2; this.fieldWire.position.y = 0.01;
    this.fieldGroup.add(this.fieldWire);
    this.fieldRing = new THREE.Mesh(
      new THREE.TorusGeometry(0.995, 0.012, 8, 48),
      new THREE.MeshBasicMaterial({ color: 0x63c78a, transparent: true, opacity: 0.32, depthWrite: false })
    );
    this.fieldRing.rotation.x = -Math.PI / 2;
    this.fieldRing.position.y = 0.02;
    this.fieldGroup.add(this.fieldRing);
    this.fieldGroup.visible = false;
    this.scene.add(this.fieldGroup);
    // LÂMINAS NO CHÃO: pequenas, foscas, rente ao piso, sem brilho
    const bladeMat = new THREE.MeshStandardMaterial({ color: 0x9aa6b2, metalness: 0.55, roughness: 0.5 });
    const guardMat = new THREE.MeshStandardMaterial({ color: 0x5a636e, metalness: 0.4, roughness: 0.6 });
    const gripM = new THREE.MeshStandardMaterial({ color: 0x33291d, roughness: 0.9 });
    for (let i = 0; i < 5; i++) {
      const sw = new THREE.Group();
      const bl = new THREE.Mesh(this.geoBox, bladeMat);
      bl.scale.set(0.045, 0.5, 0.016); bl.position.y = 0.25;
      sw.add(bl);
      const gd = new THREE.Mesh(this.geoBox, guardMat);
      gd.scale.set(0.17, 0.035, 0.05); gd.position.y = -0.015;
      sw.add(gd);
      const hb = new THREE.Mesh(this.geoBox, gripM);
      hb.scale.set(0.04, 0.13, 0.04); hb.position.y = -0.1;
      sw.add(hb);
      const gl = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: 0xbdd7ff, transparent: true, opacity: 0.0, blending: THREE.AdditiveBlending, depthWrite: false }));
      gl.scale.setScalar(0.3);
      sw.add(gl);
      this.bladeGlows.push(gl);
      sw.visible = false;
      // deitadas rente ao chão, como lâminas varrendo o piso
      sw.rotation.x = Math.PI / 2 - 0.12;
      this.scene.add(sw);
      this.bladeMeshes.push(sw);
    }
    // nova
    this.novaMat = new THREE.MeshBasicMaterial({ color: 0x7dd7ff, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending });
    this.novaMesh = new THREE.Mesh(this.geoSphere, this.novaMat);
    this.novaMesh.visible = false;
    this.scene.add(this.novaMesh);
    this.novaRingMat = new THREE.MeshBasicMaterial({ color: 0xbfe9ff, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false });
    this.novaRing = new THREE.Mesh(new THREE.TorusGeometry(1, 0.09, 10, 48), this.novaRingMat);
    this.novaRing.rotation.x = -Math.PI / 2;
    this.novaRing.visible = false;
    this.scene.add(this.novaRing);
    // raios (grupo de 3 cilindros em zigue-zague)
    const boltMat = new THREE.MeshBasicMaterial({ color: 0xe2f2ff, transparent: true, opacity: 0, toneMapped: false, blending: THREE.AdditiveBlending, depthWrite: false });
    for (let i = 0; i < 3; i++) {
      const seg = new THREE.Mesh(new THREE.CylinderGeometry(0.1 - i * 0.02, 0.14 - i * 0.02, 5, 6), boltMat);
      seg.position.y = -i * 4.4;
      seg.rotation.z = (i % 2 ? 1 : -1) * 0.22;
      this.boltGroup.add(seg);
    }
    const boltGlow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: 0xcfe6ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false }));
    boltGlow.scale.setScalar(4);
    boltGlow.position.y = -6;
    this.boltGroup.add(boltGlow);
    this.boltGroup.visible = false;
    this.scene.add(this.boltGroup);
  }

  /* ============================== ZOMBIES ============================== */
  private zSkin(type: ZType): [THREE.MeshStandardMaterial, THREE.MeshStandardMaterial, THREE.MeshStandardMaterial] {
    const tints = type === "brute"
      ? [0x4a3d33, 0x55452f, 0x40342a]
      : type === "runner"
        ? [0x3a4034, 0x44483a, 0x333b30]
        : [0x39413a, 0x414a3c, 0x323a34, 0x46413a, 0x3a3f45];
    const jackets = [0x4a3b2c, 0x39424e, 0x3d4a38, 0x503030, 0x444444];
    const t = tints[(Math.random() * tints.length) | 0];
    const j = jackets[(Math.random() * jackets.length) | 0];
    const cloth = new THREE.MeshStandardMaterial({ color: j, roughness: 0.95 });
    const skin = new THREE.MeshStandardMaterial({ color: t, roughness: 0.7 });
    const flesh = new THREE.MeshStandardMaterial({ color: 0x6f7d66, roughness: 0.75 });
    // mancha de sangue no peito
    return [cloth, skin, flesh];
  }

  private makeZombieMesh(type: ZType, scale: number) {
    const group = new THREE.Group();
    const [cloth, skin, flesh] = this.zSkin(type);
    const pants = new THREE.MeshStandardMaterial({ color: 0x23282b, roughness: 0.95 });
    const boot = new THREE.MeshStandardMaterial({ color: 0x14100c, roughness: 0.9 });
    const mats = [cloth, skin, flesh, pants];
    const mkLimb = (w: number, h: number, dpt: number, m: THREE.Material) => {
      const pivot = new THREE.Group();
      const mesh = new THREE.Mesh(this.geoBox, m);
      mesh.scale.set(w, h, dpt);
      mesh.position.y = -h / 2;
      mesh.castShadow = true;
      pivot.add(mesh);
      return pivot;
    };
    const legL = mkLimb(0.24, 0.85, 0.26, pants); legL.position.set(-0.17, 0.85, 0);
    const legR = mkLimb(0.24, 0.85, 0.26, pants); legR.position.set(0.17, 0.85, 0);
    group.add(legL, legR);
    for (const [lx, s] of [[-0.17, 1], [0.17, 1]] as [number, number][]) {
      void s;
      const b = new THREE.Mesh(this.geoBox, boot);
      b.scale.set(0.26, 0.16, 0.4); b.position.set(lx, 0.08, 0.05);
      b.castShadow = true;
      group.add(b);
    }
    // tronco com jaqueta rasgada
    const torso = new THREE.Mesh(this.geoBox, cloth);
    torso.scale.set(0.66, 0.78, 0.42); torso.position.y = 1.22;
    torso.castShadow = true;
    group.add(torso);
    const rip = new THREE.Mesh(this.geoBox, skin);
    rip.scale.set(0.3, 0.4, 0.44); rip.position.set(0.08, 1.1, 0);
    group.add(rip);
    const stain = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.4), new THREE.MeshBasicMaterial({ color: 0x4a0808, transparent: true, opacity: 0.85, depthWrite: false }));
    stain.position.set(-0.08, 1.28, 0.22);
    group.add(stain);
    const armL = mkLimb(0.17, 0.72, 0.19, cloth); armL.position.set(-0.44, 1.55, 0); armL.rotation.x = -1.35;
    const armR = mkLimb(0.17, 0.72, 0.19, cloth); armR.position.set(0.44, 1.55, 0); armR.rotation.x = -1.35;
    group.add(armL, armR);
    // garras
    for (const arm of [armL, armR]) {
      for (const fx of [-0.04, 0.04]) {
        const claw = new THREE.Mesh(new THREE.ConeGeometry(0.035, 0.16, 6), flesh);
        claw.position.set(fx, -0.78, -0.06); claw.rotation.x = Math.PI;
        arm.add(claw);
      }
    }
    // cabeça + mandíbula + dentes
    const headM = new THREE.Mesh(this.geoSphere, skin);
    headM.scale.set(0.44, 0.48, 0.44); headM.position.y = 1.9;
    headM.castShadow = true;
    group.add(headM);
    const jaw = new THREE.Mesh(this.geoBox, flesh);
    jaw.scale.set(0.24, 0.1, 0.2); jaw.position.set(0, 1.72, 0.14);
    group.add(jaw);
    for (const tx of [-0.06, 0, 0.06]) {
      const tooth = new THREE.Mesh(this.geoBox, new THREE.MeshBasicMaterial({ color: 0xd8d2b8 }));
      tooth.scale.set(0.035, 0.05, 0.02); tooth.position.set(tx, 1.78, 0.24);
      group.add(tooth);
    }
    const eyeMat = new THREE.MeshBasicMaterial({ color: type === "brute" ? 0xff9d2e : 0xff3b3b, toneMapped: false });
    for (const ex of [-0.1, 0.1]) {
      const e = new THREE.Mesh(this.geoSphere, eyeMat);
      e.scale.set(0.075, 0.075, 0.05); e.position.set(ex, 1.94, 0.2);
      group.add(e);
    }
    const eyeGlow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: type === "brute" ? 0xff9d2e : 0xff3b3b, transparent: true, opacity: 0.75, blending: THREE.AdditiveBlending, depthWrite: false }));
    eyeGlow.scale.setScalar(type === "brute" ? 0.55 : 0.42);
    eyeGlow.position.set(0, 1.94, 0.26);
    group.add(eyeGlow);
    if (type === "brute") {
      for (let s = -1; s <= 1; s++) {
        const spike = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.4, 6), pants);
        spike.position.set(s * 0.28, 1.75, -0.22); spike.rotation.x = -0.5;
        spike.castShadow = true;
        group.add(spike);
      }
      const pad1 = new THREE.Mesh(this.geoBox, boot);
      pad1.scale.set(0.3, 0.18, 0.34); pad1.position.set(-0.48, 1.62, 0);
      group.add(pad1);
      const pad2 = pad1.clone(); pad2.position.x = 0.48; group.add(pad2);
    }
    group.scale.setScalar(scale);
    group.traverse((o) => { if ((o as THREE.Mesh).isMesh) (o as THREE.Mesh).castShadow = true; });
    return { group, legL, legR, armL, armR, headM, mats, eyeGlow };
  }

  private activeWindows(): GameWindow[] {
    return this.windows.filter((w) => this.zonesOpen[w.zone]);
  }

  private pickWindow(): GameWindow | null {
    const act = this.activeWindows();
    if (!act.length) return null;
    // 70% na mesma área do jogador (perto), 30% flanco (longe)
    const near = act.filter((w) => {
      const dx = w.inX - this.px, dz = w.inZ - this.pz;
      return dx * dx + dz * dz < 30 * 30 && dx * dx + dz * dz > 6 * 6;
    });
    const pool = near.length >= 2 || Math.random() < 0.7 ? (near.length ? near : act) : act;
    return pool[(Math.random() * pool.length) | 0];
  }

  private spawnZombie(fx?: number, fz?: number, forceWin?: GameWindow) {
    const r = Math.random();
    let type: ZType = "walker";
    const inTower = this.mapId === "fortaleza" && this.pz < -24 && Math.abs(this.px) < 30;
    const bruteCh = inTower ? 0.24 : this.round >= 7 ? 0.14 : 0;
    const runCh = this.round >= 4 ? 0.38 : 0;
    if (r < bruteCh) type = "brute";
    else if (r < bruteCh + runCh) type = "runner";
    // progressão suave (não exagerada): +13% hp/round, cap de velocidade 1.4x
    const R = Math.max(1, this.round);
    const hpMul = 1 + (R - 1) * 0.13 + Math.pow(Math.max(0, R - 1), 1.5) * 0.02;
    const spMul = Math.min(1.4, 1 + (R - 1) * 0.03);
    let hp = 105 * hpMul, speed = rand(2.0, 2.7) * spMul, radius = 0.5, dmg = 15 + Math.min(10, (R - 1) * 0.7);
    if (type === "runner") { hp *= 0.55; speed = rand(4.2, 5.0) * Math.min(1.25, spMul); dmg = 10 + Math.min(7, (R - 1) * 0.5); radius = 0.42; }
    if (type === "brute") { hp *= 3.2; speed = rand(1.45, 1.8) * spMul; dmg = 30 + Math.min(12, (R - 1) * 0.9); radius = 0.7; }
    if (R === 1) hp = 100;
    const scale = type === "brute" ? 1.35 : type === "runner" ? 0.92 : 1;
    const parts = this.makeZombieMesh(type, scale);
    let sx: number, sz: number, winId = -1, state: Zombie["state"] = "chase", dropFromSky = false;
    const win = forceWin ?? (fx === undefined ? this.pickWindow() : undefined);
    if (win && win.vent) {
      // cai do duto do teto direto na sala
      winId = win.id; state = "enter";
      sx = win.inX + rand(-1.2, 1.2); sz = win.inZ + rand(-1.2, 1.2);
      dropFromSky = true;
      parts.group.position.set(sx, 4.6, sz);
    } else if (win) {
      winId = win.id; state = "towin";
      sx = win.outX + rand(-0.8, 0.8); sz = win.outZ + rand(-0.8, 0.8);
      parts.group.position.set(sx, 0, sz);
    } else {
      if (fx !== undefined && fz !== undefined) { sx = fx; sz = fz; }
      else if (this.spawns.length) {
        const cands = [...this.spawns].sort(() => Math.random() - 0.5);
        let sp = cands[0];
        for (const c of cands) {
          const dx = c.x - this.px, dz = c.z - this.pz;
          if (dx * dx + dz * dz > 14 * 14) { sp = c; break; }
        }
        sx = sp.x + rand(-1, 1); sz = sp.z + rand(-1, 1);
      } else {
        // fallback seguro: nasce atrás do jogador, longe da vista
        const a = Math.atan2(this.px, this.pz) + Math.PI + rand(-0.6, 0.6);
        sx = this.px + Math.sin(a) * 16; sz = this.pz + Math.cos(a) * 16;
      }
      parts.group.position.set(sx, -1.9, sz);
    }
    this.scene.add(parts.group);
    if (state === "chase") {
      this.burst(sx, 0.4, sz, 12, "#3a4436", 3, 0.7);
      this.spawnSmoke(sx, 0.8, sz, "#2a332a", 1.1, 2.2, 0.7);
    } else {
      this.burst(sx, 0.6, sz, 6, "#232a22", 2, 0.6);
    }
    this.zombies.push({
      id: this.zid++, type, group: parts.group, legL: parts.legL, legR: parts.legR, armL: parts.armL, armR: parts.armR, headM: parts.headM,
      mats: parts.mats, eyeGlow: parts.eyeGlow,
      x: sx, z: sz, hp, maxHp: hp, speed, radius, damage: dmg, atk: 0, spawnT: state === "towin" ? 0 : 1.1, deathT: 0, dead: false, deadGone: 0,
      wob: rand(0, TAU), flash: 0, lunge: 0, groan: rand(1, 5), bladeCd: 0, slowT: 0, slowMult: 1, scale,
      winId, state, barAtk: 0, dropFromSky,
    });
    if (state === "towin") sound.groan();
    if (dropFromSky) {
      this.burst(sx, 4.2, sz, 6, "#3a4048", 2, 0.5);
      sound.groan();
    }
  }

  private windowById(id: number): GameWindow | undefined { return this.windows.find((w) => w.id === id); }

  private breakPlank(win: GameWindow) {
    if (win.planks <= 0) return;
    win.planks--;
    const pm = win.plankMeshes[win.planks];
    if (pm) {
      pm.mesh.visible = false;
      // estilhaços de madeira p/ dentro
      this.burst(win.inX, 1.4, win.inZ, 10, "#7a5c38", 3.5, 0.6, 6);
      this.burst(win.inX, 1.2, win.inZ, 5, "#a38052", 2.5, 0.5, 5);
    }
    sound.plankBreak();
    win.hitT = 0.5;
    if (win.planks === 0) {
      this.spawnText(win.inX, 2.6, win.inZ, "BARREIRA ROMPIDA!", "#ff5b5b", 1);
      voice.barrier();
    }
  }

  private updateWindowsDoors(dt: number) {
    this.repairCd = Math.max(0, this.repairCd - dt);
    for (const w of this.windows) {
      w.hitT = Math.max(0, w.hitT - dt);
      w.rebuildCd = Math.max(0, w.rebuildCd - dt);
      // tábua reconstruída desce com bounce
      if (w.rebuildCd > 0 || w.planks < w.maxPlanks) {
        const idx = w.planks - 1;
        const pm = w.plankMeshes[idx];
        if (pm && pm.mesh.visible && w.rebuildCd > 0) {
          const target = pm.full;
          pm.mesh.position.y += (target - pm.mesh.position.y) * Math.min(1, 12 * dt);
          pm.mesh.rotation.z += (0 - pm.mesh.rotation.z) * Math.min(1, 10 * dt);
        }
      }
      // brilho: vermelho pulsante se tem zumbi quebrando
      const breaking = this.zombies.some((z) => !z.dead && z.winId === w.id && z.state === "barrier");
      const targetOp = breaking ? 0.55 + Math.sin(this.time * 10) * 0.2 : 0.18;
      const targetCol = breaking ? new THREE.Color(0xff2d2d) : new THREE.Color(0x3a1a1a);
      w.glowMat.opacity += (targetOp - w.glowMat.opacity) * Math.min(1, 6 * dt);
      (w.glowMat.color as THREE.Color).lerp(targetCol, Math.min(1, 6 * dt));
    }
    for (const d of this.doors) {
      if (d.opened && d.opening < 1) {
        d.opening = Math.min(1, d.opening + dt * 0.7);
        const e = d.opening * d.opening * (3 - 2 * d.opening);
        const l = d.panelL as unknown as THREE.Group;
        const r = d.panelR as unknown as THREE.Group;
        l.position.x = -d.w / 4 - e * (d.w / 2 + 0.4);
        r.position.x = d.w / 4 + e * (d.w / 2 + 0.4);
        l.rotation.y = e * 0.5; r.rotation.y = -e * 0.5;
        d.signMat.color.set(0x5dff8d);
        if (d.opening >= 1) { l.visible = false; r.visible = false; d.panel.visible = false; }
      }
      if (!d.opened) {
        const locked = this.round < d.reqRound;
        d.light.intensity = locked ? 5 + Math.sin(this.time * 3) * 2 : 8 + Math.sin(this.time * 5) * 3;
        d.light.color.set(locked ? 0xff4444 : 0xffd94f);
        d.signMat.color.lerp(new THREE.Color(locked ? 0xff4444 : 0xffd94f), Math.min(1, 4 * dt));
      } else {
        d.light.intensity = Math.max(0, d.light.intensity - dt * 10);
      }
    }
  }

  private nextRound(first = false) {
    this.round++;
    this.queue = Math.min(6 + this.round * 5, 46);
    this.spawnInterval = Math.max(0.28, 1.05 - this.round * 0.07);
    this.spawnT = first ? 0.8 : 0.4;
    const subs = ["ELES ESTÃO VINDO...", "SEGURE A POSIÇÃO!", "NÃO DEIXE ELES CHEGAREM!", "SOBREVIVA.", "A NOITE PIORA..."];
    this.banner = `ROUND ${this.round}`;
    this.bannerSub = subs[(Math.random() * subs.length) | 0];
    this.bannerT = 3.2;
    sound.roundStart();
    voice.round(this.round);
  }

  /* ============================== INPUT ============================== */
  private onResize = () => this.resize();
  private resize() {
    const parent = this.canvas.parentElement;
    const w = parent ? parent.clientWidth : window.innerWidth;
    const h = parent ? parent.clientHeight : window.innerHeight;
    const pr = clamp(window.devicePixelRatio || 1, 1, 2);
    this.renderer.setPixelRatio(pr);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / Math.max(1, h);
    this.camera.updateProjectionMatrix();
    if (typeof (this.composer as unknown as { setPixelRatio?: (n: number) => void } | null)?.setPixelRatio === "function") {
      (this.composer as unknown as { setPixelRatio: (n: number) => void }).setPixelRatio(pr);
    }
    this.composer?.setSize(w, h);
  }

  private attach() {
    const cv = this.canvas;
    const keyDown = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(k)) e.preventDefault();
      if (k === "tab") e.preventDefault();
      if (e.code === "Space") e.preventDefault();
      this.keys.add(k);
      this.keys.add(e.code);
      if (k === "r") this.reloadWeapon();
      if (k === "f" || k === "e") this.interact();
      if (k === "v") this.triggerKnife();
      if (k === "q" || k === "tab") this.cycleWeapon();
      if (k === "1") this.selectWeapon(0);
      if (k === "2") this.selectWeapon(1);
      if (e.code === "Space" || k === " ") this.queueJump();
      if (k === "p") this.onPauseKey?.();
    };
    const keyUp = (e: KeyboardEvent) => { this.keys.delete(e.key.toLowerCase()); this.keys.delete(e.code); };
    const mouseMove = (e: MouseEvent) => {
      if (!this.locked || this.paused || this.currentChoices || this.dying > 0) return;
      const sens = 0.0023 * (1 - this.adsK * 0.45);
      this.yaw -= e.movementX * sens;
      this.pitch -= e.movementY * sens;
      this.pitch = clamp(this.pitch, -1.45, 1.45);
      this.swayX = clamp(this.swayX - e.movementX * 0.0004, -0.03, 0.03);
      this.swayY = clamp(this.swayY - e.movementY * 0.0004, -0.03, 0.03);
    };
    const mouseDown = (e: MouseEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.closest("button") || t.closest("input"))) return;
      // BOTÃO DIREITO = FACADA (toque rápido) / mira ADS (segurar)
      if (e.button === 2) {
        sound.ensure();
        this.rmbHeld = true; this.rmbDownT = 0; this.rmbFiredKnife = false;
        return;
      }
      if (e.button !== 0) return;
      if (!this.locked && !this.isTouch && this.running && !this.paused && !this.currentChoices) {
        this.requestLock();
        return;
      }
      this.mouseDown = true;
      sound.ensure();
    };
    const mouseUp = (e: MouseEvent) => {
      if (e.button === 0) this.mouseDown = false;
      if (e.button === 2) {
        // soltou rápido = facada; segurou = estava mirando
        if (this.rmbHeld && !this.rmbFiredKnife && this.rmbDownT < 0.24) this.triggerKnife();
        this.rmbHeld = false; this.ads = false;
      }
    };
    const wheel = (e: WheelEvent) => { e.preventDefault(); this.cycleWeapon(); };
    const ctxMenu = (e: Event) => e.preventDefault();
    const blur = () => { this.keys.clear(); this.mouseDown = false; this.ads = false; };
    const lockChange = () => {
      this.locked = document.pointerLockElement === cv;
      if (!this.locked) this.ads = false;
      if (!this.locked && this.running && !this.paused && !this.currentChoices && this.dying <= 0 && this.started && !this.isTouch) {
        this.pause();
        this.onLockLost?.();
      }
    };
    window.addEventListener("keydown", keyDown);
    window.addEventListener("keyup", keyUp);
    window.addEventListener("mousemove", mouseMove);
    window.addEventListener("mousedown", mouseDown);
    window.addEventListener("mouseup", mouseUp);
    cv.addEventListener("wheel", wheel, { passive: false });
    cv.addEventListener("contextmenu", ctxMenu);
    window.addEventListener("blur", blur);
    window.addEventListener("resize", this.onResize);
    document.addEventListener("pointerlockchange", lockChange);
    this.detachFns = [
      () => window.removeEventListener("keydown", keyDown),
      () => window.removeEventListener("keyup", keyUp),
      () => window.removeEventListener("mousemove", mouseMove),
      () => window.removeEventListener("mousedown", mouseDown),
      () => window.removeEventListener("mouseup", mouseUp),
      () => cv.removeEventListener("wheel", wheel),
      () => cv.removeEventListener("contextmenu", ctxMenu),
      () => window.removeEventListener("blur", blur),
      () => window.removeEventListener("resize", this.onResize),
      () => document.removeEventListener("pointerlockchange", lockChange),
    ];
  }

  requestLock() {
    if (this.isTouch || this.locked) return;
    try {
      const p = this.canvas.requestPointerLock() as unknown as Promise<void> | undefined;
      if (p && typeof p.catch === "function") p.catch(() => undefined);
    } catch { /* noop */ }
  }
  isLocked() { return this.isTouch ? true : this.locked; }
  isLevelUpOpen() { return this.currentChoices !== null; }
  toggleADS() { this.ads = !this.ads; }
  /* -------- pulo / agachar -------- */
  queueJump() { this.jumpBuf = 0.15; }
  touchJump() { this.jumpBuf = 0.15; sound.ensure(); }
  toggleCrouch() { this.touchCrouch = !this.touchCrouch; sound.ensure(); }
  touchKnife() { sound.ensure(); this.triggerKnife(); }
  private wantCrouch(_mx: number, my: number): boolean {
    if (this.touchCrouch) return true;
    if (this.keys.has("c") || this.keys.has("controlleft") || this.keys.has("control")) return true;
    // SHIFT agacha (pedido) — mas se estiver indo p/ frente, SHIFT corre
    if (this.keys.has("shift") && !(my < -0.1)) return true;
    return false;
  }

  setTouchMove(x: number, y: number) { this.touchMove.x = x; this.touchMove.y = y; if (x || y) this.isTouch = true; }
  setTouchLook(dx: number, dy: number) {
    if (this.paused || this.currentChoices || this.dying > 0) return;
    this.isTouch = true;
    this.yaw -= dx * 0.0042;
    this.pitch -= dy * 0.0042;
    this.pitch = clamp(this.pitch, -1.45, 1.45);
  }
  setTouchFiring(b: boolean) { this.touchFiring = b; if (b) { this.isTouch = true; sound.ensure(); } }

  /* ============================== LIFECYCLE ============================== */
  start() {
    sound.ensure(); sound.startAmbience(); voice.prime();
    this.resetWorld();
    this.running = true; this.paused = false; this.destroyed = false; this.started = true;
    this.last = performance.now();
    cancelAnimationFrame(this.raf);
    this.raf = requestAnimationFrame(this.loop);
    if (!this.isTouch) this.requestLock();
  }
  pause() { this.paused = true; this.mouseDown = false; this.ads = false; if (document.pointerLockElement) document.exitPointerLock(); }
  resume() {
    if (!this.running) return;
    this.paused = false;
    this.last = performance.now();
    cancelAnimationFrame(this.raf);
    this.raf = requestAnimationFrame(this.loop);
    if (!this.isTouch) this.requestLock();
  }
  destroy() {
    this.destroyed = true; this.running = false;
    cancelAnimationFrame(this.raf);
    this.detachFns.forEach((f) => f());
    if (document.pointerLockElement) document.exitPointerLock();
    this.composer = null;
    this.renderer.dispose();
  }

  private resetWorld() {
    for (const z of this.zombies) this.scene.remove(z.group);
    for (const d of this.drops) { this.scene.remove(d.mesh); this.scene.remove(d.label); }
    for (const t of this.texts) { this.scene.remove(t.spr); t.tex.dispose(); (t.spr.material as THREE.Material).dispose(); }
    for (const tr of this.tracers) this.scene.remove(tr.mesh);
    for (const dc of this.decals) this.scene.remove(dc.mesh);
    for (const h of this.holes) this.scene.remove(h.mesh);
    this.zombies = []; this.drops = []; this.texts = []; this.tracers = []; this.decals = []; this.holes = [];
    for (const p of this.particles) p.alive = false;
    for (const s of this.smokes) { s.life = 0; s.spr.visible = false; }
    this.px = this.mapDef.spawn.x; this.pz = this.mapDef.spawn.z; this.pvx = 0; this.pvz = 0;
    this.feetY = 0; this.vy = 0; this.grounded = true; this.crouchK = 0; this.landDip = 0;
    this.coyote = 0; this.jumpBuf = 0; this.touchCrouch = false;
    this.knifeT = 0; this.knifeCd = 0; this.knifeDidHit = false;
    this.rmbHeld = false; this.rmbDownT = 0; this.rmbFiredKnife = false;
    this.knifeRig.visible = false;
    this.yaw = 0; this.pitch = 0;
    this.hp = this.maxHp = 150; this.lastDmg = -99;
    this.weapons = [{ defId: "m1911", mag: 8, reserve: 96 }];
    this.cur = 0; this.fireCd = 0; this.reloadT = 0; this.reloading = false;
    this.points = 500; this.earned = 500; this.kills = 0; this.heads = 0; this.shots = 0; this.hits = 0;
    this.doubleT = 0; this.instaT = 0; this.nukeFlash = 0; this.trauma = 0;
    this.round = 0; this.intermission = 0; this.time = 0; this.dying = 0; this.deadDone = false;
    this.recentHit = 0; this.muzzleT = 0; this.crossKick = 0; this.kickT = 0;
    this.ads = false; this.adsK = 0;
    this.hitA = 0;
    this.level = 1; this.xp = 0; this.xpNeed = xpNeedForLevel(1);
    this.abilityLevels = {}; this.pendingLevels = 0; this.currentChoices = null;
    this.bladeAngle = 0; this.novaT = 0; this.thunderT = 0;
    // salas / janelas / portas / sistemas resetam
    this.zonesOpen = { start: true };
    for (const z of this.mapDef.zones) if (!(z.id in this.zonesOpen)) this.zonesOpen[z.id] = false;
    this.repairCd = 0;
    this.powerOn = false; this.partsFound = 0; this.relaysDone = 0; this.attractT = 0;
    this.perkVigor = 0; this.perkSwift = 0;
    this.voiceStreak = 0; this.voiceStreakT = 0;
    for (const w of this.windows) {
      w.planks = w.maxPlanks; w.hitT = 0; w.rebuildCd = 0;
      w.plankMeshes.forEach((p, i) => {
        p.mesh.visible = true;
        p.mesh.position.y = p.full;
        p.mesh.rotation.z = (i % 2 ? -1 : 1) * 0.03;
      });
    }
    for (const d of this.doors) {
      d.opened = false; d.opening = 0;
      const l = d.panelL as unknown as THREE.Group;
      const r = d.panelR as unknown as THREE.Group;
      l.position.x = -d.w / 4; r.position.x = d.w / 4;
      l.visible = true; r.visible = true;
      d.panel.visible = true;
      d.signMat.color.set(0xffd94f);
      d.tag.visible = true;
      d.light.color.set(0xffd94f);
      const c = this.colliders[d.colliderIdx];
      if (c) {
        const alongX = Math.abs(Math.sin(d.rotY)) < 0.5;
        if (alongX) { c.x1 = d.x - d.w / 2; c.z1 = d.z - 0.5; c.x2 = d.x + d.w / 2; c.z2 = d.z + 0.5; }
        else { c.x1 = d.x - 0.5; c.z1 = d.z - d.w / 2; c.x2 = d.x + 0.5; c.z2 = d.z + d.w / 2; }
      }
    }
    for (const s of this.switches) {
      s.done = false;
      s.light.color.set(s.kind === "power" ? 0xffd94f : 0xb46aff);
      s.tag.visible = true;
    }
    for (const p of this.perkMachines) { p.buys = 0; p.tag.visible = true; }
    for (const p of this.partPickups) { p.taken = false; p.mesh.visible = true; }
    for (const d of this.detectors) d.cd = 0;
    this.rebuildGun();
    this.nextRound(true);
    // abertura clássica: 2 zumbis nas janelas do spawn
    const starters = this.windows.filter((w) => w.zone === "start" && !w.vent).slice(0, 2);
    if (starters.length === 2) {
      this.spawnZombie(undefined, undefined, starters[0]);
      this.spawnZombie(undefined, undefined, starters[1]);
    } else {
      this.spawnZombie(this.px + 6, this.pz - 8);
      this.spawnZombie(this.px - 6, this.pz - 6);
    }
    this.queue = Math.max(0, this.queue - 2);
  }

  /* ============================== ACTIONS ============================== */
  private curDef(): WeaponDef { return WEAPONS[this.weapons[this.cur].defId]; }

  reloadWeapon() {
    if (this.dying > 0 || this.paused || this.currentChoices) return;
    const w = this.weapons[this.cur];
    const def = WEAPONS[w.defId];
    if (this.reloading || w.mag >= def.magSize || w.reserve <= 0) return;
    this.reloading = true; this.reloadT = def.reloadTime;
    this.ads = false;
    sound.reload();
  }
  cycleWeapon() {
    if (this.weapons.length < 2 || this.reloading || this.currentChoices) return;
    this.cur = (this.cur + 1) % this.weapons.length;
    this.reloading = false; this.fireCd = Math.max(this.fireCd, 0.18);
    this.ads = false;
    this.rebuildGun();
    sound.wave();
  }
  selectWeapon(i: number) {
    if (i < this.weapons.length && i !== this.cur && !this.reloading) {
      this.cur = i; this.fireCd = Math.max(this.fireCd, 0.18);
      this.ads = false;
      this.rebuildGun(); sound.wave();
    }
  }

  private nearestStation(): Station | null {
    let best: Station | null = null; let bd = 3.6 * 3.6;
    for (const s of this.stations) {
      // loja só vale se a zona dela estiver aberta
      if (!this.zonesOpen[s.zone]) continue;
      const dx = this.px - s.x, dz = this.pz - s.z;
      const dd = dx * dx + dz * dz;
      if (dd < bd) {
        this.tmpDir.set(s.x - this.px, 0, s.z - this.pz).normalize();
        const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
        const dot = this.tmpDir.x * fx + this.tmpDir.z * fz;
        if (dot > 0.3 || dd < 2.4 * 2.4) { bd = dd; best = s; }
      }
    }
    return best;
  }

  private nearestDoor(): GameDoor | null {
    let best: GameDoor | null = null; let bd = 3.4 * 3.4;
    for (const d of this.doors) {
      if (d.opened) continue;
      const dx = this.px - d.x, dz = this.pz - d.z;
      const dd = dx * dx + dz * dz;
      if (dd < bd) { bd = dd; best = d; }
    }
    return best;
  }

  private nearestWindow(): GameWindow | null {
    let best: GameWindow | null = null; let bd = 3.0 * 3.0;
    for (const w of this.windows) {
      if (!this.zonesOpen[w.zone] || w.vent) continue;
      const dx = this.px - w.inX, dz = this.pz - w.inZ;
      const dd = dx * dx + dz * dz;
      if (dd < bd) { bd = dd; best = w; }
    }
    return best;
  }

  private buyDoor(d: GameDoor) {
    if (d.opened) return;
    if (this.round < d.reqRound) {
      sound.deny();
      this.spawnText(d.x, 3.2, d.z, `ROUND ${d.reqRound} NECESSÁRIO`, "#ff5b5b", 1);
      return;
    }
    if (this.points < d.cost) {
      sound.deny();
      this.spawnText(this.px, 1.8, this.pz, `FALTAM ${d.cost - this.points} $`, "#ff5b5b", 1);
      return;
    }
    this.points -= d.cost;
    d.opened = true; d.opening = 0.001;
    sound.doorBuy();
    this.zonesOpen[d.zone] = true;
    // remove o bloqueio
    const c = this.colliders[d.colliderIdx];
    if (c) { c.x1 = 0; c.z1 = 0; c.x2 = 0; c.z2 = 0; }
    d.tag.visible = false;
    d.light.color.set(0x5dff8d);
    this.banner = `${d.label} ABERTA!`;
    this.bannerSub = `NOVAS JANELAS ATIVAS — ${this.zoneLabel(d.zone)}`;
    voice.door(d.label);
    this.bannerT = 2.6;
    this.burst(d.x, 1.5, d.z, 24, "#ffd94f", 5, 0.7);
    this.spawnSmoke(d.x, 1.5, d.z, "#c9bfa5", 1.2, 2.5, 1);
  }

  private repairWindow(w: GameWindow) {
    if (w.planks >= w.maxPlanks || this.repairCd > 0) return;
    this.repairCd = 0.32;
    w.planks++;
    w.rebuildCd = 0.25;
    const pm = w.plankMeshes[w.planks - 1];
    if (pm) {
      pm.mesh.visible = true;
      pm.mesh.position.y = pm.full + 0.5;
      pm.mesh.rotation.z = 0.3;
    }
    sound.rebuild();
    sound.cash();
    this.addPoints(60);
    this.spawnText(w.inX, 2.2, w.inZ, "+60 $ BARREIRA", "#8affc1", 0.85);
    this.burst(w.inX, 1.4, w.inZ, 8, "#c9a24a", 3, 0.5);
  }

  private nearXZ(x: number, z: number, r: number): boolean {
    const dx = this.px - x, dz = this.pz - z;
    return dx * dx + dz * dz < r * r;
  }

  private nearestPower(): SwitchBox | null {
    let best: SwitchBox | null = null; let bd = 3.2 * 3.2;
    for (const s of this.switches) {
      if (s.kind !== "power" || s.done || !this.zonesOpen[s.zone]) continue;
      const dx = this.px - s.x, dz = this.pz - s.z;
      const dd = dx * dx + dz * dz;
      if (dd < bd) { bd = dd; best = s; }
    }
    return best;
  }

  private nearestRelay(): SwitchBox | null {
    let best: SwitchBox | null = null; let bd = 3.2 * 3.2;
    for (const s of this.switches) {
      if (s.kind !== "relay" || s.done || !this.zonesOpen[s.zone]) continue;
      const dx = this.px - s.x, dz = this.pz - s.z;
      const dd = dx * dx + dz * dz;
      if (dd < bd) { bd = dd; best = s; }
    }
    return best;
  }

  private nearestPerk(): PerkMachine | null {
    let best: PerkMachine | null = null; let bd = 3.2 * 3.2;
    for (const p of this.perkMachines) {
      if (!this.zonesOpen[p.zone] || p.buys >= 4) continue;
      const dx = this.px - p.x, dz = this.pz - p.z;
      const dd = dx * dx + dz * dz;
      if (dd < bd) { bd = dd; best = p; }
    }
    return best;
  }

  private activatePower(s: SwitchBox) {
    s.done = true;
    sound.powerUp();
    const total = this.switches.filter((x) => x.kind === "power").length;
    const done = this.switches.filter((x) => x.kind === "power" && x.done).length;
    this.powerOn = done >= total;
    (s.group.children[2] as THREE.Mesh).visible = false;
    s.light.color.set(0x5dff8d);
    s.tag.visible = false;
    this.burst(s.x, 1.6, s.z, 18, "#ffd94f", 4, 0.6);
    if (this.powerOn) {
      this.banner = "ENERGIA ATIVADA!";
      this.bannerSub = this.mapId === "terminal" ? "GERADORES SINCRONIZADOS — PACK LIBERADO" : "PACK-A-PUNCH E SISTEMAS ONLINE";
      this.bannerT = 2.6;
      voice.power();
    } else {
      this.banner = `GERADOR ${done}/${total} ATIVO`;
      this.bannerSub = "LIGUE TODOS OS GERADORES";
      this.bannerT = 2.2;
      voice.say(`Gerador ${done} de ${total}. Continuem, soldados.`, true);
    }
  }

  private usePack() {
    const p = this.packMachine;
    if (!p || !this.zonesOpen[p.zone]) return;
    if (!this.powerOn) {
      sound.deny();
      this.spawnText(p.x, 2.6, p.z, "SEM ENERGIA — LIGUE OS GERADORES", "#ff5b5b", 1);
      return;
    }
    if (this.points < 3500) {
      sound.deny();
      this.spawnText(this.px, 1.8, this.pz, `FALTAM ${3500 - this.points} $`, "#ff5b5b", 1);
      return;
    }
    const w = this.weapons[this.cur];
    if (w.upgraded) {
      sound.deny();
      this.spawnText(this.px, 1.8, this.pz, "ARMA JÁ MELHORADA ★", "#9adcff", 1);
      return;
    }
    this.points -= 3500;
    w.upgraded = true;
    const def = WEAPONS[w.defId];
    w.mag = def.magSize; w.reserve = def.maxReserve;
    this.reloading = false;
    sound.packPunch();
    voice.pack(def.name);
    this.banner = `${def.name} ★ MELHORADA!`;
    this.bannerSub = "+45% DE DANO · MUNIÇÃO CHEIA";
    this.bannerT = 2.6;
    this.burst(p.x, 1.8, p.z, 30, "#5dff8d", 5, 0.8);
    this.spawnSmoke(p.x, 1.8, p.z, "#5dff8d", 1.2, 2.5, 1);
    this.trauma = Math.min(1, this.trauma + 0.25);
  }

  private buyPerk(p: PerkMachine) {
    const maxed = p.buys >= 4;
    if (maxed) { sound.deny(); return; }
    if (this.points < p.cost) {
      sound.deny();
      this.spawnText(this.px, 1.8, this.pz, `FALTAM ${p.cost - this.points} $`, "#ff5b5b", 1);
      return;
    }
    this.points -= p.cost;
    p.buys++;
    sound.perkBuy();
    voice.perk(p.label);
    if (p.perk === "vigor") {
      this.perkVigor++;
      this.maxHp += 25; this.hp = Math.min(this.maxHp, this.hp + 25);
      this.spawnText(p.x, 2.6, p.z, `VIDA MÁXIMA +25 (${this.perkVigor}/4)`, "#ff5d5d", 1.1);
    } else {
      this.perkSwift++;
      this.spawnText(p.x, 2.6, p.z, `VELOCIDADE +7% (${this.perkSwift}/4)`, "#ffd94f", 1.1);
    }
    this.burst(p.x, 1.6, p.z, 16, p.perk === "vigor" ? "#ff5d5d" : "#ffd94f", 4, 0.6);
  }

  private activateRelay(s: SwitchBox) {
    s.done = true;
    this.relaysDone++;
    sound.relay();
    s.light.color.set(0x7dd7ff);
    this.burst(s.x, 2.4, s.z, 22, "#7dd7ff", 5, 0.7);
    const total = this.switches.filter((x) => x.kind === "relay").length;
    voice.relay(this.relaysDone, total);
    if (this.relaysDone >= total) {
      sound.antenna();
      this.boomLight.position.set(0, 8, -40);
      this.boomLight.color.set(0x7dd7ff);
      this.boomLight.intensity = 140;
      this.nukeFlash = 0.8;
      for (const z of this.zombies) {
        if (!z.dead && z.spawnT <= 0.35 && z.type !== "brute") { z.hp = 0; this.killZombie(z, false, "silent"); }
        else if (!z.dead) { z.hp -= 400; z.flash = 0.15; if (z.hp <= 0) this.killZombie(z, false, "silent"); }
      }
      this.addPoints(2000);
      this.banner = "FREQUÊNCIA AZUL!";
      this.bannerSub = "O CONTROLE DO CEO FOI QUEBRADO · +2000 $";
      this.bannerT = 3;
    } else {
      this.banner = `RETRANSMISSOR ${this.relaysDone}/${total}`;
      this.bannerSub = "A ANTENA ESTÁ MUDANDO DE COR...";
      this.bannerT = 2.2;
    }
  }

  private useWorkbench() {
    const wb = this.workbench;
    if (!wb || !this.zonesOpen[wb.zone]) return;
    if (this.partsFound < 3) {
      sound.deny();
      this.spawnText(wb.x, 2.2, wb.z, `FALTAM ${3 - this.partsFound} PEÇAS DAS CATACUMBAS`, "#ff5b5b", 1);
      return;
    }
    const idx = this.weapons.findIndex((w) => w.defId === "reaper");
    if (idx >= 0) {
      const w = this.weapons[idx];
      w.mag = WEAPONS.reaper.magSize; w.reserve = WEAPONS.reaper.maxReserve;
      sound.packPunch();
      this.spawnText(wb.x, 2.2, wb.z, "CEIFADOR RECARREGADO", "#c77dff", 1.1);
      return;
    }
    const nw: Owned = { defId: "reaper", mag: WEAPONS.reaper.magSize, reserve: WEAPONS.reaper.startReserve };
    if (this.weapons.length < 2) this.weapons.push(nw);
    else this.weapons[this.cur] = nw;
    this.cur = this.weapons.findIndex((w) => w.defId === "reaper");
    this.reloading = false;
    this.rebuildGun();
    sound.packPunch();
    voice.workbench();
    this.banner = "CEIFADOR AETHELGARD!";
    this.bannerSub = "ARMA ESPECIAL MONTADA NAS CATACUMBAS";
    this.bannerT = 2.8;
    this.burst(wb.x, 1.5, wb.z, 26, "#c77dff", 5, 0.8);
  }

  interact() {
    if (this.dying > 0 || this.paused || this.currentChoices) return;
    // prioridade: janela > energia > relé > bancada > pack > perk > porta > loja
    const w = this.nearestWindow();
    if (w && !w.vent && w.planks < w.maxPlanks) {
      const dx = this.px - w.inX, dz = this.pz - w.inZ;
      if (dx * dx + dz * dz < 3.0 * 3.0) { this.repairWindow(w); return; }
    }
    const pw = this.nearestPower();
    if (pw && this.nearXZ(pw.x, pw.z, 3.2)) { this.activatePower(pw); return; }
    const rl = this.nearestRelay();
    if (rl && this.nearXZ(rl.x, rl.z, 3.2)) { this.activateRelay(rl); return; }
    if (this.workbench && this.zonesOpen[this.workbench.zone] && this.nearXZ(this.workbench.x, this.workbench.z, 3.2)) { this.useWorkbench(); return; }
    const pk = this.packMachine;
    if (pk && this.zonesOpen[pk.zone] && this.nearXZ(pk.x, pk.z, 3.2)) { this.usePack(); return; }
    const pm = this.nearestPerk();
    if (pm && this.nearXZ(pm.x, pm.z, 3.2)) { this.buyPerk(pm); return; }
    const d = this.nearestDoor();
    if (d) {
      const dx = this.px - d.x, dz = this.pz - d.z;
      if (dx * dx + dz * dz < 3.4 * 3.4) { this.buyDoor(d); return; }
    }
    const s = this.nearestStation();
    if (!s) {
      // se só há janela cheia por perto, avisa
      if (w) { sound.deny(); this.spawnText(w.inX, 2.2, w.inZ, "BARREIRA INTACTA", "#9adcff", 0.8); }
      return;
    }
    const def = WEAPONS[s.weaponId];
    const ownedIdx = this.weapons.findIndex((ww) => ww.defId === s.weaponId);
    if (ownedIdx >= 0) {
      const ww = this.weapons[ownedIdx];
      if (ww.reserve >= def.maxReserve) { sound.deny(); this.spawnText(this.px, 1.8, this.pz, "MUNIÇÃO CHEIA", "#9adcff", 1); return; }
      if (this.points < def.ammoPrice) { sound.deny(); this.spawnText(this.px, 1.8, this.pz, "DINHEIRO INSUFICIENTE", "#ff5b5b", 1); return; }
      this.points -= def.ammoPrice;
      ww.reserve = def.maxReserve;
      sound.buy(); this.spawnText(s.x, 2.4, s.z, "MUNIÇÃO MÁXIMA", "#9adcff", 1.2);
      this.burst(s.x, 1.5, s.z, 14, "#9adcff", 3, 0.5);
      this.spawnSmoke(s.x, 1.6, s.z, s.color, 0.8, 1.6, 1);
    } else {
      if (this.points < def.price) { sound.deny(); this.spawnText(this.px, 1.8, this.pz, `FALTAM ${def.price - this.points} $`, "#ff5b5b", 1); return; }
      this.points -= def.price;
      const nw: Owned = { defId: s.weaponId, mag: def.magSize, reserve: def.startReserve };
      if (this.weapons.length < 2) this.weapons.push(nw);
      else this.weapons[this.cur] = nw;
      this.cur = this.weapons.findIndex((ww) => ww.defId === s.weaponId);
      this.reloading = false;
      this.rebuildGun();
      sound.buy(); this.spawnText(s.x, 2.4, s.z, def.name.toUpperCase(), def.id === "raygun" ? "#5dff8d" : "#ffd37a", 1.4);
      this.burst(s.x, 1.5, s.z, 22, s.color, 4, 0.6);
      this.spawnSmoke(s.x, 1.6, s.z, s.color, 1, 2, 1.2);
      this.trauma = Math.min(1, this.trauma + 0.15);
    }
  }

  private addPoints(n: number) {
    this.points += n * (this.doubleT > 0 ? 2 : 1);
    this.earned += n * (this.doubleT > 0 ? 2 : 1);
  }

  private spawnText(x: number, y: number, z: number, text: string, color: string, scale = 1) {
    let ft = this.texts.find((t) => t.life <= 0);
    if (!ft) {
      if (this.texts.length >= 22) return;
      const cv = document.createElement("canvas");
      cv.width = 256; cv.height = 96;
      const tex = new THREE.CanvasTexture(cv);
      tex.colorSpace = THREE.SRGBColorSpace;
      const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false }));
      this.scene.add(spr);
      ft = { spr, cv, tex, life: 0, max: 1, vy: 0 };
      this.texts.push(ft);
    }
    const c = ft.cv.getContext("2d")!;
    c.clearRect(0, 0, ft.cv.width, ft.cv.height);
    c.font = "bold 44px monospace"; c.textAlign = "center"; c.textBaseline = "middle";
    c.strokeStyle = "rgba(0,0,0,0.9)"; c.lineWidth = 8;
    c.strokeText(text, 128, 48);
    c.fillStyle = color; c.fillText(text, 128, 48);
    ft.tex.needsUpdate = true;
    ft.spr.position.set(x + rand(-0.3, 0.3), y, z);
    ft.spr.scale.set(2.4 * scale, 0.9 * scale, 1);
    (ft.spr.material as THREE.SpriteMaterial).opacity = 1;
    ft.life = 1; ft.max = 1; ft.vy = 1.1;
  }

  /* ============================== XP ============================== */
  private gainXp(n: number, x: number, y: number, z: number) {
    if (this.dying > 0 || n <= 0) return;
    this.xp += n;
    if (n >= 10) this.spawnText(x, y + 0.6, z, `+${n} XP`, "#8affc1", 0.8);
    while (this.xp >= this.xpNeed) {
      this.xp -= this.xpNeed;
      this.level++;
      this.pendingLevels++;
      this.xpNeed = xpNeedForLevel(this.level);
    }
    if (this.pendingLevels > 0 && !this.currentChoices) this.offerChoices();
  }

  private offerChoices() {
    const choices = rollChoices(this.abilityLevels, 3);
    this.currentChoices = choices;
    this.ads = false;
    sound.levelup();
    voice.mutation();
    this.burst(this.px, 1.4, this.pz, 26, "#8affc1", 5, 0.8);
    this.spawnSmoke(this.px, 1.4, this.pz, "#8affc1", 1.2, 2.4, 1);
    this.banner = `NÍVEL ${this.level}`;
    this.bannerSub = "ESCOLHA SUA MUTAÇÃO";
    this.bannerT = 2.5;
    if (document.pointerLockElement) document.exitPointerLock();
    this.onLevelUp?.(choices);
  }

  chooseUpgrade(id: string) {
    if (!this.currentChoices) return;
    const found = this.currentChoices.find((c) => c.id === id);
    if (!found) return;
    if (found.kind === "ability") {
      const prev = this.abilityLevels[id] ?? 0;
      const lvl = Math.min(3, prev + 1);
      this.abilityLevels[id] = lvl;
      this.afterAbility(id, prev, lvl);
      this.spawnText(this.px, 2.2, this.pz, `${found.name} NV ${lvl}!`, "#ffd94f", 1.2);
      this.burst(this.px, 1.4, this.pz, 20, found.color, 5, 0.7);
    } else {
      this.applySupply(id);
    }
    sound.pickup();
    this.hp = Math.min(this.maxHp, this.hp + 25);
    this.pendingLevels = Math.max(0, this.pendingLevels - 1);
    if (this.pendingLevels > 0) this.offerChoices();
    else {
      this.currentChoices = null;
      this.onLevelUp?.(null);
      this.last = performance.now();
      if (!this.isTouch) this.requestLock();
    }
  }

  private afterAbility(id: string, prev: number, lvl: number) {
    if (id === "regen") {
      const diff = (REGEN_MAX[lvl] ?? 0) - (REGEN_MAX[prev] ?? 0);
      this.maxHp += diff;
      this.hp = Math.min(this.maxHp, this.hp + diff);
    } else if (id === "nova") {
      this.novaT = Math.min(this.novaT || 99, 1.2);
    } else if (id === "thunder") {
      this.thunderT = Math.min(this.thunderT || 99, 1.0);
    }
  }

  private applySupply(id: string) {
    if (id === "supply_points") {
      this.addPoints(750);
      this.spawnText(this.px, 2.2, this.pz, "+750 PTS", "#ffd94f", 1.2);
    } else if (id === "supply_ammo") {
      for (const w of this.weapons) {
        const def = WEAPONS[w.defId];
        w.mag = def.magSize; w.reserve = def.maxReserve;
      }
      this.reloading = false;
      this.spawnText(this.px, 2.2, this.pz, "MUNIÇÃO CHEIA!", "#9adcff", 1.2);
    } else {
      this.hp = this.maxHp;
      this.spawnText(this.px, 2.2, this.pz, "CURA TOTAL!", "#ff7a7a", 1.2);
    }
  }

  /* ============================== COMBAT ============================== */
  private tryFire(dt: number) {
    this.fireCd -= dt;
    const w = this.weapons[this.cur];
    const def = WEAPONS[w.defId];
    const wantFire = this.mouseDown || this.touchFiring;
    if (!wantFire || this.fireCd > 0 || this.reloading || this.dying > 0 || this.deadDone) return;
    if (w.mag <= 0) {
      sound.empty();
      this.fireCd = 0.25;
      this.reloadWeapon();
      return;
    }
    this.fireWeapon(w, def);
  }

  private aimDir(out: THREE.Vector3, spread: number): THREE.Vector3 {
    out.set(0, 0, -1).applyQuaternion(this.camera.quaternion);
    if (spread > 0) {
      out.x += rand(-spread, spread);
      out.y += rand(-spread, spread);
      out.z += rand(-spread, spread) * 0.3;
      out.normalize();
    }
    return out;
  }

  private raySphere(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, cx: number, cy: number, cz: number, r: number): number {
    const lx = cx - ox, ly = cy - oy, lz = cz - oz;
    const t = lx * dx + ly * dy + lz * dz;
    if (t < 0) return -1;
    const d2 = lx * lx + ly * ly + lz * lz - t * t;
    if (d2 > r * r) return -1;
    return t - Math.sqrt(Math.max(0, r * r - d2));
  }

  private fireWeapon(w: Owned, def: WeaponDef) {
    w.mag--; this.shots++;
    const rapidMult = RAPID_MULT[this.abilityLevels["rapid"] ?? 0] ?? 1;
    this.fireCd = def.interval * rapidMult;
    this.muzzleT = 0.06;
    this.kickT = 1;
    this.crossKick = Math.min(1, this.crossKick + def.kick * 3);
    if (this.isTouch) this.touchAimAssist();
    const moving = Math.hypot(this.pvx, this.pvz) > 4;
    let spread = def.spread * (moving ? 1.7 : 1) * (1 - this.adsK * 0.62) * (1 - this.crouchK * 0.35);
    if (this.isTouch) spread *= 0.6;
    const eyeNow = EYE + (CROUCH_EYE - EYE) * this.crouchK + this.feetY;
    const ox = this.px, oy = eyeNow, oz = this.pz;
    const dir = this.aimDir(this.tmpDir, spread).clone();
    this.raycaster.set(new THREE.Vector3(ox, oy, oz), dir);
    this.raycaster.far = def.range;
    const wallHits = this.raycaster.intersectObjects(this.blockerMeshes, false);
    const wallT = wallHits.length ? wallHits[0].distance : def.range;
    const pierce = PIERCE_N[this.abilityLevels["pierce"] ?? 0] ?? 0;
    const assist = this.isTouch ? 0.09 : 0;
    type H = { z: Zombie; t: number; head: boolean };
    const list: H[] = [];
    for (const z of this.zombies) {
      if (z.dead || z.spawnT > 0.35) continue;
      const hx = z.x, hy = z.group.position.y + 1.9 * z.scale, hz = z.z;
      const tx = z.x, ty = z.group.position.y + 1.15 * z.scale, tz = z.z;
      const ht = this.raySphere(ox, oy, oz, dir.x, dir.y, dir.z, hx, hy, hz, 0.26 * z.scale + assist);
      const bt = this.raySphere(ox, oy, oz, dir.x, dir.y, dir.z, tx, ty, tz, 0.58 * z.scale + assist);
      if (ht > 0 && ht < wallT) list.push({ z, t: ht, head: true });
      else if (bt > 0 && bt < wallT) list.push({ z, t: bt, head: false });
    }
    list.sort((a, b) => a.t - b.t);
    const targets = list.slice(0, 1 + pierce);
    const endT = targets.length ? targets[targets.length - 1].t : wallT;
    const ex = ox + dir.x * endT, ey = oy + dir.y * endT, ez = oz + dir.z * endT;

    sound.shoot(def.id);
    this.trauma = Math.min(1, this.trauma + def.kick * (def.id === "raygun" ? 1.5 : 0.65) * (1 - this.adsK * 0.3));
    this.pitch = clamp(this.pitch + def.kick * 0.028 * (1 - this.adsK * 0.35), -1.45, 1.45);
    this.yaw += rand(-1, 1) * def.kick * 0.008;
    // flash
    this.flashSprite.visible = true;
    this.flashSprite.material.rotation = rand(0, TAU);
    this.flashStar.visible = true;
    this.flashStar.rotation.z = rand(0, TAU);
    (this.flashStar.material as THREE.MeshBasicMaterial).color.set(def.id === "raygun" ? 0x9dffb8 : 0xffe9b0);
    this.muzzleLight.color.set(def.id === "raygun" ? 0x7dff9a : 0xffc06a);
    this.muzzleLight.intensity = def.id === "raygun" ? 30 : 16;
    this.muzzleTip.getWorldPosition(this.tmpV1);
    this.spawnTracer(this.tmpV1, this.tmpV2.set(ex, ey, ez), def.tracer, def.id === "raygun" ? 0.055 : 0.028);
    // estojo + fumaça do cano
    this.spawnP(ox + dir.x * 0.5, oy - 0.25, oz + dir.z * 0.5, rand(-1.5, 1.5), rand(1, 2.5), rand(-1.5, 1.5), 0.55, 0.045, "#d8a927", 7, 1);
    if (Math.random() < 0.5) {
      this.muzzleTip.getWorldPosition(this.tmpV1);
      this.spawnSmoke(this.tmpV1.x, this.tmpV1.y, this.tmpV1.z, "#8a8a8a", 0.9, 0.35, 0.7);
    }

    if (targets.length) {
      const dmgMult = DMG_MULT[this.abilityLevels["dmg"] ?? 0] ?? 1;
      const packMult = w.upgraded ? 1.45 : 1;
      const critCh = CRIT_CH[this.abilityLevels["crit"] ?? 0] ?? 0;
      const critMult = CRIT_MULT[this.abilityLevels["crit"] ?? 0] ?? 1;
      const vampHit = VAMP_HIT[this.abilityLevels["vampire"] ?? 0] ?? 0;
      for (const { z, t, head } of targets) {
        const fall = 1 - (t / def.range) * 0.35;
        let dmg = def.damage * (head ? def.headMult : 1) * fall * dmgMult * packMult;
        let crit = false;
        if (critCh > 0 && Math.random() < critCh) { crit = true; dmg *= critMult; }
        if (this.instaT > 0) dmg = 9999;
        z.hp -= dmg; z.flash = 0.09;
        const ka = Math.atan2(z.x - this.px, z.z - this.pz);
        z.x += Math.sin(ka) * (def.id === "raygun" ? 0.35 : 0.12);
        z.z += Math.cos(ka) * (def.id === "raygun" ? 0.35 : 0.12);
        this.hits++;
        this.blood(z.x, z.group.position.y + 1.3 * z.scale, z.z, crit ? 12 : head ? 10 : 6, def.id === "raygun");
        this.addPoints(head || crit ? 15 : 10);
        this.hitA = 0.3; this.hitKill = false; this.hitHead = head || crit;
        if (crit || head) sound.headshot(); else sound.hitmark();
        sound.zombieHit();
        if (vampHit > 0 && this.dying <= 0) this.hp = Math.min(this.maxHp, this.hp + vampHit);
        if (crit) this.spawnText(z.x, z.group.position.y + 2.4 * z.scale, z.z, `CRIT ${Math.round(dmg)}`, "#ffd94f", 0.9);
        else if (head || Math.random() < 0.35) this.spawnText(z.x, z.group.position.y + 2.2 * z.scale, z.z, `${Math.round(dmg)}`, head ? "#ff5d5d" : "#ffe9a8", head ? 0.9 : 0.7);
        if (z.hp <= 0 && !z.dead) this.killZombie(z, head);
      }
      if (def.id === "raygun") {
        const dm = DMG_MULT[this.abilityLevels["dmg"] ?? 0] ?? 1;
        this.explode(ex, ey, ez, def.aoe, def.damage * 0.7 * dm, targets[0].z);
      }
    } else {
      // impacto na parede: faísca + poeira + fumaça + marca de bala + luz
      this.burst(ex, ey, ez, 6, "#ffcf7a", 3.5, 0.3);
      this.burst(ex, ey, ez, 3, "#fff2c9", 5, 0.2);
      this.spawnSmoke(ex, ey, ez, "#6a655c", 0.8, 0.5, 0.5);
      this.impactLight.position.set(ex, ey, ez);
      this.impactLight.color.set(def.id === "raygun" ? 0x7dff9a : 0xffd9a0);
      this.impactLight.intensity = def.id === "raygun" ? 20 : 9;
      if (wallHits.length && endT < def.range - 0.5) {
        const h = wallHits[0];
        const n = h.face?.normal;
        if (n) {
          const wn = n.clone().transformDirection(h.object.matrixWorld);
          this.addHole(h.point.x, h.point.y, h.point.z, wn.x, wn.y, wn.z);
        }
      }
    }
  }

  private spawnTracer(from: THREE.Vector3, to: THREE.Vector3, color: string, thick: number) {
    let tr = this.tracers.find((t) => t.life <= 0);
    if (!tr) {
      if (this.tracers.length >= 22) return;
      const mat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 1, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false });
      const mesh = new THREE.Mesh(this.geoBox, mat);
      this.scene.add(mesh);
      tr = { mesh, mat, life: 0, max: 0.09 };
      this.tracers.push(tr);
    }
    tr.mat.color.set(color);
    const len = from.distanceTo(to);
    tr.mesh.position.copy(from).lerp(to, 0.5);
    tr.mesh.lookAt(to);
    tr.mesh.scale.set(thick, thick, Math.max(0.1, len));
    tr.life = tr.max = 0.09;
    tr.mesh.visible = true;
  }

  private explode(x: number, y: number, z: number, r: number, dmg: number, except: Zombie | null) {
    this.burst(x, y, z, 26, "#5dff8d", 7, 0.6);
    this.burst(x, y, z, 12, "#eaffea", 5, 0.4);
    this.spawnSmoke(x, y + 0.5, z, "#3d5a44", 1.4, 2.4, 1.2);
    this.glowFlash(x, y, z, "#7dff9a", 4, 0.2);
    this.boomLight.position.set(x, y + 1, z);
    this.boomLight.color.set(0x7dff9a);
    this.boomLight.intensity = 70;
    this.trauma = Math.min(1, this.trauma + 0.3);
    for (const zb of this.zombies) {
      if (zb.dead || zb === except || zb.spawnT > 0.35) continue;
      const dx = zb.x - x, dz = zb.z - z;
      const d = Math.hypot(dx, dz);
      if (d < r + zb.radius) {
        zb.hp -= this.instaT > 0 ? 9999 : dmg * (1 - (d / (r + zb.radius)) * 0.6);
        zb.flash = 0.09;
        this.blood(zb.x, zb.group.position.y + 1, zb.z, 8, true);
        if (zb.hp <= 0 && !zb.dead) this.killZombie(zb, false);
      }
    }
    const pd = Math.hypot(this.px - x, this.pz - z);
    if (pd < 2.5 && this.dying <= 0) this.damagePlayer(8, x, z);
  }

  private killZombie(z: Zombie, head: boolean, src: "gun" | "knife" | "ability" | "silent" = "gun") {
    z.dead = true; z.deathT = 0.5; z.deadGone = 3.2;
    this.kills++; if (head) this.heads++;
    this.hitA = 0.35; this.hitKill = true;
    // sargento xingando EM TEMPO REAL a cada abate
    if (src !== "silent" && this.dying <= 0) {
      const now = performance.now() / 1000;
      this.voiceStreak = now - this.voiceStreakT < 3.2 ? this.voiceStreak + 1 : 1;
      this.voiceStreakT = now;
      voice.kill({
        head, knife: src === "knife", brute: z.type === "brute",
        streak: this.voiceStreak, total: this.kills,
      });
    }
    // dinheiro por abate (sistema de economia p/ armas e portas)
    const base = head ? 150 : 100;
    const mult = this.doubleT > 0 ? 2 : 1;
    this.points += base * mult; this.earned += base * mult;
    this.spawnText(z.x, z.group.position.y + 1.7, z.z, `+${base * mult} $`, "#ffe9a8", 0.85);
    if (this.kills % 3 === 0) sound.cash();
    if (head) this.spawnText(z.x, z.group.position.y + 2.5, z.z, "HEADSHOT", "#ff5d5d", 0.9);
    sound.bloodKill();
    this.blood(z.x, z.group.position.y + 1, z.z, 18, true);
    this.addBloodPool(z.x, z.z, z.type === "brute");
    const xpBase = (z.type === "brute" ? 45 : z.type === "runner" ? 15 : 12) + (head ? 4 : 0) + Math.min(this.round, 12);
    const xpGain = Math.round(xpBase * (MAGNET_XP[this.abilityLevels["magnet"] ?? 0] ?? 1));
    this.gainXp(xpGain, z.x, z.group.position.y + 1, z.z);
    const vh = VAMP_KILL[this.abilityLevels["vampire"] ?? 0] ?? 0;
    if (vh > 0 && this.dying <= 0) this.hp = Math.min(this.maxHp, this.hp + vh);
    if (Math.random() < 0.055 && this.drops.length < 4 && this.dying <= 0) {
      const roll = Math.random();
      const type = roll < 0.32 ? "max" : roll < 0.58 ? "insta" : roll < 0.82 ? "double" : "nuke";
      this.makeDrop(z.x, z.z, type as Drop["type"]);
      this.spawnText(z.x, 2.2, z.z, "DROP!", "#7dff9a", 0.9);
    }
  }

  private damagePlayer(n: number, fromX: number, fromZ: number) {
    if (this.dying > 0 || this.deadDone) return;
    this.hp -= n;
    this.lastDmg = this.time;
    this.recentHit = 1;
    this.trauma = Math.min(1, this.trauma + 0.45);
    sound.playerHurt();
    const a = Math.atan2(this.px - fromX, this.pz - fromZ);
    this.pvx += Math.sin(a) * 3.4; this.pvz += Math.cos(a) * 3.4;
    this.burst(this.px, EYE - 0.3, this.pz, 5, "#a31515", 2.5, 0.5);
    if (this.hp / this.maxHp < 0.3 && this.hp > 0 && Math.random() < 0.3) voice.lowHp();
    if (this.hp <= 0) {
      this.hp = 0; this.dying = 1.7;
      this.ads = false;
      sound.gameOver();
      voice.gameOver();
      if (document.pointerLockElement) document.exitPointerLock();
      this.burst(this.px, 1.2, this.pz, 26, "#a31515", 5, 0.9);
    }
  }

  /* ============================== DROPS ============================== */
  private makeDrop(x: number, z: number, type: Drop["type"]) {
    const col = type === "max" ? "#7dff9a" : type === "insta" ? "#ff5d5d" : type === "double" ? "#ffd94f" : "#ff9d2e";
    const g = new THREE.Group();
    g.position.set(x, 1, z);
    const core = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.38),
      new THREE.MeshStandardMaterial({ color: new THREE.Color(col), emissive: new THREE.Color(col), emissiveIntensity: 1.6, roughness: 0.3 })
    );
    g.add(core);
    const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: new THREE.Color(col), transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false }));
    halo.scale.setScalar(2.4);
    g.add(halo);
    const beam = new THREE.Mesh(
      new THREE.CylinderGeometry(0.3, 0.55, 6, 10, 1, true),
      new THREE.MeshBasicMaterial({ color: new THREE.Color(col), transparent: true, opacity: 0.16, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false })
    );
    beam.position.set(x, 3, z);
    this.scene.add(beam);
    const label = this.textSprite(type === "max" ? "MAX" : type === "insta" ? "INSTA" : type === "double" ? "2X" : "NUKE", { color: col, scale: 1.1 });
    label.position.set(x, 2, z);
    this.scene.add(g); this.scene.add(label);
    this.drops.push({ id: this.dropId++, x, z, type, t: 26, mesh: g, label, beam });
  }

  private applyDrop(d: Drop) {
    sound.pickup();
    this.burst(d.x, 1.2, d.z, 22, "#7dff9a", 5, 0.7);
    this.spawnSmoke(d.x, 1.4, d.z, "#7dff9a", 1, 2, 1);
    if (d.type === "max") {
      for (const w of this.weapons) { w.reserve = WEAPONS[w.defId].maxReserve; w.mag = WEAPONS[w.defId].magSize; }
      this.reloading = false;
      this.banner = "MAX AMMO"; this.bannerSub = "MUNIÇÃO RESTAURADA"; this.bannerT = 2;
      voice.maxAmmo();
    } else if (d.type === "insta") {
      this.instaT = 30;
      this.banner = "INSTA-KILL"; this.bannerSub = "UM TIRO, UMA MORTE — 30s"; this.bannerT = 2;
      voice.insta();
    } else if (d.type === "double") {
      this.doubleT = 30;
      this.banner = "DOUBLE POINTS"; this.bannerSub = "PONTOS EM DOBRO — 30s"; this.bannerT = 2;
      voice.say("Pontos em dobro. Façam cada bala valer ouro.", true);
    } else {
      this.nukeFlash = 1.4; this.trauma = 1;
      sound.nuke();
      voice.nuke();
      this.boomLight.position.set(this.px, 4, this.pz);
      this.boomLight.color.set(0xfff2c9);
      this.boomLight.intensity = 140;
      this.burst(this.px, 2, this.pz, 40, "#fff2c9", 9, 1);
      this.spawnSmoke(this.px, 3, this.pz, "#c9bfa5", 2, 5, 1.5);
      for (const z of this.zombies) {
        if (!z.dead && z.spawnT <= 0.35) { z.hp = 0; this.killZombie(z, false, "silent"); }
      }
      this.queue = 0;
      this.banner = "NUKE!"; this.bannerSub = "TUDO MORREU — APROVEITE"; this.bannerT = 2.4;
    }
  }

  private tickSystems(dt: number) {
    this.attractT = Math.max(0, this.attractT - dt);
    // detectores de metal: apitam e atraem a horda
    for (const d of this.detectors) {
      d.cd = Math.max(0, d.cd - dt);
      if (!this.zonesOpen[d.zone] || d.cd > 0 || this.dying > 0) continue;
      if (Math.abs(this.px - d.x) < 1.3 && Math.abs(this.pz - d.z) < 1.6) {
        d.cd = 9; this.attractT = 4;
        sound.detector();
        voice.detector();
        this.spawnText(d.x, 2.9, d.z, "DETECTADO! ELES OUVIRAM", "#ff8a5d", 1);
        this.burst(d.x, 2.2, d.z, 10, "#ff8a5d", 3, 0.5);
        for (const z of this.zombies) if (!z.dead) z.groan = Math.min(z.groan, 0.4);
      }
    }
    // peças da arma especial: encostou, pegou
    for (const p of this.partPickups) {
      if (p.taken || !this.zonesOpen[p.zone]) continue;
      p.mesh.rotation.y += dt * 1.8;
      p.mesh.position.y = 1.0 + Math.sin(this.time * 3 + p.x) * 0.15;
      const dx = this.px - p.x, dz = this.pz - p.z;
      if (dx * dx + dz * dz < 1.7 * 1.7) {
        p.taken = true; p.mesh.visible = false;
        this.partsFound++;
        sound.partPickup();
        this.spawnText(p.x, 2.2, p.z, `PEÇA ${this.partsFound}/3`, "#ffd94f", 1);
        this.burst(p.x, 1.2, p.z, 14, "#ffd94f", 4, 0.6);
        if (this.partsFound >= 3) {
          this.banner = "PEÇAS COMPLETAS!";
          this.bannerSub = "VOLTE À BANCADA DAS CATACUMBAS";
          this.bannerT = 2.6;
        }
      }
    }
  }

  /* ============================== ABILITIES TICK ============================== */
  private tickAbilities(dt: number) {
    const dmgMult = DMG_MULT[this.abilityLevels["dmg"] ?? 0] ?? 1;
    const rr = REGEN_RATE[this.abilityLevels["regen"] ?? 0] ?? 0;
    if (rr > 0 && this.hp < this.maxHp && this.dying <= 0) this.hp = Math.min(this.maxHp, this.hp + rr * dt);
    const fl = this.abilityLevels["field"] ?? 0;
    this.fieldGroup.visible = fl > 0 && this.dying <= 0;
    if (fl > 0 && this.dying <= 0) {
      const fp = fieldParams(fl);
      const fr = fp.r / 40;
      // colado no piso, quase parado — sem pulsar na cara
      this.fieldGroup.position.set(this.px, 0.04, this.pz);
      const pulse = 1 + Math.sin(this.time * 1.2) * 0.012;
      this.fieldGroup.scale.setScalar(fr * pulse);
      this.fieldMat.opacity = 0.045;
      (this.fieldWire.material as THREE.MeshBasicMaterial).opacity = 0.22;
      (this.fieldRing.material as THREE.MeshBasicMaterial).opacity = 0.26;
      for (const z of this.zombies) {
        if (z.dead || z.spawnT > 0.35) continue;
        const dx = z.x - this.px, dz = z.z - this.pz;
        const rad = fr + z.radius;
        if (dx * dx + dz * dz < rad * rad) {
          z.slowT = 0.35; z.slowMult = 1 - fp.slow;
          if (this.instaT > 0) { this.killZombie(z, false); continue; }
          z.hp -= fp.dps * dt;
          z.flash = Math.max(z.flash, 0.04);
          if (z.hp <= 0 && !z.dead) this.killZombie(z, false);
        }
      }
      // poeira rara e baixa, sem espiral agressiva
      if (Math.random() < 0.06) {
        const a = rand(0, TAU);
        this.spawnP(this.px + Math.cos(a) * fr * 0.9, 0.12, this.pz + Math.sin(a) * fr * 0.9, 0, 0.25, 0, 0.6, 0.05, "#3f9e63", 0, 0.5);
      }
    }
    const bl = this.abilityLevels["blades"] ?? 0;
    const bp = bl > 0 ? bladeParams(bl) : null;
    const orbitR = bp ? (bp.radius / 40) * 0.8 : 0;
    this.bladeMeshes.forEach((sw, i) => {
      const on = bp !== null && i < bp.count;
      sw.visible = on && this.dying <= 0;
      if (!on) return;
      const a = this.bladeAngle + (i / bp!.count) * TAU;
      // rente ao chão, girando deitadas
      sw.position.set(this.px + Math.cos(a) * orbitR, 0.22, this.pz + Math.sin(a) * orbitR);
      sw.rotation.y = -a;
    });
    if (bp) {
      this.bladeAngle += bp.speed * dt;
      for (let i = 0; i < bp.count; i++) {
        const a = this.bladeAngle + (i / bp.count) * TAU;
        const bx = this.px + Math.cos(a) * orbitR, bz = this.pz + Math.sin(a) * orbitR;
        for (const z of this.zombies) {
          if (z.dead || z.spawnT > 0.35 || z.bladeCd > 0) continue;
          const dx = z.x - bx, dz = z.z - bz;
          const rad = 0.6 + z.radius;
          if (dx * dx + dz * dz < rad * rad) {
            z.hp -= this.instaT > 0 ? 9999 : bp.dmg * dmgMult;
            z.flash = 0.09; z.bladeCd = 0.4;
            this.blood(z.x, z.group.position.y + 1, z.z, 8, false);
            this.addPoints(10); this.hits++;
            sound.zombieHit();
            if (z.hp <= 0 && !z.dead) this.killZombie(z, false);
          }
        }
      }
    }
    const nl = this.abilityLevels["nova"] ?? 0;
    if (nl > 0) {
      this.novaT -= dt;
      if (this.novaT <= 0) {
        const np = novaParams(nl);
        this.novaT = np.cd;
        this.novaBlast(this.px, this.pz, np.r / 40, np.dmg * dmgMult);
      }
    }
    const tl = this.abilityLevels["thunder"] ?? 0;
    if (tl > 0) {
      this.thunderT -= dt;
      if (this.thunderT <= 0) {
        const tp = thunderParams(tl);
        this.thunderT = tp.cd;
        const cands = this.zombies.filter((z) => !z.dead && z.spawnT <= 0.35 && (z.x - this.px) ** 2 + (z.z - this.pz) ** 2 < 26 * 26);
        for (let i = cands.length - 1; i > 0; i--) {
          const j = (Math.random() * (i + 1)) | 0;
          [cands[i], cands[j]] = [cands[j], cands[i]];
        }
        cands.slice(0, tp.strikes).forEach((z) => this.lightningStrike(z, tp.dmg * dmgMult));
      }
    }
  }

  private novaBlast(x: number, z: number, r: number, dmg: number) {
    sound.nova();
    this.trauma = Math.min(1, this.trauma + 0.3);
    this.novaMesh.position.set(x, 1.2, z);
    this.novaMesh.scale.setScalar(0.2);
    this.novaAnim = 0.45;
    this.novaMesh.visible = true;
    this.novaRing.position.set(x, 0.12, z);
    this.novaRing.scale.setScalar(0.5);
    this.novaRing.visible = true;
    this.boomLight.position.set(x, 2, z);
    this.boomLight.color.set(0x7dd7ff);
    this.boomLight.intensity = 80;
    this.burst(x, 1.2, z, 26, "#7dd7ff", 8, 0.6);
    this.spawnSmoke(x, 1.2, z, "#7dd7ff", 0.9, 2.5, 0.8);
    for (const zb of this.zombies) {
      if (zb.dead || zb.spawnT > 0.35) continue;
      const d = Math.hypot(zb.x - x, zb.z - z);
      if (d < r + zb.radius) {
        zb.hp -= this.instaT > 0 ? 9999 : dmg * (1 - (d / (r + zb.radius)) * 0.5);
        zb.flash = 0.09;
        this.blood(zb.x, zb.group.position.y + 1, zb.z, 8, true);
        if (zb.hp <= 0 && !zb.dead) this.killZombie(zb, false);
      }
    }
  }

  private lightningStrike(z: Zombie, dmg: number) {
    if (z.dead) return;
    sound.thunder();
    this.boltGroup.position.set(z.x + rand(-0.4, 0.4), 13, z.z + rand(-0.4, 0.4));
    this.boltGroup.rotation.y = rand(0, TAU);
    this.boltAnim = 0.2;
    this.boltGroup.visible = true;
    this.boomLight.position.set(z.x, 4, z.z);
    this.boomLight.color.set(0xd8ecff);
    this.boomLight.intensity = 90;
    this.burst(z.x, 1.5, z.z, 16, "#cfe6ff", 6, 0.5);
    this.spawnSmoke(z.x, 1, z.z, "#5a6a7a", 1, 1.6, 1);
    z.hp -= this.instaT > 0 ? 9999 : dmg;
    z.flash = 0.12;
    this.blood(z.x, z.group.position.y + 1, z.z, 10, true);
    this.addPoints(10);
    if (z.hp <= 0 && !z.dead) this.killZombie(z, false);
    else this.spawnText(z.x, z.group.position.y + 2.2, z.z, `${Math.round(dmg)}`, "#d8ecff", 0.8);
    this.trauma = Math.min(1, this.trauma + 0.18);
  }

  /* ============================== UPDATE ============================== */
  private isSprinting() {
    if (this.crouchK > 0.4 || !this.grounded) return false;
    if (this.adsK > 0.4) return false;
    const tm = Math.hypot(this.touchMove.x, this.touchMove.y);
    if (tm > 0.92 && this.touchMove.y < -0.3) return true;
    // SHIFT + frente = correr (SHIFT parado = agachar, ver wantCrouch)
    return this.keys.has("shift") && (this.keys.has("w") || this.keys.has("arrowup") || tm > 0.1);
  }

  private collide(x: number, z: number, r: number): [number, number] {
    for (const c of this.colliders) {
      const cx = clamp(x, c.x1, c.x2), cz = clamp(z, c.z1, c.z2);
      let dx = x - cx, dz = z - cz;
      const d2 = dx * dx + dz * dz;
      if (d2 < r * r) {
        if (d2 < 1e-6) {
          const l = x - c.x1, rr = c.x2 - x, t = z - c.z1, b = c.z2 - z;
          const m = Math.min(l, rr, t, b);
          if (m === l) x = c.x1 - r; else if (m === rr) x = c.x2 + r;
          else if (m === t) z = c.z1 - r; else z = c.z2 + r;
        } else {
          const dd = Math.sqrt(d2), push = r - dd;
          dx /= dd; dz /= dd;
          x += dx * push; z += dz * push;
        }
      }
    }
    x = clamp(x, -MAP_W / 2 + 1, MAP_W / 2 - 1);
    z = clamp(z, -MAP_H / 2 + 1, MAP_H / 2 - 1);
    return [x, z];
  }

  private loop = (now: number) => {
    if (this.destroyed || !this.running) return;
    if (this.paused) { this.raf = requestAnimationFrame(this.loop); this.last = now; return; }
    let dt = (now - this.last) / 1000;
    this.last = now;
    if (dt > 0.05) dt = 0.05;
    if (dt <= 0) { this.raf = requestAnimationFrame(this.loop); return; }
    this.fpsAcc += 1 / Math.max(dt, 1e-4); this.fpsN++;
    if (now - this.fpsT > 500) { this.fps = Math.round(this.fpsAcc / Math.max(1, this.fpsN)); this.fpsAcc = 0; this.fpsN = 0; this.fpsT = now; }
    const scale = this.dying > 0 ? 0.35 : 1;
    this.update(dt * scale, dt);
    if (this.composer) this.composer.render();
    else this.renderer.render(this.scene, this.camera);
    this.raf = requestAnimationFrame(this.loop);
  };

  private update(dt: number, rawDt: number) {
    if (this.deadDone) {
      this.updateParticles(rawDt);
      this.updateTexts(rawDt);
      this.updateTracers(rawDt);
      this.animateAmbient(rawDt);
      return;
    }
    if (this.currentChoices) {
      this.updateParticles(rawDt);
      this.updateTexts(rawDt);
      this.camera.position.set(this.px, EYE + Math.sin(this.clockT * 1.4) * 0.02, this.pz);
      this.camera.rotation.set(this.pitch, this.yaw, 0, "YXZ");
      this.clockT += rawDt;
      this.animateAmbient(rawDt);
      return;
    }
    this.time += dt; this.clockT += rawDt;
    if (this.bannerT > 0) this.bannerT -= rawDt;
    if (this.recentHit > 0) this.recentHit -= rawDt * 2;
    if (this.nukeFlash > 0) this.nukeFlash -= rawDt * 1.2;
    if (this.doubleT > 0) this.doubleT -= dt;
    if (this.instaT > 0) this.instaT -= dt;
    if (this.hitA > 0) this.hitA -= rawDt;
    this.trauma = Math.max(0, this.trauma - rawDt * 1.6);
    this.muzzleT = Math.max(0, this.muzzleT - dt);
    this.kickT = Math.max(0, this.kickT - rawDt * 7);
    this.muzzleLight.intensity = Math.max(0, this.muzzleLight.intensity - rawDt * 300);
    this.boomLight.intensity = Math.max(0, this.boomLight.intensity - rawDt * 260);
    this.flashSprite.visible = this.muzzleT > 0;
    this.flashStar.visible = this.muzzleT > 0;
    if (this.flashStar.visible) this.flashStar.rotation.z += rawDt * 30;
    this.crossKick = Math.max(0, this.crossKick - rawDt * 3);
    this.swayX += (0 - this.swayX) * Math.min(1, 8 * rawDt);
    this.swayY += (0 - this.swayY) * Math.min(1, 8 * rawDt);
    // ADS
    this.adsK += ((this.ads && !this.reloading ? 1 : 0) - this.adsK) * Math.min(1, 11 * rawDt);
    if (Math.abs(this.adsK) < 0.001) this.adsK = this.ads && !this.reloading ? this.adsK : 0;
    this.novaAnim = Math.max(0, this.novaAnim - rawDt);
    if (this.novaAnim <= 0) { this.novaMesh.visible = false; this.novaRing.visible = false; }
    else {
      const k = 1 - this.novaAnim / 0.45;
      this.novaMesh.scale.setScalar(0.2 + k * 9);
      this.novaMat.opacity = 0.5 * (1 - k);
      this.novaRing.scale.setScalar(0.5 + k * 8);
      this.novaRingMat.opacity = 0.7 * (1 - k);
    }
    this.boltAnim = Math.max(0, this.boltAnim - rawDt);
    if (this.boltAnim <= 0) this.boltGroup.visible = false;
    else {
      const k = this.boltAnim / 0.2;
      this.boltGroup.children.forEach((ch) => {
        const m = (ch as THREE.Mesh).material as THREE.MeshBasicMaterial | THREE.SpriteMaterial;
        if ("opacity" in m) m.opacity = k;
      });
    }

    const gp = 0.32 + (Math.sin(this.time * 3) * 0.5 + 0.5) * 0.3;
    for (const gm of this.gateMats) gm.opacity = gp;

    if (this.dying > 0) {
      this.dying -= rawDt;
      const k = 1 - Math.max(0, this.dying) / 1.7;
      this.camera.position.set(this.px, EYE * (1 - k * 0.75), this.pz);
      this.camera.rotation.set(this.pitch + k * 0.25, this.yaw, k * 0.5, "YXZ");
      this.updateParticles(dt);
      this.updateTexts(rawDt);
      this.updateTracers(rawDt);
      this.animateAmbient(rawDt);
      if (this.dying <= 0 && !this.deadDone) {
        this.deadDone = true;
        this.onGameOver({ score: this.earned + this.round * 250, points: this.points, round: this.round, kills: this.kills, headshots: this.heads, shots: this.shots, hits: this.hits, time: this.time, level: this.level });
      }
      return;
    }

    /* movimento + agachar (SHIFT/C/CTRL) + pulo (ESPAÇO) */
    let mx = 0, my = 0;
    if (this.keys.has("w") || this.keys.has("arrowup")) my -= 1;
    if (this.keys.has("s") || this.keys.has("arrowdown")) my += 1;
    if (this.keys.has("a") || this.keys.has("arrowleft")) mx -= 1;
    if (this.keys.has("d") || this.keys.has("arrowright")) mx += 1;
    mx += this.touchMove.x; my += this.touchMove.y;
    const ml = Math.hypot(mx, my);
    if (ml > 1) { mx /= ml; my /= ml; }
    const crouchWant = this.wantCrouch(mx, my) && this.grounded;
    this.crouchK += ((crouchWant ? 1 : 0) - this.crouchK) * Math.min(1, 10 * rawDt);
    if (Math.abs(this.crouchK) < 0.01) this.crouchK = crouchWant ? Math.max(this.crouchK, 0.01) : 0;
    const sprint = this.isSprinting() && my < 0.2 && this.crouchK < 0.4;
    const bootsMult = BOOTS_MULT[this.abilityLevels["boots"] ?? 0] ?? 1;
    const swiftMult = 1 + this.perkSwift * 0.07;
    const speed = ((sprint ? 7.8 : 5.3) * bootsMult * swiftMult) * (1 - this.adsK * 0.45) * (1 - this.crouchK * 0.52) * (this.grounded ? 1 : 0.72);
    const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
    const rx = Math.cos(this.yaw), rz = -Math.sin(this.yaw);
    const dvx = (rx * mx + fx * -my) * speed;
    const dvz = (rz * mx + fz * -my) * speed;
    const acc = this.grounded ? 11 : 3.2;
    this.pvx += (dvx - this.pvx) * Math.min(1, acc * dt);
    this.pvz += (dvz - this.pvz) * Math.min(1, acc * dt);
    let nx = this.px + this.pvx * dt, nz = this.pz + this.pvz * dt;
    [nx, nz] = this.collide(nx, nz, 0.5);
    this.px = nx; this.pz = nz;
    // pulo com buffer + coyote
    this.jumpBuf = Math.max(0, this.jumpBuf - dt);
    this.coyote = this.grounded ? 0.12 : Math.max(0, this.coyote - dt);
    if (this.jumpBuf > 0 && (this.grounded || this.coyote > 0) && this.dying <= 0) {
      this.vy = 5.4 * (1 - this.crouchK * 0.25);
      this.grounded = false; this.coyote = 0; this.jumpBuf = 0;
      this.touchCrouch = false;
      sound.jump();
      this.bobPhase += 0.6;
    }
    if (!this.grounded) {
      this.vy -= 13.5 * dt;
      this.feetY += this.vy * dt;
      if (this.feetY <= 0) {
        this.feetY = 0; this.grounded = true;
        const hard = this.vy < -7;
        this.vy = 0;
        this.landDip = hard ? 1 : 0.45;
        sound.land();
        this.trauma = Math.min(1, this.trauma + (hard ? 0.22 : 0.08));
        this.burst(this.px, 0.15, this.pz, hard ? 12 : 6, "#6a655c", 2.5, 0.5);
        this.spawnSmoke(this.px, 0.2, this.pz, "#6a655c", 0.7, hard ? 1.2 : 0.7, 0.6);
      }
    }
    this.landDip = Math.max(0, this.landDip - rawDt * 3.2);
    const spd = Math.hypot(this.pvx, this.pvz);
    if (spd > 1.2 && this.grounded) {
      this.bobPhase += dt * (4 + spd * 1.1) * (1 - this.adsK * 0.5) * (1 - this.crouchK * 0.35);
      this.stepT -= dt * spd;
      if (this.stepT <= 0) {
        this.stepT = this.crouchK > 0.4 ? 4.4 : 3.4;
        sound.step(sprint);
        if (sprint && Math.random() < 0.5) this.spawnSmoke(this.px, 0.15, this.pz, "#5a5a52", 0.6, 0.5, 0.4);
      }
    }
    // botão direito: segurar >0.24s vira ADS (toque rápido = facada, tratado no mouseUp)
    if (this.rmbHeld) {
      this.rmbDownT += rawDt;
      if (this.rmbDownT > 0.24 && !this.rmbFiredKnife) this.ads = true;
    }
    this.fovKick += ((sprint && spd > 4 ? 1 : 0) - this.fovKick) * Math.min(1, 6 * rawDt);
    const fov = (75 + this.fovKick * 7 + this.crossKick * 1.5 - this.crouchK * 3) * (1 - this.adsK * 0.27);
    if (Math.abs(this.camera.fov - fov) > 0.1) { this.camera.fov = fov; this.camera.updateProjectionMatrix(); }

    /* arma: reload / sway / bob / coice — esconde durante a facada */
    this.updateKnife(dt);
    const knifing = this.knifeT > 0;
    this.gunRoot.visible = !knifing;
    if (this.reloading) {
      this.reloadT -= dt;
      const k = 1 - Math.max(0, this.reloadT) / this.curDef().reloadTime;
      const dip = Math.sin(k * Math.PI);
      this.gunRoot.position.set(0.28, -0.27 - dip * 0.2 - this.crouchK * 0.04, -0.55 + dip * 0.1);
      this.gunRoot.rotation.set(dip * 0.8, 0, dip * 0.25);
      if (this.reloadT <= 0) {
        const w = this.weapons[this.cur];
        const def = WEAPONS[w.defId];
        const take = Math.min(def.magSize - w.mag, w.reserve);
        w.mag += take; w.reserve -= take;
        this.reloading = false;
        this.gunRoot.rotation.set(0, 0, 0);
      }
    } else if (!knifing) {
      const sway = clamp(spd / 7, 0, 1) * (1 - this.adsK * 0.7);
      const hx = 0.28 * (1 - this.adsK) + this.swayX;
      const hy = -0.27 + this.adsK * 0.085 + Math.abs(Math.sin(this.bobPhase * 0.5)) * 0.014 * sway + this.swayY - this.crossKick * 0.015 - this.crouchK * 0.04;
      const hz = -0.55 + this.adsK * 0.15 + this.kickT * 0.09;
      this.gunRoot.position.set(hx, hy, hz);
      this.gunRoot.rotation.set(this.kickT * 0.14 + dipSafe(this.reloading), this.swayX * 2, 0);
    }
    if (!knifing) this.tryFire(dt);

    if (this.time - this.lastDmg > 4.5 && this.hp < this.maxHp) this.hp = Math.min(this.maxHp, this.hp + 26 * dt);

    /* rounds */
    const alive = this.zombies.filter((z) => !z.dead).length;
    if (this.intermission > 0) {
      this.intermission -= rawDt;
      if (this.intermission <= 0) this.nextRound();
    } else {
      const cap = this.isTouch ? 12 : 18;
      if (this.queue > 0) {
        this.spawnT -= dt;
        if (this.spawnT <= 0 && alive < cap) {
          this.spawnZombie(); this.queue--; this.spawnT = this.spawnInterval;
        }
      } else if (alive === 0) {
        const bonus = 100 + this.round * 25;
        this.points += bonus; this.earned += bonus;
        this.spawnText(this.px, 2.2, this.pz, `ROUND CLEAR +${bonus}`, "#7dff9a", 1);
        sound.pickup();
        voice.roundClear(bonus);
        this.intermission = 5;
        this.banner = `ROUND ${this.round} CLEAR`;
        this.bannerSub = `BÔNUS +${bonus} $ — PRÓXIMO ROUND EM 5s`;
        this.bannerT = 3;
      }
    }

    /* zumbis */
    for (const z of this.zombies) {
      if (z.dead) {
        z.deathT -= dt; z.deadGone -= dt;
        const k = clamp(1 - z.deathT / 0.5, 0, 1);
        z.group.rotation.x = -k * Math.PI * 0.5;
        if (z.deadGone < 1) z.group.position.y -= dt * 0.8;
        continue;
      }
      if (z.spawnT > 0) {
        z.spawnT -= dt;
        const p = 1 - Math.max(0, z.spawnT) / 1.1;
        if (z.dropFromSky) {
          // cai do duto com aceleração + poeira no impacto
          z.group.position.y = 4.6 * (1 - p) * (1 - p);
          if (z.spawnT <= 0) {
            z.group.position.y = 0;
            this.burst(z.x, 0.3, z.z, 8, "#3a4048", 2.5, 0.5);
            this.spawnSmoke(z.x, 0.5, z.z, "#4a5058", 0.7, 1.2, 0.6);
            sound.land();
          }
        } else {
          z.group.position.y = -1.9 * (1 - p);
        }
        continue;
      }
      z.flash = Math.max(0, z.flash - dt);
      z.bladeCd = Math.max(0, z.bladeCd - dt);
      z.slowT = Math.max(0, z.slowT - dt);
      z.atk -= dt; z.lunge = Math.max(0, z.lunge - dt * 3);
      z.wob += dt * (z.type === "runner" ? 9 : 5.5);
      z.groan -= dt;
      if (z.groan <= 0) { z.groan = rand(4, 11); sound.groan(); }
      // flash de dano: emissive branco
      const fl = z.flash > 0 ? Math.min(1, z.flash * 9) : 0;
      for (const m of z.mats) {
        m.emissive.setRGB(fl * 0.9, fl * 0.85, fl * 0.8);
        m.emissiveIntensity = fl;
      }
      z.eyeGlow.material.opacity = z.slowT > 0 ? 0.35 : 0.75;
      // ---- comportamento de janela ----
      const win = z.winId >= 0 ? this.windowById(z.winId) : undefined;
      let moveTX = this.px, moveTZ = this.pz, atWindow = false;
      if (win && (z.state === "towin" || z.state === "barrier" || z.state === "enter")) {
        const dxw = win.outX - z.x, dzw = win.outZ - z.z;
        const dw = Math.hypot(dxw, dzw);
        if (z.state === "towin") {
          moveTX = win.outX; moveTZ = win.outZ;
          if (dw < 1.2) {
            z.state = win.planks > 0 ? "barrier" : "enter";
            z.barAtk = 0;
          }
        } else if (z.state === "barrier") {
          atWindow = true;
          moveTX = z.x; moveTZ = z.z;
          // encara a janela
          z.group.rotation.y = Math.atan2(win.inX - z.x, win.inZ - z.z);
          z.barAtk -= dt;
          // animação de soco
          const punch = Math.sin(this.time * 9 + z.wob) * 0.5;
          z.armL.rotation.x = -1.1 + punch; z.armR.rotation.x = -1.1 - punch;
          z.legL.rotation.x = 0; z.legR.rotation.x = 0;
          if (z.barAtk <= 0) {
            const breakEvery = Math.max(0.45, 0.95 - this.round * 0.03);
            z.barAtk = breakEvery;
            z.lunge = 1;
            if (win.planks > 0) {
              win.hitT = 0.3;
              sound.barrierHit();
              this.burst(win.inX, 1.5, win.inZ, 4, "#7a5c38", 2.5, 0.4);
              // cada 2 socos quebra 1 tábua
              (z as unknown as { hits: number }).hits = (((z as unknown as { hits: number }).hits ?? 0) + 1);
              if (((z as unknown as { hits: number }).hits ?? 0) % 2 === 0) {
                this.breakPlank(win);
                if (win.planks <= 0) { z.state = "enter"; }
              }
            } else {
              z.state = "enter";
            }
          }
        } else if (z.state === "enter") {
          moveTX = win.inX; moveTZ = win.inZ;
          const dxe = win.inX - z.x, dze = win.inZ - z.z;
          if (Math.hypot(dxe, dze) < 0.7) {
            z.state = "chase"; z.winId = -1;
            z.group.position.y = 0;
          }
        }
      } else if (z.state !== "chase") {
        z.state = "chase"; z.winId = -1;
      }
      const dx = moveTX - z.x, dz = moveTZ - z.z;
      const d = Math.hypot(dx, dz) || 1;
      const slowK = z.slowT > 0 ? z.slowMult : 1;
      const rageK = this.attractT > 0 ? 1.35 : 1;
      const spd2 = z.speed * clamp(d / 4, 0.4, 1) * slowK * rageK * (atWindow ? 0 : 1);
      if (!atWindow) {
        const mvx = (dx / d) * spd2, mvz = (dz / d) * spd2;
        let zx = z.x + mvx * dt, zz = z.z + mvz * dt;
        // fora da janela, zumbi atravessa (não colide com parede externa)
        const inWinTransit = z.state === "towin" || z.state === "enter";
        if (!inWinTransit) [zx, zz] = this.collide(zx, zz, z.radius);
        else {
          zx = clamp(zx, -MAP_W / 2 - 4, MAP_W / 2 + 4);
          zz = clamp(zz, -MAP_H / 2 - 4, MAP_H / 2 + 4);
        }
        z.x = zx; z.z = zz;
        z.group.position.x = zx; z.group.position.z = zz;
      }
      z.group.position.y = (z.state === "enter" ? 0.25 + Math.sin(this.time * 8) * 0.1 : Math.abs(Math.sin(z.wob)) * 0.06);
      if (!atWindow) {
        z.group.rotation.y = Math.atan2(dx, dz);
        z.group.rotation.x = 0;
      }
      const sw = Math.sin(z.wob);
      if (!atWindow) {
        z.legL.rotation.x = sw * 0.65; z.legR.rotation.x = -sw * 0.65;
        z.armL.rotation.x = -1.35 + sw * 0.18 - z.lunge * 0.5;
        z.armR.rotation.x = -1.35 - sw * 0.18 - z.lunge * 0.5;
        z.group.rotation.z = sw * 0.06;
      }
      if (z.slowT > 0) z.group.position.y += 0.02;
      if (atWindow) continue;
      // pulou por cima? escapa do ataque
      if (this.feetY > 0.85) {
        continue;
      }
      const pd = Math.hypot(this.px - z.x, this.pz - z.z);
      if (pd < z.radius + 1.15 && z.atk <= 0 && z.state === "chase") {
        z.atk = z.type === "brute" ? 1.3 : 0.95;
        z.lunge = 1;
        sound.zombieAttack();
        const dmg = z.damage * rand(0.9, 1.15);
        this.damagePlayer(dmg, z.x, z.z);
      }
    }
    const zs = this.zombies;
    for (let i = 0; i < zs.length; i++) {
      const a = zs[i]; if (a.dead || a.spawnT > 0) continue;
      for (let j = i + 1; j < zs.length; j++) {
        const b = zs[j]; if (b.dead || b.spawnT > 0) continue;
        const dx = b.x - a.x, dz = b.z - a.z;
        const rr = a.radius + b.radius - 0.1;
        const d2 = dx * dx + dz * dz;
        if (d2 < rr * rr && d2 > 0.0001) {
          const dd = Math.sqrt(d2), push = ((rr - dd) / dd) * 0.5;
          a.x -= dx * push * 0.4; a.z -= dz * push * 0.4;
          b.x += dx * push * 0.4; b.z += dz * push * 0.4;
          a.group.position.x = a.x; a.group.position.z = a.z;
          b.group.position.x = b.x; b.group.position.z = b.z;
        }
      }
    }
    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];
      if (z.dead && z.deadGone <= 0) {
        this.scene.remove(z.group);
        this.zombies.splice(i, 1);
      }
    }

    /* drops */
    const magnetR = (MAGNET_R[this.abilityLevels["magnet"] ?? 0] ?? 34) / 40;
    for (let i = this.drops.length - 1; i >= 0; i--) {
      const dr2 = this.drops[i];
      dr2.t -= dt;
      dr2.mesh.rotation.y += dt * 2.4;
      dr2.mesh.position.y = 1 + Math.sin(this.time * 3 + dr2.id) * 0.15;
      dr2.label.position.set(dr2.x, 2 + Math.sin(this.time * 3 + dr2.id) * 0.15, dr2.z);
      (dr2.beam.material as THREE.MeshBasicMaterial).opacity = 0.12 + Math.sin(this.time * 4) * 0.05;
      if (dr2.t < 5) dr2.mesh.visible = Math.sin(this.time * 12) > -0.2;
      if (dr2.t <= 0) {
        this.scene.remove(dr2.mesh); this.scene.remove(dr2.label); this.scene.remove(dr2.beam);
        this.drops.splice(i, 1); continue;
      }
      const dx = dr2.x - this.px, dz = dr2.z - this.pz;
      if (dx * dx + dz * dz < magnetR * magnetR) {
        this.scene.remove(dr2.mesh); this.scene.remove(dr2.label); this.scene.remove(dr2.beam);
        this.drops.splice(i, 1);
        this.applyDrop(dr2);
      }
    }

    this.tickSystems(dt);
    this.tickAbilities(dt);
    this.updateWindowsDoors(dt);
    this.updateParticles(dt);
    this.updateTexts(rawDt);
    this.updateTracers(rawDt);
    for (let i = this.decals.length - 1; i >= 0; i--) {
      this.decals[i].life -= dt;
      if (this.decals[i].life <= 0) {
        this.scene.remove(this.decals[i].mesh);
        this.decals.splice(i, 1);
      }
    }
    for (let i = this.holes.length - 1; i >= 0; i--) {
      this.holes[i].life -= dt;
      if (this.holes[i].life <= 0) {
        this.scene.remove(this.holes[i].mesh);
        this.holes.splice(i, 1);
      }
    }

    /* câmera FPS + agachar + pulo + shake + roll da facada */
    const eyeBase = EYE + (CROUCH_EYE - EYE) * this.crouchK;
    const sh = this.trauma * this.trauma;
    const shx = (Math.random() - 0.5) * sh * 0.06;
    const shy = (Math.random() - 0.5) * sh * 0.06;
    const knifeRoll = this.knifeT > 0 ? Math.sin((1 - this.knifeT / 0.42) * Math.PI) * -0.16 : 0;
    const bobY = Math.sin(this.bobPhase * 0.5) * 0.035 * clamp(spd / 5, 0, 1) * (1 - this.adsK * 0.6) * (1 - this.crouchK * 0.4);
    this.camera.position.set(this.px + shx * 2, eyeBase + this.feetY + bobY - this.landDip * 0.16, this.pz);
    this.camera.rotation.set(this.pitch + shy - this.landDip * 0.03, this.yaw + shx, shx * 0.6 + Math.sin(this.bobPhase * 0.25) * 0.003 + knifeRoll, "YXZ");
    this.flash.position.set(0.15, -0.1, 0.1);
    this.flash.target.position.set(this.px - Math.sin(this.yaw) * 7, eyeBase + this.feetY - 0.5 + this.pitch * -7, this.pz - Math.cos(this.yaw) * 7);
    this.flash.angle = 0.6 - this.adsK * 0.12;
    // luzes dinâmicas decaem
    this.impactLight.intensity = Math.max(0, this.impactLight.intensity - rawDt * 60);
    this.knifeLight.intensity = Math.max(this.knifeLight.intensity, this.knifeT > 0 ? this.knifeLight.intensity : 0);
    // grade cinematográfica
    const gp2 = this.gradePass as unknown as { uniforms?: { uTime?: { value: number }; uDamage?: { value: number }; uFlash?: { value: number } } } | null;
    if (gp2?.uniforms) {
      if (gp2.uniforms.uTime) gp2.uniforms.uTime.value = this.clockT;
      if (gp2.uniforms.uDamage) gp2.uniforms.uDamage.value = clamp(this.recentHit * 0.9 + (this.hp / this.maxHp < 0.35 ? 0.3 : 0), 0, 1);
      if (gp2.uniforms.uFlash) gp2.uniforms.uFlash.value = clamp(this.nukeFlash * 0.9 + this.muzzleT * 1.2, 0, 1);
    }
    for (const s of this.stations) {
      (s.ring.material as THREE.MeshBasicMaterial).opacity = 0.4 + (Math.sin(this.time * 4 + s.x) * 0.5 + 0.5) * 0.3;
      s.tag.position.y = 3.5 + Math.sin(this.time * 2 + s.x) * 0.08;
      (s.beam.material as THREE.MeshBasicMaterial).opacity = 0.1 + (Math.sin(this.time * 3 + s.x) * 0.5 + 0.5) * 0.1;
    }
    this.animateAmbient(rawDt);
  }

  private animateAmbient(dt: number) {
    for (const l of this.lamps) {
      l.group.rotation.z = Math.sin(this.clockT * 0.9 + l.phase) * 0.07;
      l.group.rotation.x = Math.cos(this.clockT * 0.7 + l.phase) * 0.05;
      const flick = Math.sin(this.clockT * 13 + l.phase * 3) * 0.5 + Math.sin(this.clockT * 31 + l.phase) * 0.5;
      const drop = flick > 0.92 ? 0.45 : 1;
      l.light.intensity = l.base * drop * (0.92 + Math.sin(this.clockT * 7 + l.phase) * 0.08);
      (l.glow.material as THREE.SpriteMaterial).opacity = 0.7 * drop;
    }
    // projetor tremeluz como cinema antigo
    if (this.projectorBeam) {
      (this.projectorBeam.material as THREE.MeshBasicMaterial).opacity = 0.05 + (Math.sin(this.clockT * 24) * 0.5 + 0.5) * 0.025 + Math.random() * 0.008;
    }
    // alerta vermelho girando em rounds altos ou vida baixa
    const danger = this.round >= 6 || this.hp / this.maxHp < 0.35;
    const target = danger ? 14 + Math.sin(this.clockT * 5) * 10 : 0;
    this.alertLight.intensity += (target - this.alertLight.intensity) * Math.min(1, 3 * dt);
    this.alertLight.position.set(Math.sin(this.clockT * 2.2) * 14, 6, Math.cos(this.clockT * 1.7) * 10);
    // relâmpagos distantes aleatórios
    this.skyFlashT -= dt;
    if (this.skyFlashT <= 0) {
      this.skyFlashT = rand(7, 18);
      this.skyFlashLight.intensity = rand(2, 5);
      setTimeout(() => { this.skyFlashLight.intensity = 0; }, 120);
      setTimeout(() => { this.skyFlashLight.intensity = rand(1, 3); }, 220);
      setTimeout(() => { this.skyFlashLight.intensity = 0; }, 340);
    }
    for (const f of this.fogPlanes) {
      f.mesh.position.x += f.speed * dt;
      if (f.mesh.position.x > MAP_W / 2 + 16) f.mesh.position.x = -MAP_W / 2 - 16;
    }
    const pos = this.dust.geometry.getAttribute("position") as THREE.BufferAttribute;
    const arr = pos.array as Float32Array;
    for (let i = 0; i < this.dustVel.length; i++) {
      arr[i * 3 + 1] -= this.dustVel[i] * dt * 0.4;
      arr[i * 3] += Math.sin(this.clockT * 0.5 + i) * dt * 0.15;
      if (arr[i * 3 + 1] < 0.1) arr[i * 3 + 1] = 7;
    }
    pos.needsUpdate = true;
    // brasas subindo
    if (this.ember) {
      const ep = this.ember.geometry.getAttribute("position") as THREE.BufferAttribute;
      const ea = ep.array as Float32Array;
      const n = this.emberVel.length / 2;
      for (let i = 0; i < n; i++) {
        ea[i * 3 + 1] += this.emberVel[i * 2] * dt;
        ea[i * 3] += Math.sin(this.clockT * 2 + this.emberVel[i * 2 + 1]) * dt * 0.5;
        if (ea[i * 3 + 1] > 6) {
          ea[i * 3 + 1] = 0.4;
          ea[i * 3] += rand(-0.5, 0.5);
        }
      }
      ep.needsUpdate = true;
      (this.ember.material as THREE.PointsMaterial).opacity = 0.65 + Math.sin(this.clockT * 3) * 0.2;
    }
  }

  private touchAimAssist() {
    this.camera.getWorldDirection(this.tmpV1);
    const eyeNow = EYE + (CROUCH_EYE - EYE) * this.crouchK + this.feetY;
    let best: Zombie | null = null; let bestScore = 0.992;
    for (const z of this.zombies) {
      if (z.dead || z.spawnT > 0.35) continue;
      this.tmpV2.set(z.x - this.px, (z.group.position.y + 1.15 * z.scale) - eyeNow, z.z - this.pz);
      const dist = this.tmpV2.length();
      if (dist > 30) continue;
      this.tmpV2.normalize();
      const dot = this.tmpV1.dot(this.tmpV2);
      if (dot > bestScore) { bestScore = dot; best = z; }
    }
    if (best) {
      const eyeNow2 = EYE + (CROUCH_EYE - EYE) * this.crouchK + this.feetY;
      const wantYaw = Math.atan2(-(best.x - this.px), -(best.z - this.pz));
      let dy = wantYaw - this.yaw;
      while (dy > Math.PI) dy -= TAU;
      while (dy < -Math.PI) dy += TAU;
      this.yaw += dy * 0.35;
      const wantPitch = Math.atan2((best.group.position.y + 1.15 * best.scale) - eyeNow2, Math.hypot(best.x - this.px, best.z - this.pz));
      this.pitch += clamp(wantPitch - this.pitch, -0.1, 0.1) * 0.35;
    }
  }

  private updateTexts(dt: number) {
    for (const t of this.texts) {
      if (t.life <= 0) continue;
      t.life -= dt * 0.9;
      if (t.life <= 0) { (t.spr.material as THREE.SpriteMaterial).opacity = 0; continue; }
      t.spr.position.y += t.vy * dt;
      (t.spr.material as THREE.SpriteMaterial).opacity = clamp(t.life * 1.4, 0, 1);
    }
  }

  private updateTracers(dt: number) {
    for (const t of this.tracers) {
      if (t.life <= 0) continue;
      t.life -= dt;
      if (t.life <= 0) { t.mesh.visible = false; continue; }
      t.mat.opacity = t.life / t.max;
    }
  }

  /* ============================== SNAPSHOT ============================== */
  getSnapshot(): HudSnapshot {
    const w = this.weapons[this.cur];
    const def = WEAPONS[w.defId];
    const alive = this.zombies.filter((z) => !z.dead).length;
    let nearBuy: NearBuy | null = null;
    if (this.dying <= 0) {
      // prioridade: janela > energia > relé > bancada > pack > perk > porta > loja
      const win = this.nearestWindow();
      const pw = this.nearestPower();
      const rl = this.nearestRelay();
      const pm = this.nearestPerk();
      const pk = this.packMachine;
      const wb = this.workbench;
      if (win && !win.vent && win.planks < win.maxPlanks) {
        nearBuy = {
          kind: "window", label: `CONSERTAR BARREIRA (${win.planks}/${win.maxPlanks})`,
          price: 0, can: true, hint: "+60 $ por tábua · segure a posição",
        };
      } else if (pw && this.nearXZ(pw.x, pw.z, 3.2)) {
        nearBuy = { kind: "power", label: `LIGAR ${pw.label}`, price: 0, can: true, hint: "Ativa Pack-a-Punch e sistemas" };
      } else if (rl && this.nearXZ(rl.x, rl.z, 3.2)) {
        nearBuy = { kind: "relay", label: `ATIVAR ${rl.label} (${this.relaysDone + 1}/3)`, price: 0, can: true, hint: "Muda a antena p/ azul · detona a horda" };
      } else if (wb && this.zonesOpen[wb.zone] && this.nearXZ(wb.x, wb.z, 3.2)) {
        nearBuy = {
          kind: "workbench", label: this.partsFound >= 3 ? "MONTAR CEIFADOR" : `CEIFADOR (${this.partsFound}/3 PEÇAS)`,
          price: 0, can: this.partsFound >= 3, hint: this.partsFound >= 3 ? "Arma especial das catacumbas" : "Ache as peças nas catacumbas",
        };
      } else if (pk && this.zonesOpen[pk.zone] && this.nearXZ(pk.x, pk.z, 3.2)) {
        const w = this.weapons[this.cur];
        const maxed = !!w.upgraded;
        nearBuy = {
          kind: "pack", label: maxed ? "PACK-A-PUNCH ★ MAX" : "PACK-A-PUNCH ★ MELHORAR ARMA",
          price: 3500, can: !maxed && this.powerOn && this.points >= 3500,
          hint: !this.powerOn ? "SEM ENERGIA — ligue os geradores" : maxed ? "Esta arma já está melhorada" : "+45% dano · munição cheia",
        };
      } else if (pm && this.nearXZ(pm.x, pm.z, 3.2)) {
        const maxed = pm.buys >= 4;
        nearBuy = {
          kind: "perk", label: maxed ? `${pm.label} ★ MAX` : `${pm.label} (${pm.buys}/4)`,
          price: pm.cost, can: !maxed && this.points >= pm.cost,
          hint: pm.perk === "vigor" ? "+25 vida máxima por dose" : "+7% velocidade por dose",
        };
      } else {
        const door = this.nearestDoor();
        if (door) {
          const locked = this.round < door.reqRound;
          nearBuy = {
            kind: "door", label: `ABRIR ${door.label}`,
            price: door.cost, can: !locked && this.points >= door.cost,
            hint: locked ? `Desbloqueia no ROUND ${door.reqRound}` : `Abre ${this.zoneLabel(door.zone)}`,
            lockedReason: locked ? `ROUND ${door.reqRound}` : undefined,
          };
        } else {
          const st = this.nearestStation();
          if (st) {
            const dd = WEAPONS[st.weaponId];
            const owned = this.weapons.some((x) => x.defId === st.weaponId);
            const price = owned ? dd.ammoPrice : dd.price;
            nearBuy = {
              kind: "station", label: owned ? `${dd.name} — MUNIÇÃO` : dd.name,
              price, can: this.points >= price && !(owned && this.weapons.find((x) => x.defId === st.weaponId)?.reserve === dd.maxReserve),
              hint: owned ? "Recarregar estoque" : this.weapons.length >= 2 ? "Troca pela arma atual" : "Nova arma",
            };
          }
        }
      }
    }
    return {
      hp: Math.ceil(this.hp), maxHp: this.maxHp, points: this.points,
      score: this.earned + this.round * 250, round: Math.max(1, this.round),
      zombiesLeft: alive + this.queue,
      alive, kills: this.kills, headshots: this.heads, shots: this.shots, hits: this.hits,
      accuracy: this.shots ? Math.round((this.hits / this.shots) * 100) : 0,
      gameTime: this.time, weaponName: def.name, weaponShort: def.short,
      mag: w.mag, reserve: w.reserve, magSize: def.magSize,
      reloading: this.reloading, reloadPct: this.reloading ? 1 - this.reloadT / def.reloadTime : 0,
      weapons: this.weapons.map((x, i) => ({ short: WEAPONS[x.defId].short, mag: x.mag, reserve: x.reserve, active: i === this.cur })),
      doubleT: Math.max(0, this.doubleT), instaT: Math.max(0, this.instaT),
      banner: this.banner, bannerSub: this.bannerSub, bannerT: Math.max(0, this.bannerT),
      nearBuy, intermission: Math.max(0, this.intermission),
      lowHp: this.hp / this.maxHp < 0.35, recentHit: clamp(this.recentHit, 0, 1),
      nukeFlash: this.nukeFlash, dying: this.dying, fps: this.fps,
      level: this.level, xp: Math.floor(this.xp), xpNeed: this.xpNeed,
      abilities: Object.entries(this.abilityLevels)
        .filter(([, l]) => l > 0)
        .map(([id, l]) => ({ id, name: ABILITIES[id]?.name ?? id, level: l, color: ABILITIES[id]?.color ?? "#fff", icon: ABILITIES[id]?.icon ?? "spark" })),
      hitA: clamp(this.hitA / 0.35, 0, 1), hitKill: this.hitKill, hitHead: this.hitHead,
      locked: this.isLocked(), spread: (10 + this.crossKick * 22) * (1 - this.adsK * 0.55), ads: this.adsK,
      crouched: this.crouchK > 0.5, airborne: !this.grounded, knifing: this.knifeT > 0 ? 1 - this.knifeT / 0.42 : 0,
    };
  }
}

function dipSafe(_reloading: boolean) { return 0; }

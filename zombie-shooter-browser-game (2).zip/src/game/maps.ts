/* ============================================================
   DEAD OPS — Definição dos 3 mapas (level design orientado pelo
   Manual Técnico de Design de Fases e Narrativa Ambiental).
   Coordenadas: x leste+, z sul+ (spawn sempre ao sul, olhando p/ norte).
   Mapa: 120 x 96 (x ±60, z ±48).
   rotY janelas/portas: 0 = parede horizontal | PI/2 = parede vertical.
   Janelas: rotY PI = parede SUL · 0 = NORTE · PI/2 = OESTE · -PI/2 = LESTE.
   ============================================================ */

export type MapId = "subzero" | "terminal" | "fortaleza";

export interface ZoneDef { id: string; label: string; color: string }
export interface WallDef { x: number; z: number; w: number; d: number }
export interface DoorDef {
  id: string; label: string; x: number; z: number; rotY: number; w: number;
  cost: number; reqRound: number; zone: string;
}
export interface WindowDef {
  zone: string; x: number; z: number; rotY: number; vent?: boolean;
}
export interface StationDef {
  w: string; x: number; z: number; ry: number; label: string; color: string; zone: string;
}
export interface PointDef { x: number; z: number; zone: string; label: string }
export interface PerkDef extends PointDef { perk: "vigor" | "swift"; cost: number }
export interface LoreDef {
  lines: string[]; x: number; y: number; z: number; ry: number; w: number; color: string;
}

export interface MapDef {
  id: MapId;
  name: string;
  sub: string;
  desc: string;
  accent: string;
  difficulty: string;
  theme: {
    skyTop: string; skyMid: string; skyBot: string;
    fogColor: number; fogDensity: number;
    hemiSky: number; hemiGround: number;
    moonColor: number; moonIntensity: number;
    floorTint: number;
  };
  spawn: { x: number; z: number };
  zones: ZoneDef[];
  walls: WallDef[];
  doors: DoorDef[];
  windows: WindowDef[];
  stations: StationDef[];
  powerBoxes: PointDef[];
  pack: PointDef;
  perks: PerkDef[];
  detectors?: PointDef[];
  relays?: PointDef[];
  parts?: PointDef[];
  workbench?: PointDef;
  lore: LoreDef[];
}

/* ================= MAPA 1 — SUB-ZERO ================= */
const SUBZERO: MapDef = {
  id: "subzero",
  name: "SUB-ZERO",
  sub: "LABORATÓRIO ANTÁRTICO",
  desc: "Garagem → Descontaminação → Lab Central → Criogenia. Frio, metal e o Projeto Lazarus.",
  accent: "#7dd7ff",
  difficulty: "EQUILIBRADO",
  theme: {
    skyTop: "#02040a", skyMid: "#071120", skyBot: "#0b2030",
    fogColor: 0x0a1420, fogDensity: 0.012,
    hemiSky: 0x9fc0e8, hemiGround: 0x05070a,
    moonColor: 0xb8ccff, moonIntensity: 1.1,
    floorTint: 0xcfd4d6,
  },
  spawn: { x: 0, z: 36 },
  zones: [
    { id: "start", label: "GARAGEM", color: "#ffe9a8" },
    { id: "corr", label: "DESCONTAMINAÇÃO", color: "#b79bff" },
    { id: "lab", label: "LAB CENTRAL", color: "#7dd7ff" },
    { id: "cryo", label: "CRIOGENIA", color: "#8affc1" },
  ],
  walls: [
    { x: -19.85, z: 26, w: 20.3, d: 0.9 },
    { x: 0, z: 26, w: 12.6, d: 0.9 },
    { x: 19.85, z: 26, w: 20.3, d: 0.9 },
    { x: -29.85, z: 14, w: 28.3, d: 0.9 },
    { x: 0, z: 14, w: 24.6, d: 0.9 },
    { x: 29.85, z: 14, w: 28.3, d: 0.9 },
    { x: -30.85, z: -10, w: 42.3, d: 0.9 },
    { x: 0, z: -10, w: 12.6, d: 0.9 },
    { x: 30.85, z: -10, w: 42.3, d: 0.9 },
  ],
  doors: [
    { id: "D1", label: "DESCONTAMINAÇÃO · OESTE", x: -8, z: 26, rotY: 0, w: 3.4, cost: 1000, reqRound: 5, zone: "corr" },
    { id: "D2", label: "DESCONTAMINAÇÃO · LESTE", x: 8, z: 26, rotY: 0, w: 3.4, cost: 1000, reqRound: 5, zone: "corr" },
    { id: "D3", label: "LAB CENTRAL · OESTE", x: -14, z: 14, rotY: 0, w: 3.4, cost: 2000, reqRound: 8, zone: "lab" },
    { id: "D4", label: "LAB CENTRAL · LESTE", x: 14, z: 14, rotY: 0, w: 3.4, cost: 2000, reqRound: 8, zone: "lab" },
    { id: "D5", label: "CRIOGENIA · OESTE", x: -8, z: -10, rotY: 0, w: 3.4, cost: 3000, reqRound: 10, zone: "cryo" },
    { id: "D6", label: "CRIOGENIA · LESTE", x: 8, z: -10, rotY: 0, w: 3.4, cost: 3000, reqRound: 10, zone: "cryo" },
  ],
  windows: [
    { zone: "start", x: -8, z: 48, rotY: Math.PI },
    { zone: "start", x: 0, z: 48, rotY: Math.PI },
    { zone: "start", x: 8, z: 48, rotY: Math.PI },
    { zone: "corr", x: -60, z: 18, rotY: Math.PI / 2 },
    { zone: "corr", x: -60, z: 24, rotY: Math.PI / 2 },
    { zone: "corr", x: 60, z: 18, rotY: -Math.PI / 2 },
    { zone: "corr", x: 60, z: 24, rotY: -Math.PI / 2 },
    { zone: "corr", x: -15, z: 20, rotY: 0, vent: true },
    { zone: "corr", x: 15, z: 20, rotY: 0, vent: true },
    { zone: "lab", x: -60, z: 0, rotY: Math.PI / 2 },
    { zone: "lab", x: -60, z: 8, rotY: Math.PI / 2 },
    { zone: "lab", x: 60, z: 0, rotY: -Math.PI / 2 },
    { zone: "lab", x: 60, z: 8, rotY: -Math.PI / 2 },
    { zone: "cryo", x: -24, z: -48, rotY: 0 },
    { zone: "cryo", x: -8, z: -48, rotY: 0 },
    { zone: "cryo", x: 8, z: -48, rotY: 0 },
    { zone: "cryo", x: 24, z: -48, rotY: 0 },
    { zone: "cryo", x: -60, z: -28, rotY: Math.PI / 2 },
    { zone: "cryo", x: 60, z: -28, rotY: -Math.PI / 2 },
  ],
  stations: [
    { w: "mp5k", x: -13.2, z: 32, ry: Math.PI / 2, label: "MP5K", color: "#57c8ff", zone: "start" },
    { w: "ak47", x: 13.2, z: 32, ry: -Math.PI / 2, label: "AK-47", color: "#ffa14f", zone: "start" },
    { w: "ak47", x: -28, z: 13.2, ry: Math.PI, label: "AK-47", color: "#ffa14f", zone: "lab" },
    { w: "mp5k", x: 28, z: 13.2, ry: Math.PI, label: "MP5K", color: "#57c8ff", zone: "lab" },
    { w: "raygun", x: 15, z: -46.4, ry: Math.PI, label: "RAY GUN", color: "#5dff8d", zone: "cryo" },
  ],
  powerBoxes: [{ x: 0, z: -6, zone: "lab", label: "ENERGIA DO LAB" }],
  pack: { x: 0, z: -42, zone: "cryo", label: "MELHORIA DE ARMAS" },
  perks: [
    { perk: "swift", x: -28, z: 20, zone: "corr", cost: 2000, label: "VELOCIDADE" },
    { perk: "vigor", x: 34, z: -4, zone: "lab", cost: 2000, label: "VIDA EXTRA" },
  ],
  lore: [
    { lines: ["CONFIDENCIAL", "PROJETO LAZARUS"], x: -10, y: 1.6, z: 44, ry: Math.PI, w: 2.2, color: "#ff5b5b" },
    { lines: ["Arthur Vance", "nos condenou"], x: -33.8, y: 2.2, z: 20, ry: Math.PI / 2, w: 3.4, color: "#c9a24a" },
    { lines: ["ERRO: CONTENÇÃO FALHOU", "PACIENTE ZERO EVADIDO"], x: -20, y: 2.6, z: 2, ry: 0, w: 5.5, color: "#b79bff" },
    { lines: ["LOG_PROJETO_LAZARUS_01", "> amostra roxa instável", "> não abra a câmara"], x: 12, y: 2.2, z: -2, ry: Math.PI, w: 5, color: "#7dd7ff" },
    { lines: ["AETHELGARD", "❄ ❄ ❄"], x: 0, y: 0.1, z: -24, ry: 0, w: 8, color: "#3f6a8a" },
    { lines: ["NÃO RESPIRE", "O VAPOR"], x: -40, y: 2.4, z: -30, ry: Math.PI / 2, w: 3.6, color: "#8affc1" },
  ],
};

/* ================= MAPA 2 — TERMINAL 4 ================= */
const TERMINAL: MapDef = {
  id: "terminal",
  name: "TERMINAL 4",
  sub: "AEROPORTO DE EVACUAÇÃO",
  desc: "Check-in → Segurança → Duty-Free → Pista. Caos urbano, fumaça roxa e o avião da Aethelgard.",
  accent: "#ffb066",
  difficulty: "ABERTO · SNIPERS",
  theme: {
    skyTop: "#0a0616", skyMid: "#1c1026", skyBot: "#2e1a2e",
    fogColor: 0x14101c, fogDensity: 0.013,
    hemiSky: 0xb09ac8, hemiGround: 0x0a0705,
    moonColor: 0xd8c8ff, moonIntensity: 0.9,
    floorTint: 0xd8d0c0,
  },
  spawn: { x: 0, z: 38 },
  zones: [
    { id: "start", label: "CHECK-IN", color: "#ffe9a8" },
    { id: "sec", label: "SEGURANÇA", color: "#ff8a5d" },
    { id: "duty", label: "DUTY-FREE", color: "#7dd7ff" },
    { id: "runway", label: "PISTA", color: "#b79bff" },
  ],
  walls: [
    { x: -25.85, z: 24, w: 36.3, d: 0.9 },
    { x: 0, z: 24, w: 8.6, d: 0.9 },
    { x: 25.85, z: 24, w: 36.3, d: 0.9 },
    { x: -14, z: 18, w: 0.9, d: 12 },
    { x: 14, z: 18, w: 0.9, d: 12 },
    { x: -31.85, z: 12, w: 44.3, d: 0.9 },
    { x: 0, z: 12, w: 12.6, d: 0.9 },
    { x: 31.85, z: 12, w: 44.3, d: 0.9 },
    { x: -38.35, z: -12, w: 43.3, d: 0.9 },
    { x: 0, z: -12, w: 26.6, d: 0.9 },
    { x: 38.35, z: -12, w: 43.3, d: 0.9 },
  ],
  doors: [
    { id: "D1", label: "SEGURANÇA · OESTE", x: -6, z: 24, rotY: 0, w: 3.4, cost: 1000, reqRound: 5, zone: "sec" },
    { id: "D2", label: "SEGURANÇA · LESTE", x: 6, z: 24, rotY: 0, w: 3.4, cost: 1000, reqRound: 5, zone: "sec" },
    { id: "D3", label: "DUTY-FREE · OESTE", x: -8, z: 12, rotY: 0, w: 3.4, cost: 2000, reqRound: 8, zone: "duty" },
    { id: "D4", label: "DUTY-FREE · LESTE", x: 8, z: 12, rotY: 0, w: 3.4, cost: 2000, reqRound: 8, zone: "duty" },
    { id: "D5", label: "PISTA · OESTE", x: -15, z: -12, rotY: 0, w: 3.4, cost: 2500, reqRound: 10, zone: "runway" },
    { id: "D6", label: "PISTA · LESTE", x: 15, z: -12, rotY: 0, w: 3.4, cost: 2500, reqRound: 10, zone: "runway" },
  ],
  windows: [
    { zone: "start", x: -12, z: 48, rotY: Math.PI },
    { zone: "start", x: 0, z: 48, rotY: Math.PI },
    { zone: "start", x: 12, z: 48, rotY: Math.PI },
    { zone: "start", x: -60, z: 32, rotY: Math.PI / 2 },
    { zone: "start", x: -60, z: 42, rotY: Math.PI / 2 },
    { zone: "start", x: 60, z: 32, rotY: -Math.PI / 2 },
    { zone: "start", x: 60, z: 42, rotY: -Math.PI / 2 },
    { zone: "sec", x: -6, z: 18, rotY: 0, vent: true },
    { zone: "sec", x: 6, z: 18, rotY: 0, vent: true },
    { zone: "duty", x: -60, z: -6, rotY: Math.PI / 2 },
    { zone: "duty", x: -60, z: 6, rotY: Math.PI / 2 },
    { zone: "duty", x: 60, z: -6, rotY: -Math.PI / 2 },
    { zone: "duty", x: 60, z: 6, rotY: -Math.PI / 2 },
    { zone: "runway", x: -30, z: -48, rotY: 0 },
    { zone: "runway", x: -10, z: -48, rotY: 0 },
    { zone: "runway", x: 10, z: -48, rotY: 0 },
    { zone: "runway", x: 30, z: -48, rotY: 0 },
    { zone: "runway", x: -60, z: -30, rotY: Math.PI / 2 },
    { zone: "runway", x: 60, z: -30, rotY: -Math.PI / 2 },
  ],
  stations: [
    { w: "mp5k", x: -12, z: 46.4, ry: Math.PI, label: "MP5K", color: "#57c8ff", zone: "start" },
    { w: "ak47", x: 12, z: 46.4, ry: Math.PI, label: "AK-47", color: "#ffa14f", zone: "start" },
    { w: "ak47", x: -30, z: 11.2, ry: Math.PI, label: "AK-47", color: "#ffa14f", zone: "duty" },
    { w: "mp5k", x: 30, z: 11.2, ry: Math.PI, label: "MP5K", color: "#57c8ff", zone: "duty" },
    { w: "raygun", x: 14, z: -30, ry: -Math.PI / 2, label: "RAY GUN", color: "#5dff8d", zone: "runway" },
  ],
  powerBoxes: [
    { x: -12, z: -32, zone: "runway", label: "GERADOR A" },
    { x: 12, z: -32, zone: "runway", label: "GERADOR B" },
  ],
  pack: { x: -6, z: -40, zone: "runway", label: "PACK-A-PUNCH" },
  perks: [],
  detectors: [
    { x: -4, z: 18, zone: "sec", label: "DETECTOR OESTE" },
    { x: 4, z: 18, zone: "sec", label: "DETECTOR LESTE" },
  ],
  lore: [
    { lines: ["PARTIDAS · ATRASADO", "TODOS OS VOOS CANCELADOS"], x: 0, y: 4.4, z: 46, ry: Math.PI, w: 9, color: "#7dd7ff" },
    { lines: ["PROTOCOLO DE", "EVACUAÇÃO CIVIL"], x: -20, y: 1.2, z: 40, ry: 0.4, w: 3.4, color: "#c9bfa5" },
    { lines: ["ELES OUVEM", "O APITO..."], x: -13.2, y: 2.4, z: 18, ry: Math.PI / 2, w: 3.6, color: "#ff8a5d" },
    { lines: ["COMUNICADO MILITAR", "PERÍMETRO PERDIDO"], x: 0, y: 2.2, z: 0, ry: Math.PI, w: 5.5, color: "#ffb066" },
    { lines: ["AETHELGARD · MANIFESTO", "CARGA: 12 CAIXAS PB"], x: -6, y: 1.6, z: -36, ry: 0.2, w: 4.5, color: "#b79bff" },
    { lines: ["CAIXA-PRETA VOO 815:", "\"eles estão na pista...\""], x: 18, y: 2.4, z: -38, ry: -Math.PI / 2, w: 5, color: "#ff5b5b" },
  ],
};

/* ================= MAPA 3 — FORTALEZA ================= */
const CASTLE: MapDef = {
  id: "fortaleza",
  name: "FORTALEZA",
  sub: "CASTELO DA CORPORAÇÃO",
  desc: "Pátio → Salão → Catacumbas → Torre. Cyber-gótico, a IA central e o chefe final.",
  accent: "#b79bff",
  difficulty: "DIFÍCIL · CHEFE",
  theme: {
    skyTop: "#05050e", skyMid: "#120e24", skyBot: "#1e1430",
    fogColor: 0x0d0d16, fogDensity: 0.012,
    hemiSky: 0x9a8ac8, hemiGround: 0x080604,
    moonColor: 0xc8b8ff, moonIntensity: 1.0,
    floorTint: 0xc4bcb0,
  },
  spawn: { x: 0, z: 40 },
  zones: [
    { id: "start", label: "PÁTIO", color: "#ffe9a8" },
    { id: "hall", label: "SALÃO", color: "#ffb066" },
    { id: "crypt", label: "CATACUMBAS", color: "#b79bff" },
    { id: "tower", label: "TORRE", color: "#ff5b8a" },
  ],
  walls: [
    { x: -24.85, z: 24, w: 30.3, d: 0.9 },
    { x: 0, z: 24, w: 12.6, d: 0.9 },
    { x: 24.85, z: 24, w: 30.3, d: 0.9 },
    { x: -28.35, z: 0, w: 23.3, d: 0.9 },
    { x: 0, z: 0, w: 26.6, d: 0.9 },
    { x: 28.35, z: 0, w: 23.3, d: 0.9 },
    { x: -20, z: -12, w: 14, d: 0.9 },
    { x: 20, z: -12, w: 14, d: 0.9 },
    { x: 0, z: -6, w: 0.9, d: 12 },
    { x: -15, z: -24, w: 26, d: 0.9 },
    { x: 15, z: -24, w: 26, d: 0.9 },
  ],
  doors: [
    { id: "D1", label: "SALÃO · OESTE", x: -8, z: 24, rotY: 0, w: 3.4, cost: 1000, reqRound: 5, zone: "hall" },
    { id: "D2", label: "SALÃO · LESTE", x: 8, z: 24, rotY: 0, w: 3.4, cost: 1000, reqRound: 5, zone: "hall" },
    { id: "D3", label: "CATACUMBAS · OESTE", x: -15, z: 0, rotY: 0, w: 3.4, cost: 2000, reqRound: 8, zone: "crypt" },
    { id: "D4", label: "CATACUMBAS · LESTE", x: 15, z: 0, rotY: 0, w: 3.4, cost: 2000, reqRound: 8, zone: "crypt" },
    { id: "D5", label: "TORRE · PORTÃO", x: 0, z: -24, rotY: 0, w: 4.2, cost: 3500, reqRound: 12, zone: "tower" },
  ],
  windows: [
    { zone: "start", x: -12, z: 48, rotY: Math.PI },
    { zone: "start", x: 0, z: 48, rotY: Math.PI },
    { zone: "start", x: 12, z: 48, rotY: Math.PI },
    { zone: "start", x: -60, z: 32, rotY: Math.PI / 2 },
    { zone: "start", x: 60, z: 32, rotY: -Math.PI / 2 },
    { zone: "hall", x: -60, z: 8, rotY: Math.PI / 2 },
    { zone: "hall", x: -60, z: 16, rotY: Math.PI / 2 },
    { zone: "hall", x: 60, z: 8, rotY: -Math.PI / 2 },
    { zone: "hall", x: 60, z: 16, rotY: -Math.PI / 2 },
    { zone: "crypt", x: -60, z: -12, rotY: Math.PI / 2 },
    { zone: "crypt", x: 60, z: -12, rotY: -Math.PI / 2 },
    { zone: "crypt", x: -25, z: -14, rotY: 0, vent: true },
    { zone: "crypt", x: 25, z: -14, rotY: 0, vent: true },
    { zone: "crypt", x: -10, z: -18, rotY: 0, vent: true },
    { zone: "crypt", x: 10, z: -18, rotY: 0, vent: true },
    { zone: "tower", x: -12, z: -48, rotY: 0 },
    { zone: "tower", x: 0, z: -48, rotY: 0 },
    { zone: "tower", x: 12, z: -48, rotY: 0 },
    { zone: "tower", x: -20, z: -36, rotY: 0, vent: true },
    { zone: "tower", x: 20, z: -36, rotY: 0, vent: true },
  ],
  stations: [
    { w: "mp5k", x: -20, z: 46.4, ry: Math.PI, label: "MP5K", color: "#57c8ff", zone: "start" },
    { w: "ak47", x: 20, z: 46.4, ry: Math.PI, label: "AK-47", color: "#ffa14f", zone: "start" },
    { w: "ak47", x: -39, z: 12, ry: Math.PI / 2, label: "AK-47", color: "#ffa14f", zone: "hall" },
    { w: "mp5k", x: 39, z: 12, ry: -Math.PI / 2, label: "MP5K", color: "#57c8ff", zone: "hall" },
    { w: "raygun", x: -25, z: -4, ry: Math.PI / 2, label: "RAY GUN", color: "#5dff8d", zone: "crypt" },
  ],
  powerBoxes: [{ x: 20, z: 8, zone: "hall", label: "MAINFRAME" }],
  pack: { x: 0, z: -27, zone: "tower", label: "PACK-A-PUNCH" },
  perks: [
    { perk: "vigor", x: -8, z: 16, zone: "hall", cost: 2000, label: "VIDA EXTRA" },
  ],
  relays: [
    { x: -14, z: -40, zone: "tower", label: "RETRANSMISSOR A" },
    { x: 14, z: -40, zone: "tower", label: "RETRANSMISSOR B" },
    { x: 0, z: -32, zone: "tower", label: "RETRANSMISSOR C" },
  ],
  parts: [
    { x: -30, z: -8, zone: "crypt", label: "PEÇA 1/3" },
    { x: 30, z: -8, zone: "crypt", label: "PEÇA 2/3" },
    { x: 0, z: -20, zone: "crypt", label: "PEÇA 3/3" },
  ],
  workbench: { x: 20, z: -16, zone: "crypt", label: "MONTAR ARMA ESPECIAL" },
  lore: [
    { lines: ["AQUI JAZ O REI", "QUE OUVIU A MÁQUINA"], x: 0, y: 1.4, z: 44, ry: Math.PI, w: 4.5, color: "#c9bfa5" },
    { lines: ["LOG_IA_CENTRAL:", "> frequência roxa 99%", "> eles obedecem"], x: -10, y: 3.0, z: 6, ry: 0.3, w: 5.5, color: "#b79bff" },
    { lines: ["NOTAS DO CEO:", "\"o poder antigo é NOSSO\""], x: 8, y: 1.8, z: -16, ry: -0.4, w: 4.5, color: "#ffd94f" },
    { lines: ["ALERTA CRÍTICO", "NÚCLEO DE ENERGIA"], x: -20, y: 2.6, z: -10, ry: Math.PI / 2, w: 4, color: "#ff5b5b" },
    { lines: ["A ANTENA OUVE", "NÃO PENSE ALTO"], x: 0, y: 1.2, z: -28, ry: Math.PI, w: 4.5, color: "#ff5b8a" },
  ],
};

export const MAPS: Record<MapId, MapDef> = {
  subzero: SUBZERO,
  terminal: TERMINAL,
  fortaleza: CASTLE,
};

export const MAP_LIST: MapDef[] = [SUBZERO, TERMINAL, CASTLE];

/** Vão da parede externa p/ cada janela de parede (a bala atravessa). */
export function outerGaps(def: MapDef): { north: number[]; south: number[]; west: number[]; east: number[] } {
  const g = { north: [] as number[], south: [] as number[], west: [] as number[], east: [] as number[] };
  for (const w of def.windows) {
    if (w.vent) continue;
    if (Math.abs(w.rotY - Math.PI) < 0.1) g.south.push(w.x);
    else if (Math.abs(w.rotY) < 0.1) g.north.push(w.x);
    else if (Math.abs(w.rotY - Math.PI / 2) < 0.1) g.west.push(w.z);
    else g.east.push(w.z);
  }
  return g;
}

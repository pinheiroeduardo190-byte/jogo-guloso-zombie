/* ============================================================
   DEAD OPS — Sargento BRUTO xingando em tempo real
   - Foco TOTAL em kill: xinga a cada abate, headshot, facada,
     multi-kill e brutamontes, com fila inteligente e interrupção.
   - Sistema SÓ fala o essencial (round, porta, energia, pack...).
   - Level NÃO é anunciado — só manda escolher a mutação.
   ============================================================ */

type VoicePick = SpeechSynthesisVoice | null;

interface SayOpts {
  prio?: number;      // 0 sistema | 1 kill | 2 destaque | 3 crítico
  cd?: number;        // cooldown ms desta categoria
  rate?: number;
}

class BrutalVoice {
  enabled = true;
  private voice: VoicePick = null;
  private queue: { text: string; prio: number; rate: number }[] = [];
  private speaking = false;
  private currentPrio = 0;
  private lastKillAt = 0;
  private lastSysAt = 0;
  private lastHotAt = 0;
  private lastIdx: Record<string, number> = {};
  private ctx: AudioContext | null = null;

  constructor() {
    try {
      this.enabled = localStorage.getItem("dz_voice") !== "0";
    } catch { this.enabled = true; }
    if ("speechSynthesis" in window) {
      const load = () => {
        const vs = window.speechSynthesis.getVoices();
        if (!vs.length) return;
        this.voice = this.pickMale(vs);
      };
      load();
      window.speechSynthesis.onvoiceschanged = load;
      const unlock = () => {
        try { window.speechSynthesis.getVoices(); } catch { /* noop */ }
        window.removeEventListener("pointerdown", unlock);
        window.removeEventListener("keydown", unlock);
      };
      window.addEventListener("pointerdown", unlock);
      window.addEventListener("keydown", unlock);
    }
  }

  setEnabled(v: boolean) {
    this.enabled = v;
    try { localStorage.setItem("dz_voice", v ? "1" : "0"); } catch { /* noop */ }
    if (!v) {
      this.queue = [];
      try { window.speechSynthesis?.cancel(); } catch { /* noop */ }
      this.speaking = false;
      this.currentPrio = 0;
    }
  }

  prime() {
    try { window.speechSynthesis?.getVoices(); } catch { /* noop */ }
  }

  private pickMale(vs: SpeechSynthesisVoice[]): VoicePick {
    const low = (n: string) => n.toLowerCase();
    const maleHints = ["daniel", "ricardo", "fabio", "fábio", "lucas", "rafael", "paulo", "marcos", "thiago", "google português do brasil masculino", "microsoft daniel", "microsoft ricardo"];
    for (const h of maleHints) {
      const f = vs.find((v) => low(v.name).includes(h));
      if (f) return f;
    }
    const ptBR = vs.filter((v) => v.lang.toLowerCase().startsWith("pt"));
    const femaleHints = ["maria", "ana", "francisca", "helena", "helo", "luciana", "camila", "female", "feminina", "google português do brasil feminino", "zira", "samantha"];
    const malePt = ptBR.find((v) => !femaleHints.some((h) => low(v.name).includes(h)));
    if (malePt) return malePt;
    if (ptBR.length) return ptBR[0];
    const en = vs.find((v) => v.lang.toLowerCase().startsWith("en") && /daniel|david|alex|dan|george|male/i.test(v.name));
    if (en) return en;
    return vs[0] ?? null;
  }

  /** Fala principal. Prioridade alta interrompe fala fraca p/ tempo real. */
  say(text: string, priority = false) {
    this.speak(text, { prio: priority ? 3 : 0 });
  }

  private speak(text: string, opts: SayOpts = {}) {
    if (!this.enabled || !text) return;
    const prio = opts.prio ?? 0;
    const now = performance.now();
    // throttles por canal — kill pode ser bem mais frequente
    if (prio === 1 && now - this.lastKillAt < (opts.cd ?? 1700)) return;
    if (prio === 0 && now - this.lastSysAt < (opts.cd ?? 2200)) return;
    if (prio === 2 && now - this.lastHotAt < (opts.cd ?? 900)) return;
    if (prio === 1) this.lastKillAt = now;
    if (prio === 0) this.lastSysAt = now;
    if (prio === 2) this.lastHotAt = now;
    if (prio === 3) { this.lastKillAt = now; this.lastSysAt = now; this.lastHotAt = now; }

    if (!("speechSynthesis" in window)) {
      this.gruntFallback(prio >= 2 ? 1.4 : 1);
      return;
    }
    // interrupção: destaque/crítico atropela fala fraca em andamento
    try {
      const synth = window.speechSynthesis;
      if ((prio >= 2) && (this.speaking || synth.speaking) && prio > this.currentPrio) {
        synth.cancel();
        this.speaking = false;
        this.queue = [];
      }
    } catch { /* noop */ }

    this.queue.push({ text, prio, rate: opts.rate ?? (prio === 1 ? 1.08 : prio === 2 ? 1.12 : 0.94) });
    // kill: só guarda a mais nova (tempo real). sistema: no máx 1 na fila
    if (this.queue.length > 1) {
      const highs = this.queue.filter((q) => q.prio >= 2).slice(-1);
      const last = this.queue[this.queue.length - 1];
      this.queue = highs.length && highs[0] !== last ? [...highs, last].slice(-2) : [last];
    }
    this.pump();
  }

  private pump() {
    if (this.speaking || !this.queue.length) return;
    if (!("speechSynthesis" in window)) return;
    try {
      const synth = window.speechSynthesis;
      if (synth.speaking) return;
      const item = this.queue.shift()!;
      const u = new SpeechSynthesisUtterance(item.text);
      if (this.voice) u.voice = this.voice;
      u.lang = this.voice?.lang ?? "pt-BR";
      u.pitch = 0.2 + Math.random() * 0.12; // grave + variação natural
      u.rate = item.rate;
      u.volume = 1.0;
      this.speaking = true;
      this.currentPrio = item.prio;
      u.onend = () => { this.speaking = false; this.currentPrio = 0; this.pump(); };
      u.onerror = () => { this.speaking = false; this.currentPrio = 0; this.pump(); };
      synth.speak(u);
      window.setTimeout(() => {
        if (this.speaking) { this.speaking = false; this.currentPrio = 0; this.pump(); }
      }, 3500);
    } catch {
      this.speaking = false;
      this.currentPrio = 0;
      this.gruntFallback(1);
    }
  }

  private gruntFallback(power = 1) {
    try {
      if (!this.ctx) this.ctx = new AudioContext();
      const ctx = this.ctx;
      if (ctx.state === "suspended") void ctx.resume();
      const t = ctx.currentTime;
      const o = ctx.createOscillator();
      o.type = "sawtooth";
      o.frequency.setValueAtTime(95, t);
      o.frequency.exponentialRampToValueAtTime(50, t + 0.35);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.22 * power, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.4);
      const f = ctx.createBiquadFilter();
      f.type = "lowpass"; f.frequency.value = 500;
      o.connect(f); f.connect(g); g.connect(ctx.destination);
      o.start(t); o.stop(t + 0.45);
    } catch { /* noop */ }
  }

  private pick(key: string, pool: string[]): string {
    let i = (Math.random() * pool.length) | 0;
    if (pool.length > 1 && this.lastIdx[key] === i) i = (i + 1 + ((Math.random() * (pool.length - 1)) | 0)) % pool.length;
    this.lastIdx[key] = i;
    return pool[i];
  }

  /* ============ XINGAMENTO EM TEMPO REAL (KILLS) ============ */

  private KILL = [
    "Morreu, desgraçado!",
    "Toma essa, filho da puta!",
    "Vai pro inferno, porra!",
    "Mais um pro chão, caralho!",
    "Derrubado! Chupa essa!",
    "É bala, arrombado!",
    "Deita, desgraça!",
    "Toma chumbo, miserável!",
    "Pro chão, filho da puta!",
    "Apagado! Quem é o próximo?",
    "Rasgado no meio, porra!",
    "Boa noite, carniça!",
    "Manda outro, seus merdas!",
    "Furou, desgraçado!",
    "Toma! Aprende a morrer!",
    "Noite de caça, porra!",
    "Despedaçado, caralho!",
    "Mais um pra conta, seus lixos!",
    "Comeu bala, otário!",
    "Enterrado! Próximo!",
  ];

  private HEAD = [
    "Cabeça explodida, caralho!",
    "Miolo no chão, porra!",
    "Na testa, filho da puta!",
    "Headshot, desgraçado!",
    "Estourou os miolos!",
    "Tiro cirúrgico, porra!",
    "Crânio rachado, caralho!",
    "Bem no meio da fuça!",
    "Cérebro voando, miserável!",
    "Na cabeça! Aprende, arrombado!",
  ];

  private KNIFE = [
    "Faca no bucho, arrombado!",
    "Cortado, filho da puta!",
    "Na lâmina, desgraçado!",
    "Fatiado, porra!",
    "Toma facada, caralho!",
    "Abrindo esse lixo na faca!",
  ];

  private BRUTE = [
    "O grandão caiu, porra!",
    "Brutamontes pro chão, caralho!",
    "Derrubei o gigante, seus merdas!",
    "Nem o grandão aguentou, desgraça!",
    "Toma, montanha de bosta!",
  ];

  private MULTI2 = [
    "Double kill, porra!",
    "Dois de uma vez, caralho!",
    "Dobradinha de defunto!",
  ];
  private MULTI3 = [
    "Triple kill! Vocês são uns monstros!",
    "Três pro inferno, porra!",
    "Chacina tripla, caralho!",
  ];
  private RAMPAGE = [
    "Massacre! Ninguém segura vocês, porra!",
    "Rampage, caralho! Continuem matando!",
    "Isso é um abate, seus desgraçados lindos!",
    "Chuva de tripas! Sensacional, porra!",
  ];

  /** Chamada a cada abate. Decide sozinha o que gritar. */
  kill(opts: { head?: boolean; knife?: boolean; brute?: boolean; streak?: number; total?: number }) {
    if (!this.enabled) return;
    const { head, knife, brute, streak = 1, total = 0 } = opts;
    // marcos de carnificina (raros, alta prioridade)
    if (total > 0 && (total === 50 || total === 100 || total === 200 || total === 350 || total === 500)) {
      this.speak(this.pick("mile", [
        `${total} mortos, porra! Vocês são a própria morte!`,
        `${total} carniças no chão! Lendário, caralho!`,
      ]), { prio: 2 });
      return;
    }
    if (streak >= 5) { this.speak(this.pick("ramp", this.RAMPAGE), { prio: 2 }); return; }
    if (streak === 4) { this.speak(this.pick("ramp", this.RAMPAGE), { prio: 2 }); return; }
    if (streak === 3) { this.speak(this.pick("m3", this.MULTI3), { prio: 2 }); return; }
    if (streak === 2) { this.speak(this.pick("m2", this.MULTI2), { prio: 1, cd: 1200 }); return; }
    if (brute) { this.speak(this.pick("brute", this.BRUTE), { prio: 2 }); return; }
    if (knife) { this.speak(this.pick("knife", this.KNIFE), { prio: 2 }); return; }
    if (head) { this.speak(this.pick("head", this.HEAD), { prio: 1, cd: 1300 }); return; }
    this.speak(this.pick("kill", this.KILL), { prio: 1 });
  }

  /* ============ SISTEMA (curto, xingando, sem tagarelar) ============ */

  /** Level: NÃO anuncia número nenhum. Só manda escolher a mutação. */
  mutation() {
    this.speak(this.pick("mut", [
      "Escolhe logo essa porra de mutação!",
      "Mutação na tela! Escolhe, caralho!",
      "Para de enrolar e escolhe a mutação, porra!",
      "Mutação! Escolhe rápido, desgraça!",
    ]), { prio: 2, cd: 500 });
  }
  /** compat: ninguém mais fala nível */
  levelup(_level: number) { this.mutation(); }

  round(n: number) {
    const lines = [
      `Round ${n}. Segura essa porra de posição!`,
      `Round ${n}. Eles vêm com tudo. Rasga esses desgraçados!`,
      `Round ${n}. Sem piedade, sem recuo, porra!`,
    ];
    this.speak(lines[n % lines.length], { prio: 3 });
  }
  roundClear(bonus: number) {
    this.speak(`Área limpa, porra! ${bonus} dólares no bolso.`, { prio: 0, cd: 1000 });
  }
  door(label: string) {
    this.speak(`${label} aberta. Entra rasgando, porra!`, { prio: 0, cd: 1000 });
  }
  power() { this.speak("Energia ligada, caralho! Pack-a-Punch online. Caça liberada!", { prio: 2 }); }
  pack(weapon: string) { this.speak(`${weapon} melhorada. Agora vai chover tripa, porra!`, { prio: 2 }); }
  perk(label: string) { this.speak(`${label}! Mais forte, desgraçado!`, { prio: 0 }); }
  relay(done: number, total: number) {
    if (done >= total) this.speak("Frequência azul, porra! O controle deles quebrou. Massacrem tudo!", { prio: 3 });
    else this.speak(`Retransmissor ${done} de ${total}. Continua, caralho!`, { prio: 2 });
  }
  workbench() { this.speak("Ceifador montado, porra! Isso aí é a morte em pessoa!", { prio: 2 }); }
  maxAmmo() { this.speak("Munição máxima! Enche o pente e volta matando, porra!", { prio: 0 }); }
  insta() { this.speak("Um tiro, um morto, caralho! Aproveita essa porra!", { prio: 2 }); }
  nuke() { this.speak("Nuclear, porra! Todo mundo pelos ares!", { prio: 3 }); }
  gameOver() { this.speak("Homem caído, porra! Vocês lutaram como uns desgraçados valentes. De novo!", { prio: 3 }); }
  lowHp() { this.speak(this.pick("low", ["Tá sangrando pra caralho! Sai daí, porra!", "Quase morto, desgraçado! Corre!"]), { prio: 2 }); }
  barrier() { this.speak("Barreira rompida, merda! Reconstrói essa porra rápido!", { prio: 2 }); }
  detector() { this.speak("Alarme, porra! Eles ouviram! Prepara!", { prio: 2 }); }
}

export const voice = new BrutalVoice();

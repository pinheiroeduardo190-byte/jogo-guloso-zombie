/* ============================================================
   DEAD OPS — Ability / XP system
   12 habilidades, cada uma com 3 níveis (NV3 = máximo).
   ============================================================ */

export interface AbilityDef {
  id: string;
  name: string;
  tagline: string;
  desc: [string, string, string];
  icon: string;
  color: string;
}

export const ABILITIES: Record<string, AbilityDef> = {
  field: {
    id: "field", name: "CAMPO DE FORÇA", tagline: "Aura que queima e retarda",
    icon: "shield", color: "#5dff8d",
    desc: [
      "Aura tóxica (R110): 16 dano/s e -28% velocidade nos zumbis.",
      "Aura maior (R140): 30 dano/s e -45% velocidade.",
      "DOMÍNIO TOTAL (R170): 52 dano/s e -62% velocidade.",
    ],
  },
  blades: {
    id: "blades", name: "LÂMINAS ORBITAIS", tagline: "Espadas que giram ao seu redor",
    icon: "swords", color: "#cfe6ff",
    desc: [
      "1 lâmina orbital: 38 de dano por corte.",
      "3 lâminas: 55 de dano, órbita maior e mais rápida.",
      "5 LÂMINAS: 80 de dano, órbita máxima e veloz.",
    ],
  },
  rapid: {
    id: "rapid", name: "GATILHO LEVE", tagline: "Cadência de tiro",
    icon: "zap", color: "#ffe066",
    desc: [
      "+15% cadência de tiro em todas as armas.",
      "+30% cadência de tiro em todas as armas.",
      "+50% cadência. Chuva de chumbo.",
    ],
  },
  dmg: {
    id: "dmg", name: "BALAS PERFURANTES", tagline: "Dano bruto",
    icon: "crosshair", color: "#ff9d5d",
    desc: [
      "+20% de dano em todos os tiros e cortes.",
      "+45% de dano em todos os tiros e cortes.",
      "+75% de dano. Tudo derrete.",
    ],
  },
  pierce: {
    id: "pierce", name: "BALAS ESPECTRAIS", tagline: "Tiros atravessam zumbis",
    icon: "ghost", color: "#b79bff",
    desc: [
      "Tiros atravessam +1 zumbi extra.",
      "Tiros atravessam +2 zumbis extras.",
      "Atravessam +4. Uma bala, uma fila de mortos.",
    ],
  },
  crit: {
    id: "crit", name: "CAÇADOR DE CRÂNIOS", tagline: "Críticos devastadores",
    icon: "target", color: "#ff5d5d",
    desc: [
      "10% de chance de crítico x1.8.",
      "20% de chance de crítico x2.2.",
      "35% de chance de crítico x2.9.",
    ],
  },
  nova: {
    id: "nova", name: "PULSO NOVA", tagline: "Onda de choque periódica",
    icon: "nova", color: "#7dd7ff",
    desc: [
      "Onda a cada 6s: 70 de dano (raio 150).",
      "Onda a cada 4.5s: 125 de dano (raio 180).",
      "Onda a cada 3.2s: 200 de dano (raio 215).",
    ],
  },
  thunder: {
    id: "thunder", name: "JUÍZO FINAL", tagline: "Raios caem do céu",
    icon: "storm", color: "#e8f4ff",
    desc: [
      "1 raio a cada 5s: 90 de dano.",
      "2 raios a cada 3.6s: 135 de dano.",
      "4 raios a cada 2.6s: 190 de dano.",
    ],
  },
  vampire: {
    id: "vampire", name: "PACTO SOMBRIO", tagline: "Roube vida dos mortos",
    icon: "vampire", color: "#ff4d6d",
    desc: [
      "+5 de vida a cada abate.",
      "+11 de vida a cada abate.",
      "+20 por abate e roubo de vida em cada tiro.",
    ],
  },
  regen: {
    id: "regen", name: "SORO 935", tagline: "Regeneração constante",
    icon: "heart", color: "#7dffb0",
    desc: [
      "+15 vida máxima e regenera 4/s sempre.",
      "+30 vida máxima e regenera 9/s sempre.",
      "+50 vida máxima e regenera 16/s sempre.",
    ],
  },
  boots: {
    id: "boots", name: "ADRENALINA", tagline: "Velocidade de movimento",
    icon: "boots", color: "#ffd166",
    desc: [
      "+8% velocidade de movimento.",
      "+16% velocidade de movimento.",
      "+27% velocidade. Impossível de cercar.",
    ],
  },
  magnet: {
    id: "magnet", name: "ÍMÃ DE SUCATA", tagline: "Coleta longe + XP extra",
    icon: "magnet", color: "#ff8ad8",
    desc: [
      "Coleta drops de longe e +10% de XP.",
      "Coleta maior e +22% de XP.",
      "Coleta enorme e +38% de XP.",
    ],
  },
};

/* ---------- tabelas de parâmetros por nível (índice = nível) ---------- */
export const RAPID_MULT = [1, 0.87, 0.74, 0.6];
export const DMG_MULT = [1, 1.2, 1.45, 1.75];
export const PIERCE_N = [0, 1, 2, 4];
export const CRIT_CH = [0, 0.1, 0.2, 0.35];
export const CRIT_MULT = [1, 1.8, 2.2, 2.9];
export const BOOTS_MULT = [1, 1.08, 1.16, 1.27];
export const MAGNET_R = [34, 78, 120, 180];
export const MAGNET_XP = [1, 1.1, 1.22, 1.38];
export const REGEN_MAX = [0, 15, 30, 50];
export const REGEN_RATE = [0, 4, 9, 16];
export const VAMP_KILL = [0, 5, 11, 20];
export const VAMP_HIT = [0, 0, 0.6, 1.2];

export function fieldParams(lvl: number) {
  if (lvl >= 3) return { r: 170, dps: 52, slow: 0.62 };
  if (lvl === 2) return { r: 140, dps: 30, slow: 0.45 };
  return { r: 110, dps: 16, slow: 0.28 };
}
export function bladeParams(lvl: number) {
  if (lvl >= 3) return { count: 5, dmg: 80, radius: 108, speed: 4.2 };
  if (lvl === 2) return { count: 3, dmg: 55, radius: 92, speed: 3.4 };
  return { count: 1, dmg: 38, radius: 78, speed: 2.8 };
}
export function novaParams(lvl: number) {
  if (lvl >= 3) return { cd: 3.2, dmg: 200, r: 215 };
  if (lvl === 2) return { cd: 4.5, dmg: 125, r: 180 };
  return { cd: 6, dmg: 70, r: 150 };
}
export function thunderParams(lvl: number) {
  if (lvl >= 3) return { cd: 2.6, strikes: 4, dmg: 190 };
  if (lvl === 2) return { cd: 3.6, strikes: 2, dmg: 135 };
  return { cd: 5, strikes: 1, dmg: 90 };
}

/* ---------- XP ---------- */
export function xpNeedForLevel(level: number): number {
  return Math.round(34 + level * 20 + Math.pow(level, 1.65) * 9);
}

/* ---------- escolhas de level-up ---------- */
export interface Choice {
  id: string;
  kind: "ability" | "supply";
  level: number;
  name: string;
  desc: string;
  color: string;
  icon: string;
  tag: string;
}

export const SUPPLIES: Record<string, { name: string; desc: string; color: string; icon: string }> = {
  supply_points: { name: "CAIXA DE SUPRIMENTO", desc: "+750 pontos na hora. Guerra custa caro.", color: "#ffd94f", icon: "package" },
  supply_ammo: { name: "CAIXOTE DE MUNIÇÃO", desc: "Pentes e reservas CHEIOS em todas as armas.", color: "#9adcff", icon: "package" },
  supply_health: { name: "KIT MÉDICO", desc: "Cura TOTAL imediata. Volte à luta.", color: "#ff7a7a", icon: "package" },
};

export function rollChoices(owned: Record<string, number>, n = 3): Choice[] {
  const pool = Object.keys(ABILITIES).filter((id) => (owned[id] ?? 0) < 3);
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  const out: Choice[] = [];
  for (const id of pool.slice(0, n)) {
    const lvl = (owned[id] ?? 0) + 1;
    const def = ABILITIES[id];
    out.push({
      id, kind: "ability", level: lvl, name: def.name,
      desc: def.desc[lvl - 1], color: def.color, icon: def.icon,
      tag: lvl === 1 ? "NOVA HABILIDADE" : lvl === 2 ? "NÍVEL 2" : "NÍVEL MÁXIMO",
    });
  }
  const supKeys = Object.keys(SUPPLIES);
  let si = 0;
  while (out.length < n) {
    const sid = supKeys[si % supKeys.length];
    si++;
    const s = SUPPLIES[sid];
    out.push({ id: sid, kind: "supply", level: 0, name: s.name, desc: s.desc, color: s.color, icon: s.icon, tag: "SUPORTE" });
  }
  return out;
}
